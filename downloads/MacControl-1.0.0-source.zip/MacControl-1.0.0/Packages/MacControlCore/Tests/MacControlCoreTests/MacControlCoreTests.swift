import Foundation
import XCTest
@testable import MacControlCore

final class MacControlCoreTests: XCTestCase {
    func testHandshakeEncryptionAndReplayProtection() throws {
        let pin = "482915"
        let hostHS = HandshakeContext(role: .host, deviceName: "MacBook Pro")
        let clientHS = HandshakeContext(role: .client, deviceName: "iPhone 17 Pro")

        let hostHello = hostHS.makeHello()
        let clientHello = clientHS.makeHello()

        let hostMaterial = try hostHS.deriveKeys(peerHello: clientHello, pin: pin)
        let clientMaterial = try clientHS.deriveKeys(peerHello: hostHello, pin: pin)

        XCTAssertTrue(hostMaterial.verifyPeerProof(clientMaterial.myAuthProof()))
        XCTAssertTrue(clientMaterial.verifyPeerProof(hostMaterial.myAuthProof()))

        let hostCrypto = hostMaterial.buildCryptoSession()
        let clientCrypto = clientMaterial.buildCryptoSession()

        let msg = ClientControlMessage.pointerMoveNormalized(x: 0.42, y: 0.73, displayID: 1)
        let encodedMsg = try JSONEncoder().encode(msg)
        let cipher = try clientCrypto.seal(encodedMsg, associatedKind: .encryptedControl)
        let opened = try hostCrypto.open(cipher, associatedKind: .encryptedControl)
        let decoded = try JSONDecoder().decode(ClientControlMessage.self, from: opened)
        XCTAssertEqual(decoded, msg)

        // Replay of identical packet must be rejected
        XCTAssertThrowsError(try hostCrypto.open(cipher, associatedKind: .encryptedControl))

        // Out-of-order / skipped packets (e.g., dropped video frames on relay) must still authenticate later frames
        _ = try hostCrypto.seal(Data([1, 2, 3]), associatedKind: .encryptedVideo) // seq 1 dropped
        _ = try hostCrypto.seal(Data([4, 5, 6]), associatedKind: .encryptedVideo) // seq 2 dropped
        let seq3 = try hostCrypto.seal(Data([7, 8, 9]), associatedKind: .encryptedVideo)
        let openedSeq3 = try clientCrypto.open(seq3, associatedKind: .encryptedVideo)
        XCTAssertEqual(openedSeq3, Data([7, 8, 9]))
    }

    func testWrongPinFailsHandshakeVerification() throws {
        let hostHS = HandshakeContext(role: .host, deviceName: "Mac Studio")
        let clientHS = HandshakeContext(role: .client, deviceName: "iPhone")

        let hostMaterial = try hostHS.deriveKeys(peerHello: clientHS.makeHello(), pin: "111111")
        let clientMaterial = try clientHS.deriveKeys(peerHello: hostHS.makeHello(), pin: "999999")

        XCTAssertFalse(hostMaterial.verifyPeerProof(clientMaterial.myAuthProof()))
        XCTAssertFalse(clientMaterial.verifyPeerProof(hostMaterial.myAuthProof()))
    }

    func testStreamDeframerHandlesChunkedAndCoalescedFrames() throws {
        let f1 = WireFrame(kind: .encryptedControl, payload: Data("hello-control".utf8))
        let f2 = WireFrame(kind: .encryptedVideo, payload: Data(repeating: 0xAB, count: 4096))
        let combined = f1.serialize() + f2.serialize()

        let deframer = WireStreamDeframer()
        // Feed 3 bytes at a time at start, then rest in two uneven chunks
        XCTAssertTrue(try deframer.push(Data(combined[0..<3])).isEmpty)
        let firstBatch = try deframer.push(Data(combined[3..<50]))
        XCTAssertEqual(firstBatch, [f1])
        let secondBatch = try deframer.push(Data(combined[50..<combined.count]))
        XCTAssertEqual(secondBatch, [f2])
    }

    func testVideoAndAudioBinaryPacketRoundTrip() {
        let sps = Data([0x67, 0x64, 0x00, 0x1F])
        let pps = Data([0x68, 0xEB, 0xEC, 0xB2])
        let avcc = Data([0x00, 0x00, 0x00, 0x05, 0x65, 0x88, 0x84, 0x00, 0x10])
        let packet = VideoFramePacket(
            codec: .hevc,
            isKeyframe: true,
            width: 1920,
            height: 1200,
            timestampUs: 123_456_789,
            parameterSets: [sps, pps],
            avccData: avcc
        )
        let roundTrip = VideoFramePacket.decode(from: packet.encode())
        XCTAssertEqual(roundTrip, packet)

        let audio = AudioFramePacket(
            sampleRate: 24_000,
            channels: 2,
            timestampUs: 987_654,
            pcmInt16Data: Data([0x01, 0x02, 0xFE, 0xFF])
        )
        XCTAssertEqual(AudioFramePacket.decode(from: audio.encode()), audio)
    }

    func testPairingQRPayloadRoundTrip() {
        let payload = PairingQRPayload(
            hostName: "Thushar's Mac",
            localHost: "192.168.1.42",
            vpnHost: "100.88.12.5",
            port: 59420,
            relayURL: "wss://relay.example.com",
            relayRoomID: "MAC-7K2P",
            pin: "604821"
        )
        let uri = payload.toURIString()
        let parsed = PairingQRPayload.fromURIString(uri)
        XCTAssertEqual(parsed, payload)
    }
}
