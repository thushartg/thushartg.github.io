// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "MacControlCore",
    platforms: [
        .macOS(.v14),
        .iOS(.v17)
    ],
    products: [
        .library(
            name: "MacControlCore",
            targets: ["MacControlCore"]
        )
    ],
    targets: [
        .target(
            name: "MacControlCore",
            path: "Sources/MacControlCore"
        ),
        .testTarget(
            name: "MacControlCoreTests",
            dependencies: ["MacControlCore"],
            path: "Tests/MacControlCoreTests"
        )
    ]
)
