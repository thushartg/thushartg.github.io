import Foundation

/// Encodes and parses QR code / URI pairing payloads (`maccontrol://pair?...`)
/// so the iPhone app can configure Local IP, Tailscale VPN IP, Internet Relay Room, and Pairing PIN in one scan.
public struct PairingQRPayload: Codable, Equatable, Sendable {
    public var hostName: String
    public var localHost: String?
    public var vpnHost: String?
    public var port: UInt16
    public var relayURL: String?
    public var relayRoomID: String?
    public var pin: String

    public init(
        hostName: String,
        localHost: String?,
        vpnHost: String?,
        port: UInt16,
        relayURL: String?,
        relayRoomID: String?,
        pin: String
    ) {
        self.hostName = hostName
        self.localHost = localHost
        self.vpnHost = vpnHost
        self.port = port
        self.relayURL = relayURL
        self.relayRoomID = relayRoomID
        self.pin = pin
    }

    public func toURIString() -> String {
        var components = URLComponents()
        components.scheme = "maccontrol"
        components.host = "pair"
        var items: [URLQueryItem] = [
            URLQueryItem(name: "name", value: hostName),
            URLQueryItem(name: "port", value: String(port)),
            URLQueryItem(name: "pin", value: pin)
        ]
        if let localHost, !localHost.isEmpty {
            items.append(URLQueryItem(name: "lan", value: localHost))
        }
        if let vpnHost, !vpnHost.isEmpty {
            items.append(URLQueryItem(name: "vpn", value: vpnHost))
        }
        if let relayURL, !relayURL.isEmpty {
            items.append(URLQueryItem(name: "relay", value: relayURL))
        }
        if let relayRoomID, !relayRoomID.isEmpty {
            items.append(URLQueryItem(name: "room", value: relayRoomID))
        }
        components.queryItems = items
        return components.string ?? ""
    }

    public static func fromURIString(_ raw: String) -> PairingQRPayload? {
        guard let components = URLComponents(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
              components.scheme?.lowercased() == "maccontrol",
              components.host?.lowercased() == "pair" else {
            return nil
        }
        let dict = Dictionary(uniqueKeysWithValues: (components.queryItems ?? []).compactMap { item -> (String, String)? in
            guard let val = item.value else { return nil }
            return (item.name, val)
        })
        guard let pin = dict["pin"], !pin.isEmpty else { return nil }
        let port = UInt16(dict["port"] ?? "") ?? MacControlConstants.defaultPort
        return PairingQRPayload(
            hostName: dict["name"] ?? "Mac",
            localHost: dict["lan"],
            vpnHost: dict["vpn"],
            port: port,
            relayURL: dict["relay"],
            relayRoomID: dict["room"],
            pin: pin
        )
    }
}
