import Foundation

public enum MacControlConstants {
    public static let protocolVersion: Int = 1
    public static let bonjourServiceType = "_maccontrol._tcp"
    public static let defaultPort: UInt16 = 59420
    public static let defaultRelayPort: UInt16 = 8787
}

public enum MouseButton: String, Codable, Sendable {
    case left
    case right
    case center
}

public enum ScrollPhase: String, Codable, Sendable {
    case began
    case changed
    case ended
    case instant
}

public struct KeyModifiers: OptionSet, Codable, Hashable, Sendable {
    public let rawValue: UInt32

    public init(rawValue: UInt32) {
        self.rawValue = rawValue
    }

    public static let command  = KeyModifiers(rawValue: 1 << 0)
    public static let shift    = KeyModifiers(rawValue: 1 << 1)
    public static let option   = KeyModifiers(rawValue: 1 << 2)
    public static let control  = KeyModifiers(rawValue: 1 << 3)
    public static let function = KeyModifiers(rawValue: 1 << 4)
}

public enum StreamQuality: String, Codable, CaseIterable, Identifiable, Sendable {
    case low
    case balanced
    case high
    case ultra

    public var id: String { rawValue }

    public var label: String {
        switch self {
        case .low: return "Low (Cellular / Saver)"
        case .balanced: return "Balanced (720p–1080p)"
        case .high: return "High (Retina Sharp)"
        case .ultra: return "Ultra (LAN / USB)"
        }
    }

    public var maxDimension: Int {
        switch self {
        case .low: return 1152
        case .balanced: return 1600
        case .high: return 2048
        case .ultra: return 2560
        }
    }

    public var targetBitrateBps: Int {
        switch self {
        case .low: return 1_400_000
        case .balanced: return 3_500_000
        case .high: return 7_000_000
        case .ultra: return 14_000_000
        }
    }
}

public enum VideoCodecKind: UInt8, Codable, CaseIterable, Sendable {
    case h264 = 1
    case hevc = 2
}

public enum SystemAction: Codable, Equatable, Sendable {
    case volumeUp
    case volumeDown
    case setVolume(Float)
    case toggleMute
    case brightnessUp
    case brightnessDown
    case mediaPlayPause
    case mediaNext
    case mediaPrevious
    case missionControl
    case appExpose
    case showDesktop
    case launchpad
    case spotlight
    case lockScreen
    case sleepDisplay
    case sleepMac
}

public struct DisplayMetadata: Codable, Equatable, Identifiable, Sendable {
    public let id: UInt32
    public let name: String
    public let width: Int
    public let height: Int
    public let isMain: Bool

    public init(id: UInt32, name: String, width: Int, height: Int, isMain: Bool) {
        self.id = id
        self.name = name
        self.width = width
        self.height = height
        self.isMain = isMain
    }

    public var aspectRatio: Double {
        guard height > 0 else { return 16.0 / 10.0 }
        return Double(width) / Double(height)
    }
}

public struct StreamConfiguration: Codable, Equatable, Sendable {
    public var enabled: Bool
    public var fps: Int
    public var quality: StreamQuality
    public var codec: VideoCodecKind
    public var audioEnabled: Bool
    public var displayID: UInt32?

    public init(
        enabled: Bool = true,
        fps: Int = 60,
        quality: StreamQuality = .high,
        codec: VideoCodecKind = .hevc,
        audioEnabled: Bool = false,
        displayID: UInt32? = nil
    ) {
        self.enabled = enabled
        self.fps = fps
        self.quality = quality
        self.codec = codec
        self.audioEnabled = audioEnabled
        self.displayID = displayID
    }
}

public enum ClientControlMessage: Codable, Equatable, Sendable {
    /// Absolute normalized touch coordinates (0.0 ... 1.0) on the target display.
    case pointerMoveNormalized(x: Double, y: Double, displayID: UInt32?)
    case pointerButton(x: Double?, y: Double?, button: MouseButton, isDown: Bool, clickCount: Int, displayID: UInt32?)

    /// Relative Magic Trackpad movements and clicks.
    case trackpadDelta(dx: Double, dy: Double, isDragging: Bool)
    case trackpadClick(button: MouseButton, clickCount: Int)
    case scroll(dx: Double, dy: Double, phase: ScrollPhase)

    /// Virtual keycode & Unicode text input.
    case keyEvent(keyCode: UInt16, modifiers: KeyModifiers, isDown: Bool)
    case keyShortcut(keyCode: UInt16, modifiers: KeyModifiers)
    case textInput(text: String)

    /// System actions, stream tuning, and clipboard sync.
    case systemCommand(SystemAction)
    case configureStream(StreamConfiguration)
    case requestKeyframe
    case setClipboard(text: String)
    case requestClipboard
    case ping(timestampMs: UInt64)
}

public struct HostInfo: Codable, Equatable, Sendable {
    public let hostName: String
    public let osVersion: String
    public let displays: [DisplayMetadata]
    public let activeDisplayID: UInt32?
    public let accessibilityGranted: Bool
    public let screenRecordingGranted: Bool
    public let volume: Float
    public let isMuted: Bool
    public let streamConfig: StreamConfiguration

    public init(
        hostName: String,
        osVersion: String,
        displays: [DisplayMetadata],
        activeDisplayID: UInt32?,
        accessibilityGranted: Bool,
        screenRecordingGranted: Bool,
        volume: Float,
        isMuted: Bool,
        streamConfig: StreamConfiguration
    ) {
        self.hostName = hostName
        self.osVersion = osVersion
        self.displays = displays
        self.activeDisplayID = activeDisplayID
        self.accessibilityGranted = accessibilityGranted
        self.screenRecordingGranted = screenRecordingGranted
        self.volume = volume
        self.isMuted = isMuted
        self.streamConfig = streamConfig
    }
}

public enum HostControlMessage: Codable, Equatable, Sendable {
    case hostInfo(HostInfo)
    case clipboardUpdate(text: String)
    case cursorPosition(normalizedX: Double, normalizedY: Double)
    case pong(clientTimestampMs: UInt64)
    case statusBanner(message: String, isWarning: Bool)
}

// MARK: - Handshake DTOs

public struct HandshakeHello: Codable, Sendable {
    public let protocolVersion: Int
    public let deviceName: String
    public let publicKeyBase64: String
    public let nonceBase64: String

    public init(protocolVersion: Int = MacControlConstants.protocolVersion, deviceName: String, publicKeyBase64: String, nonceBase64: String) {
        self.protocolVersion = protocolVersion
        self.deviceName = deviceName
        self.publicKeyBase64 = publicKeyBase64
        self.nonceBase64 = nonceBase64
    }
}

public struct HandshakeAuthProof: Codable, Sendable {
    public let hmacBase64: String

    public init(hmacBase64: String) {
        self.hmacBase64 = hmacBase64
    }
}

public struct HandshakeReject: Codable, Sendable {
    public let reason: String
    public let retryAfterSeconds: Int?

    public init(reason: String, retryAfterSeconds: Int? = nil) {
        self.reason = reason
        self.retryAfterSeconds = retryAfterSeconds
    }
}
