import Foundation

/// Standard macOS Carbon / HIToolbox virtual key codes shared across macOS and iOS.
public enum MacKeyCode {
    public static let ansiA: UInt16 = 0x00
    public static let ansiS: UInt16 = 0x01
    public static let ansiD: UInt16 = 0x02
    public static let ansiF: UInt16 = 0x03
    public static let ansiH: UInt16 = 0x04
    public static let ansiG: UInt16 = 0x05
    public static let ansiZ: UInt16 = 0x06
    public static let ansiX: UInt16 = 0x07
    public static let ansiC: UInt16 = 0x08
    public static let ansiV: UInt16 = 0x09
    public static let ansiB: UInt16 = 0x0B
    public static let ansiQ: UInt16 = 0x0C
    public static let ansiW: UInt16 = 0x0D
    public static let ansiE: UInt16 = 0x0E
    public static let ansiR: UInt16 = 0x0F
    public static let ansiY: UInt16 = 0x10
    public static let ansiT: UInt16 = 0x11
    public static let ansi1: UInt16 = 0x12
    public static let ansi2: UInt16 = 0x13
    public static let ansi3: UInt16 = 0x14
    public static let ansi4: UInt16 = 0x15
    public static let ansi6: UInt16 = 0x16
    public static let ansi5: UInt16 = 0x17
    public static let equal: UInt16 = 0x18
    public static let ansi9: UInt16 = 0x19
    public static let ansi7: UInt16 = 0x1A
    public static let minus: UInt16 = 0x1B
    public static let ansi8: UInt16 = 0x1C
    public static let ansi0: UInt16 = 0x1D
    public static let rightBracket: UInt16 = 0x1E
    public static let ansiO: UInt16 = 0x1F
    public static let ansiU: UInt16 = 0x20
    public static let leftBracket: UInt16 = 0x21
    public static let ansiI: UInt16 = 0x22
    public static let ansiP: UInt16 = 0x23
    public static let returnKey: UInt16 = 0x24
    public static let ansiL: UInt16 = 0x25
    public static let ansiJ: UInt16 = 0x26
    public static let quote: UInt16 = 0x27
    public static let ansiK: UInt16 = 0x28
    public static let semicolon: UInt16 = 0x29
    public static let backslash: UInt16 = 0x2A
    public static let comma: UInt16 = 0x2B
    public static let slash: UInt16 = 0x2C
    public static let ansiN: UInt16 = 0x2D
    public static let ansiM: UInt16 = 0x2E
    public static let period: UInt16 = 0x2F
    public static let tab: UInt16 = 0x30
    public static let space: UInt16 = 0x31
    public static let grave: UInt16 = 0x32
    public static let delete: UInt16 = 0x33
    public static let escape: UInt16 = 0x35
    public static let command: UInt16 = 0x37
    public static let shift: UInt16 = 0x38
    public static let capsLock: UInt16 = 0x39
    public static let option: UInt16 = 0x3A
    public static let control: UInt16 = 0x3B
    public static let function: UInt16 = 0x3F

    public static let f1: UInt16 = 0x7A
    public static let f2: UInt16 = 0x78
    public static let f3: UInt16 = 0x63
    public static let f4: UInt16 = 0x76
    public static let f5: UInt16 = 0x60
    public static let f6: UInt16 = 0x61
    public static let f7: UInt16 = 0x62
    public static let f8: UInt16 = 0x64
    public static let f9: UInt16 = 0x65
    public static let f10: UInt16 = 0x6D
    public static let f11: UInt16 = 0x67
    public static let f12: UInt16 = 0x6F

    public static let home: UInt16 = 0x73
    public static let pageUp: UInt16 = 0x74
    public static let forwardDelete: UInt16 = 0x75
    public static let end: UInt16 = 0x77
    public static let pageDown: UInt16 = 0x79

    public static let leftArrow: UInt16 = 0x7B
    public static let rightArrow: UInt16 = 0x7C
    public static let downArrow: UInt16 = 0x7D
    public static let upArrow: UInt16 = 0x7E

    /// Maps ASCII single characters to macOS virtual keycodes (for modifier combinations like Cmd+C).
    public static func keyCode(forCharacter char: Character) -> (keyCode: UInt16, needsShift: Bool)? {
        let lower = String(char).lowercased()
        let isUpper = char.isUppercase && char.isLetter

        let baseMap: [String: UInt16] = [
            "a": ansiA, "s": ansiS, "d": ansiD, "f": ansiF, "h": ansiH, "g": ansiG,
            "z": ansiZ, "x": ansiX, "c": ansiC, "v": ansiV, "b": ansiB, "q": ansiQ,
            "w": ansiW, "e": ansiE, "r": ansiR, "y": ansiY, "t": ansiT, "1": ansi1,
            "2": ansi2, "3": ansi3, "4": ansi4, "6": ansi6, "5": ansi5, "=": equal,
            "9": ansi9, "7": ansi7, "-": minus, "8": ansi8, "0": ansi0, "]": rightBracket,
            "o": ansiO, "u": ansiU, "[": leftBracket, "i": ansiI, "p": ansiP, "l": ansiL,
            "j": ansiJ, "'": quote, "k": ansiK, ";": semicolon, "\\": backslash,
            ",": comma, "/": slash, "n": ansiN, "m": ansiM, ".": period, "`": grave,
            " ": space, "\n": returnKey, "\r": returnKey, "\t": tab
        ]
        if let code = baseMap[lower] {
            return (code, isUpper)
        }

        let shiftedSymbolMap: [Character: UInt16] = [
            "!": ansi1, "@": ansi2, "#": ansi3, "$": ansi4, "%": ansi5,
            "^": ansi6, "&": ansi7, "*": ansi8, "(": ansi9, ")": ansi0,
            "_": minus, "+": equal, "{": leftBracket, "}": rightBracket,
            "|": backslash, ":": semicolon, "\"": quote, "<": comma,
            ">": period, "?": slash, "~": grave
        ]
        if let code = shiftedSymbolMap[char] {
            return (code, true)
        }
        return nil
    }
}
