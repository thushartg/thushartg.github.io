import Foundation

public enum FrameKind: UInt8, Sendable {
    case handshakeHello       = 0x01
    case handshakeClientAuth  = 0x02
    case handshakeHostAuth    = 0x03
    case handshakeReject      = 0x04

    case encryptedControl     = 0x10
    case encryptedVideo       = 0x20
    case encryptedAudio       = 0x21

    /// Sent by the internet relay server as informational room status.
    case relayNotice          = 0x30
}

public enum WireFrameError: Error, LocalizedError {
    case invalidMagic
    case unknownFrameKind(UInt8)
    case payloadTooLarge(UInt32)

    public var errorDescription: String? {
        switch self {
        case .invalidMagic:
            return "Invalid MacControl wire frame header."
        case .unknownFrameKind(let raw):
            return "Unknown frame kind 0x\(String(raw, radix: 16))."
        case .payloadTooLarge(let size):
            return "Frame payload (\(size) bytes) exceeds maximum allowed limit."
        }
    }
}

public struct WireFrame: Equatable, Sendable {
    public static let magic0: UInt8 = 0x4D // 'M'
    public static let magic1: UInt8 = 0x43 // 'C'
    public static let headerSize = 7
    public static let maxPayloadSize: UInt32 = 16 * 1024 * 1024 // 16 MB safety ceiling

    public let kind: FrameKind
    public let payload: Data

    public init(kind: FrameKind, payload: Data) {
        self.kind = kind
        self.payload = payload
    }

    public func serialize() -> Data {
        var out = Data()
        out.reserveCapacity(Self.headerSize + payload.count)
        out.append(Self.magic0)
        out.append(Self.magic1)
        out.append(kind.rawValue)
        out.appendUInt32BE(UInt32(payload.count))
        out.append(payload)
        return out
    }

    public static func deserializeSingle(_ data: Data) throws -> WireFrame {
        guard data.count >= headerSize else {
            throw WireFrameError.invalidMagic
        }
        let base = data.startIndex
        guard data[base] == magic0, data[base + 1] == magic1 else {
            throw WireFrameError.invalidMagic
        }
        let rawKind = data[base + 2]
        guard let kind = FrameKind(rawValue: rawKind) else {
            throw WireFrameError.unknownFrameKind(rawKind)
        }
        guard let len = data.readUInt32BE(at: base + 3) else {
            throw WireFrameError.invalidMagic
        }
        guard len <= maxPayloadSize else {
            throw WireFrameError.payloadTooLarge(len)
        }
        let payloadStart = base + headerSize
        let payloadEnd = payloadStart + Int(len)
        guard payloadEnd <= data.endIndex else {
            throw WireFrameError.invalidMagic
        }
        return WireFrame(kind: kind, payload: Data(data[payloadStart..<payloadEnd]))
    }
}

/// Incremental byte-stream parser for TCP connections where frames can coalesce or split across reads.
public final class WireStreamDeframer {
    private var buffer = Data()

    public init() {}

    public func reset() {
        buffer.removeAll(keepingCapacity: false)
    }

    public func push(_ chunk: Data) throws -> [WireFrame] {
        guard !chunk.isEmpty else { return [] }
        buffer.append(chunk)
        var frames: [WireFrame] = []

        while buffer.count >= WireFrame.headerSize {
            let base = buffer.startIndex
            guard buffer[base] == WireFrame.magic0,
                  buffer[base + 1] == WireFrame.magic1 else {
                throw WireFrameError.invalidMagic
            }
            let rawKind = buffer[base + 2]
            guard let kind = FrameKind(rawValue: rawKind) else {
                throw WireFrameError.unknownFrameKind(rawKind)
            }
            guard let payloadLen = buffer.readUInt32BE(at: base + 3) else {
                break
            }
            if payloadLen > WireFrame.maxPayloadSize {
                throw WireFrameError.payloadTooLarge(payloadLen)
            }
            let totalSize = WireFrame.headerSize + Int(payloadLen)
            guard buffer.count >= totalSize else {
                break
            }
            let pStart = base + WireFrame.headerSize
            let pEnd = pStart + Int(payloadLen)
            let payload = Data(buffer[pStart..<pEnd])
            frames.append(WireFrame(kind: kind, payload: payload))
            buffer.removeSubrange(base..<pEnd)
        }

        // Reclaim backing storage if buffer completely drained
        if buffer.isEmpty {
            buffer = Data()
        }
        return frames
    }
}
