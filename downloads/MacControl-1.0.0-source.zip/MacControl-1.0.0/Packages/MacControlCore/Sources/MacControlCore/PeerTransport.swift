import Foundation
import Network

public enum TransportState: Equatable, Sendable {
    case connecting
    case connected
    case disconnected(String?)
}

/// Unified transport interface implemented by both Direct TCP (`NWConnection` over LAN/USB/Tailscale)
/// and Internet Relay (`URLSessionWebSocketTask`).
public protocol WireTransport: AnyObject, Sendable {
    var descriptionLabel: String { get }
    var onStateChange: (@Sendable (TransportState) -> Void)? { get set }
    var onFrame: (@Sendable (WireFrame) -> Void)? { get set }

    func start()
    func send(_ frame: WireFrame, isDroppableMedia: Bool)
    func close()
}

// MARK: - Direct TCP Transport (Local Wi-Fi, Wired USB, Tailscale VPN)

public final class TCPWireTransport: WireTransport, @unchecked Sendable {
    public let connection: NWConnection
    public let descriptionLabel: String
    public var onStateChange: (@Sendable (TransportState) -> Void)?
    public var onFrame: (@Sendable (WireFrame) -> Void)?

    private let queue = DispatchQueue(label: "com.maccontrol.tcp.transport", qos: .userInteractive)
    private let deframer = WireStreamDeframer()
    private var inFlightVideoFrames = 0
    private let maxInFlightVideoFrames = 4
    private var isClosed = false

    public static func makeLowLatencyParameters() -> NWParameters {
        let tcpOptions = NWProtocolTCP.Options()
        tcpOptions.noDelay = true // Disable Nagle's algorithm for instant touch/keystroke delivery
        tcpOptions.enableKeepalive = true
        tcpOptions.keepaliveIdle = 10
        tcpOptions.keepaliveInterval = 5
        tcpOptions.keepaliveCount = 3
        let params = NWParameters(tls: nil, tcp: tcpOptions)
        params.serviceClass = .interactiveVideo
        params.includePeerToPeer = true
        return params
    }

    public init(connection: NWConnection, label: String) {
        self.connection = connection
        self.descriptionLabel = label
    }

    public convenience init(host: String, port: UInt16) {
        let nwHost = NWEndpoint.Host(host)
        let nwPort = NWEndpoint.Port(rawValue: port) ?? NWEndpoint.Port(integerLiteral: MacControlConstants.defaultPort)
        let conn = NWConnection(host: nwHost, port: nwPort, using: Self.makeLowLatencyParameters())
        self.init(connection: conn, label: "\(host):\(port)")
    }

    public convenience init(endpoint: NWEndpoint, label: String) {
        let conn = NWConnection(to: endpoint, using: Self.makeLowLatencyParameters())
        self.init(connection: conn, label: label)
    }

    public func start() {
        connection.stateUpdateHandler = { [weak self] state in
            guard let self, !self.isClosed else { return }
            switch state {
            case .preparing, .setup:
                self.onStateChange?(.connecting)
            case .ready:
                self.onStateChange?(.connected)
                self.receiveNextChunk()
            case .waiting:
                // Transient path transition (e.g. Wi-Fi roam or iOS background handoff); wait for recovery instead of tearing down
                self.onStateChange?(.connecting)
            case .failed(let err):
                self.isClosed = true
                self.onStateChange?(.disconnected(err.localizedDescription))
            case .cancelled:
                if !self.isClosed {
                    self.isClosed = true
                    self.onStateChange?(.disconnected(nil))
                }
            @unknown default:
                break
            }
        }
        connection.start(queue: queue)
    }

    public func send(_ frame: WireFrame, isDroppableMedia: Bool = false) {
        queue.async { [weak self] in
            guard let self, !self.isClosed else { return }
            if isDroppableMedia && self.inFlightVideoFrames >= self.maxInFlightVideoFrames {
                // Drop stale non-keyframe media packet rather than building latency queue
                return
            }
            if isDroppableMedia {
                self.inFlightVideoFrames += 1
            }
            let data = frame.serialize()
            self.connection.send(content: data, completion: .contentProcessed { [weak self] error in
                guard let self else { return }
                if isDroppableMedia {
                    self.inFlightVideoFrames = max(0, self.inFlightVideoFrames - 1)
                }
                if let error, !self.isClosed {
                    self.isClosed = true
                    self.connection.cancel()
                    self.onStateChange?(.disconnected(error.localizedDescription))
                }
            })
        }
    }

    public func close() {
        queue.async { [weak self] in
            guard let self, !self.isClosed else { return }
            self.isClosed = true
            self.deframer.reset()
            self.connection.cancel()
            self.onStateChange?(.disconnected(nil))
        }
    }

    private func receiveNextChunk() {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 262_144) { [weak self] content, _, isComplete, error in
            guard let self, !self.isClosed else { return }
            if let content, !content.isEmpty {
                do {
                    let frames = try self.deframer.push(content)
                    for frame in frames {
                        self.onFrame?(frame)
                    }
                } catch {
                    self.isClosed = true
                    self.connection.cancel()
                    self.onStateChange?(.disconnected(error.localizedDescription))
                    return
                }
            }
            if let error {
                self.isClosed = true
                self.connection.cancel()
                self.onStateChange?(.disconnected(error.localizedDescription))
                return
            }
            if isComplete {
                self.isClosed = true
                self.connection.cancel()
                self.onStateChange?(.disconnected(nil))
                return
            }
            self.receiveNextChunk()
        }
    }
}

// MARK: - WebSocket Relay Transport (Over-the-Internet NAT Traversal)

public struct RelayNoticePayload: Codable, Sendable {
    public let event: String
    public let peerConnected: Bool
    public let room: String?
}

public final class WebSocketRelayTransport: NSObject, WireTransport, URLSessionWebSocketDelegate, @unchecked Sendable {
    public let descriptionLabel: String
    public var onStateChange: (@Sendable (TransportState) -> Void)?
    public var onFrame: (@Sendable (WireFrame) -> Void)?
    public var onRelayEvent: (@Sendable (RelayNoticePayload) -> Void)?

    private let relayURL: URL
    private var session: URLSession?
    private var task: URLSessionWebSocketTask?
    private let lock = NSLock()
    private var inFlightMedia = 0
    private let maxInFlightMedia = 3
    private var isClosed = false
    private var pingTimer: DispatchSourceTimer?

    public init?(baseRelayURL: String, roomID: String, role: SessionRole) {
        let trimmedURL = baseRelayURL.trimmingCharacters(in: .whitespacesAndNewlines)
        let normalizedRoom = roomID.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmedURL.isEmpty, !normalizedRoom.isEmpty,
              var components = URLComponents(string: trimmedURL) else {
            return nil
        }
        if components.scheme == "http" { components.scheme = "ws" }
        if components.scheme == "https" { components.scheme = "wss" }
        if components.path.isEmpty || components.path == "/" {
            components.path = "/relay"
        }
        var items = components.queryItems ?? []
        items.append(URLQueryItem(name: "room", value: normalizedRoom))
        items.append(URLQueryItem(name: "role", value: role == .host ? "host" : "client"))
        components.queryItems = items
        guard let finalURL = components.url else { return nil }

        self.relayURL = finalURL
        self.descriptionLabel = "Relay (\(normalizedRoom))"
        super.init()
    }

    public func start() {
        onStateChange?(.connecting)
        let config = URLSessionConfiguration.default
        config.waitsForConnectivity = false
        let urlSession = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        let wsTask = urlSession.webSocketTask(with: relayURL)
        wsTask.maximumMessageSize = Int(WireFrame.maxPayloadSize) + 1024
        self.session = urlSession
        self.task = wsTask
        wsTask.resume()
        listenNextMessage()
        startKeepalivePings()
    }

    public func send(_ frame: WireFrame, isDroppableMedia: Bool = false) {
        lock.lock()
        if isClosed {
            lock.unlock()
            return
        }
        if isDroppableMedia && inFlightMedia >= maxInFlightMedia {
            lock.unlock()
            return
        }
        if isDroppableMedia {
            inFlightMedia += 1
        }
        let currentTask = task
        lock.unlock()

        let raw = frame.serialize()
        currentTask?.send(.data(raw)) { [weak self] error in
            guard let self else { return }
            self.lock.lock()
            if isDroppableMedia {
                self.inFlightMedia = max(0, self.inFlightMedia - 1)
            }
            let alreadyClosed = self.isClosed
            self.lock.unlock()
            if let error, !alreadyClosed {
                self.closeWithReason(error.localizedDescription)
            }
        }
    }

    public func close() {
        closeWithReason(nil)
    }

    private func closeWithReason(_ reason: String?) {
        lock.lock()
        guard !isClosed else {
            lock.unlock()
            return
        }
        isClosed = true
        pingTimer?.cancel()
        pingTimer = nil
        let currentTask = task
        let currentSession = session
        task = nil
        session = nil
        lock.unlock()

        currentTask?.cancel(with: .goingAway, reason: nil)
        currentSession?.invalidateAndCancel()
        onStateChange?(.disconnected(reason))
    }

    private func listenNextMessage() {
        lock.lock()
        let currentTask = task
        let closed = isClosed
        lock.unlock()
        guard !closed, let currentTask else { return }

        currentTask.receive { [weak self] result in
            guard let self else { return }
            switch result {
            case .success(let message):
                switch message {
                case .data(let data):
                    if let frame = try? WireFrame.deserializeSingle(data) {
                        if frame.kind == .relayNotice,
                           let notice = try? JSONDecoder().decode(RelayNoticePayload.self, from: frame.payload) {
                            self.onRelayEvent?(notice)
                        } else {
                            self.onFrame?(frame)
                        }
                    }
                case .string(let text):
                    if let textData = text.data(using: .utf8),
                       let notice = try? JSONDecoder().decode(RelayNoticePayload.self, from: textData) {
                        self.onRelayEvent?(notice)
                    }
                @unknown default:
                    break
                }
                self.listenNextMessage()
            case .failure(let error):
                self.closeWithReason(error.localizedDescription)
            }
        }
    }

    private func startKeepalivePings() {
        let timer = DispatchSource.makeTimerSource(queue: DispatchQueue.global(qos: .utility))
        timer.schedule(deadline: .now() + 15, repeating: 15)
        timer.setEventHandler { [weak self] in
            guard let self else { return }
            self.lock.lock()
            let currentTask = self.task
            let closed = self.isClosed
            self.lock.unlock()
            guard !closed else { return }
            currentTask?.sendPing { _ in }
        }
        lock.lock()
        pingTimer = timer
        lock.unlock()
        timer.resume()
    }

    public func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask, didOpenWithProtocol protocol: String?) {
        onStateChange?(.connected)
    }

    public func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask, didCloseWith closeCode: URLSessionWebSocketTask.CloseCode, reason: Data?) {
        let msg = reason.flatMap { String(data: $0, encoding: .utf8) }
        closeWithReason(msg)
    }

    public func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error {
            closeWithReason(error.localizedDescription)
        }
    }
}
