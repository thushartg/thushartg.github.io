import CryptoKit
import Foundation

public enum CryptoSessionError: Error, LocalizedError {
    case invalidPeerKey
    case authenticationFailed
    case replayOrOutOfOrder
    case malformedCiphertext

    public var errorDescription: String? {
        switch self {
        case .invalidPeerKey:
            return "Invalid peer cryptographic key during handshake."
        case .authenticationFailed:
            return "Pairing PIN mismatch or session authentication failed."
        case .replayOrOutOfOrder:
            return "Rejected replayed or tampered encrypted packet."
        case .malformedCiphertext:
            return "Encrypted packet could not be decoded."
        }
    }
}

public enum SessionRole: Sendable {
    case host
    case client
}

/// Performs X25519 ephemeral key agreement bound to the Pairing PIN via HKDF-SHA256,
/// mutual HMAC verification, and monotonic-nonce ChaCha20-Poly1305 AEAD encryption.
public final class HandshakeContext {
    public let role: SessionRole
    public let deviceName: String
    private let privateKey: Curve25519.KeyAgreement.PrivateKey
    public let localNonce: Data

    public init(role: SessionRole, deviceName: String) {
        self.role = role
        self.deviceName = deviceName
        self.privateKey = Curve25519.KeyAgreement.PrivateKey()
        var randomBytes = [UInt8](repeating: 0, count: 16)
        for idx in randomBytes.indices {
            randomBytes[idx] = UInt8.random(in: .min ... .max)
        }
        self.localNonce = Data(randomBytes)
    }

    public func makeHello() -> HandshakeHello {
        HandshakeHello(
            deviceName: deviceName,
            publicKeyBase64: privateKey.publicKey.rawRepresentation.base64EncodedString(),
            nonceBase64: localNonce.base64EncodedString()
        )
    }

    public func deriveKeys(peerHello: HandshakeHello, pin: String) throws -> DerivedHandshakeMaterial {
        guard let peerPubData = Data(base64Encoded: peerHello.publicKeyBase64),
              let peerNonce = Data(base64Encoded: peerHello.nonceBase64),
              peerNonce.count >= 8 else {
            throw CryptoSessionError.invalidPeerKey
        }
        let peerPubKey = try Curve25519.KeyAgreement.PublicKey(rawRepresentation: peerPubData)
        let sharedSecret = try privateKey.sharedSecretFromKeyAgreement(with: peerPubKey)

        let normalizedPIN = pin.trimmingCharacters(in: .whitespacesAndNewlines)
        let hostPub = role == .host ? privateKey.publicKey.rawRepresentation : peerPubData
        let clientPub = role == .client ? privateKey.publicKey.rawRepresentation : peerPubData
        let hostNonce = role == .host ? localNonce : peerNonce
        let clientNonce = role == .client ? localNonce : peerNonce

        // Transcript binds both public keys, both nonces, and the Pairing PIN salt
        var transcript = Data("MacControl-v1".utf8)
        transcript.append(hostPub)
        transcript.append(clientPub)
        transcript.append(hostNonce)
        transcript.append(clientNonce)

        let pinHash = Data(SHA256.hash(data: Data(("MacControlPIN:" + normalizedPIN).utf8)))
        var salt = Data()
        salt.append(pinHash)
        salt.append(hostNonce)
        salt.append(clientNonce)

        let clientToHostKey = sharedSecret.hkdfDerivedSymmetricKey(
            using: SHA256.self,
            salt: salt,
            sharedInfo: Data("c2h-aead".utf8) + transcript,
            outputByteCount: 32
        )
        let hostToClientKey = sharedSecret.hkdfDerivedSymmetricKey(
            using: SHA256.self,
            salt: salt,
            sharedInfo: Data("h2c-aead".utf8) + transcript,
            outputByteCount: 32
        )
        let authKey = sharedSecret.hkdfDerivedSymmetricKey(
            using: SHA256.self,
            salt: salt,
            sharedInfo: Data("handshake-auth".utf8) + transcript,
            outputByteCount: 32
        )

        let clientProofData = Data(HMAC<SHA256>.authenticationCode(
            for: Data("client-verified".utf8) + transcript,
            using: authKey
        ))
        let hostProofData = Data(HMAC<SHA256>.authenticationCode(
            for: Data("host-verified".utf8) + transcript,
            using: authKey
        ))

        return DerivedHandshakeMaterial(
            role: role,
            peerDeviceName: peerHello.deviceName,
            clientToHostKey: clientToHostKey,
            hostToClientKey: hostToClientKey,
            clientProof: clientProofData,
            hostProof: hostProofData
        )
    }
}

public struct DerivedHandshakeMaterial {
    public let role: SessionRole
    public let peerDeviceName: String
    public let clientToHostKey: SymmetricKey
    public let hostToClientKey: SymmetricKey
    public let clientProof: Data
    public let hostProof: Data

    public func myAuthProof() -> HandshakeAuthProof {
        let data = role == .client ? clientProof : hostProof
        return HandshakeAuthProof(hmacBase64: data.base64EncodedString())
    }

    public func verifyPeerProof(_ proof: HandshakeAuthProof) -> Bool {
        guard let provided = Data(base64Encoded: proof.hmacBase64) else { return false }
        let expected = role == .client ? hostProof : clientProof
        guard provided.count == expected.count else { return false }
        var diff: UInt8 = 0
        for idx in 0..<expected.count {
            diff |= provided[idx] ^ expected[idx]
        }
        return diff == 0
    }

    public func buildCryptoSession() -> CryptoSession {
        switch role {
        case .host:
            return CryptoSession(sendKey: hostToClientKey, receiveKey: clientToHostKey, directionPrefix: 0x01, peerDirectionPrefix: 0x02)
        case .client:
            return CryptoSession(sendKey: clientToHostKey, receiveKey: hostToClientKey, directionPrefix: 0x02, peerDirectionPrefix: 0x01)
        }
    }
}

/// Thread-safe ChaCha20-Poly1305 AEAD encryptor/decryptor with monotonic 64-bit sequence numbers
/// and sliding-window replay protection (safe across packet drops on relay backpressure).
public final class CryptoSession: @unchecked Sendable {
    private let sendKey: SymmetricKey
    private let receiveKey: SymmetricKey
    private let directionPrefix: UInt8
    private let peerDirectionPrefix: UInt8

    private let lock = NSLock()
    private var nextSendSeq: UInt64 = 1
    private var highestRecvSeq: UInt64 = 0
    private var replayBitmap: UInt64 = 0

    public init(sendKey: SymmetricKey, receiveKey: SymmetricKey, directionPrefix: UInt8, peerDirectionPrefix: UInt8) {
        self.sendKey = sendKey
        self.receiveKey = receiveKey
        self.directionPrefix = directionPrefix
        self.peerDirectionPrefix = peerDirectionPrefix
    }

    /// Envelope layout: [seq: UInt64 BE (8 bytes)] [ciphertext + 16-byte Poly1305 tag]
    public func seal(_ plaintext: Data, associatedKind: FrameKind) throws -> Data {
        lock.lock()
        let seq = nextSendSeq
        nextSendSeq &+= 1
        lock.unlock()

        let nonce = try Self.makeNonce(prefix: directionPrefix, seq: seq)
        let aad = Data([associatedKind.rawValue])
        let sealedBox = try ChaChaPoly.seal(plaintext, using: sendKey, nonce: nonce, authenticating: aad)

        var out = Data()
        out.reserveCapacity(8 + sealedBox.ciphertext.count + sealedBox.tag.count)
        out.appendUInt64BE(seq)
        out.append(sealedBox.ciphertext)
        out.append(sealedBox.tag)
        return out
    }

    public func open(_ envelope: Data, associatedKind: FrameKind) throws -> Data {
        // 8 bytes seq + 16 bytes tag minimum
        guard envelope.count >= 24 else {
            throw CryptoSessionError.malformedCiphertext
        }
        let base = envelope.startIndex
        guard let seq = envelope.readUInt64BE(at: base), seq > 0 else {
            throw CryptoSessionError.malformedCiphertext
        }

        // Pre-check replay window before expensive verification
        lock.lock()
        let allowed = isSequenceCandidateAllowedLocked(seq)
        lock.unlock()
        guard allowed else {
            throw CryptoSessionError.replayOrOutOfOrder
        }

        let nonce = try Self.makeNonce(prefix: peerDirectionPrefix, seq: seq)
        let ciphertextEnd = envelope.endIndex - 16
        let ciphertext = envelope[(base + 8)..<ciphertextEnd]
        let tag = envelope[ciphertextEnd..<envelope.endIndex]
        let sealedBox = try ChaChaPoly.SealedBox(nonce: nonce, ciphertext: ciphertext, tag: tag)
        let aad = Data([associatedKind.rawValue])
        let plaintext = try ChaChaPoly.open(sealedBox, using: receiveKey, authenticating: aad)

        // Commit sequence number in sliding window only after tag authenticates
        lock.lock()
        let committed = commitSequenceLocked(seq)
        lock.unlock()
        guard committed else {
            throw CryptoSessionError.replayOrOutOfOrder
        }
        return plaintext
    }

    private func isSequenceCandidateAllowedLocked(_ seq: UInt64) -> Bool {
        if seq > highestRecvSeq {
            return true
        }
        let delta = highestRecvSeq - seq
        if delta >= 64 {
            return false
        }
        let mask: UInt64 = 1 << delta
        return (replayBitmap & mask) == 0
    }

    private func commitSequenceLocked(_ seq: UInt64) -> Bool {
        if seq > highestRecvSeq {
            let shift = seq - highestRecvSeq
            if shift >= 64 {
                replayBitmap = 1
            } else {
                replayBitmap = (replayBitmap << shift) | 1
            }
            highestRecvSeq = seq
            return true
        } else {
            let delta = highestRecvSeq - seq
            if delta >= 64 {
                return false
            }
            let mask: UInt64 = 1 << delta
            if (replayBitmap & mask) != 0 {
                return false
            }
            replayBitmap |= mask
            return true
        }
    }

    private static func makeNonce(prefix: UInt8, seq: UInt64) throws -> ChaChaPoly.Nonce {
        var bytes = [UInt8](repeating: 0, count: 12)
        bytes[0] = prefix
        var be = seq.bigEndian
        Swift.withUnsafeBytes(of: &be) { raw in
            for idx in 0..<8 {
                bytes[4 + idx] = raw[idx]
            }
        }
        return try ChaChaPoly.Nonce(data: Data(bytes))
    }
}
