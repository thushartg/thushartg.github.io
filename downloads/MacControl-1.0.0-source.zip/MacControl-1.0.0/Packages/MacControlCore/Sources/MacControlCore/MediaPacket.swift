import Foundation

/// Compact zero-copy binary framing for hardware-encoded H.264 / HEVC video frames.
/// Binary layout:
///   [0]      codec: UInt8 (1 = H.264, 2 = HEVC)
///   [1]      flags: UInt8 (bit 0 = isKeyframe)
///   [2..3]   width: UInt16 BE
///   [4..5]   height: UInt16 BE
///   [6..13]  timestampUs: UInt64 BE
///   [14]     parameterSetCount: UInt8
///   For each parameter set:
///     [len: UInt16 BE] [bytes...]
///   Remaining bytes: AVCC / HVCC length-prefixed NALU buffer (4-byte BE length prefixes, directly usable in CMBlockBuffer).
public struct VideoFramePacket: Equatable, Sendable {
    public let codec: VideoCodecKind
    public let isKeyframe: Bool
    public let width: UInt16
    public let height: UInt16
    public let timestampUs: UInt64
    public let parameterSets: [Data]
    public let avccData: Data

    public init(
        codec: VideoCodecKind,
        isKeyframe: Bool,
        width: UInt16,
        height: UInt16,
        timestampUs: UInt64,
        parameterSets: [Data],
        avccData: Data
    ) {
        self.codec = codec
        self.isKeyframe = isKeyframe
        self.width = width
        self.height = height
        self.timestampUs = timestampUs
        self.parameterSets = parameterSets
        self.avccData = avccData
    }

    public func encode() -> Data {
        var paramBytes = 0
        for ps in parameterSets {
            paramBytes += 2 + ps.count
        }
        var out = Data()
        out.reserveCapacity(15 + paramBytes + avccData.count)
        out.append(codec.rawValue)
        out.append(isKeyframe ? 0x01 : 0x00)
        out.appendUInt16BE(width)
        out.appendUInt16BE(height)
        out.appendUInt64BE(timestampUs)
        out.append(UInt8(min(parameterSets.count, 16)))
        for ps in parameterSets.prefix(16) {
            out.appendUInt16BE(UInt16(ps.count))
            out.append(ps)
        }
        out.append(avccData)
        return out
    }

    public static func decode(from data: Data) -> VideoFramePacket? {
        guard data.count >= 15 else { return nil }
        let base = data.startIndex
        guard let codec = VideoCodecKind(rawValue: data[base]) else { return nil }
        let isKeyframe = (data[base + 1] & 0x01) != 0
        guard let width = data.readUInt16BE(at: base + 2),
              let height = data.readUInt16BE(at: base + 4),
              let timestampUs = data.readUInt64BE(at: base + 6) else {
            return nil
        }
        let psCount = Int(data[base + 14])
        var cursor = base + 15
        var parameterSets: [Data] = []
        parameterSets.reserveCapacity(psCount)
        for _ in 0..<psCount {
            guard let psLen = data.readUInt16BE(at: cursor) else { return nil }
            cursor += 2
            let len = Int(psLen)
            guard cursor + len <= data.endIndex else { return nil }
            parameterSets.append(Data(data[cursor..<(cursor + len)]))
            cursor += len
        }
        let avccData = Data(data[cursor..<data.endIndex])
        return VideoFramePacket(
            codec: codec,
            isKeyframe: isKeyframe,
            width: width,
            height: height,
            timestampUs: timestampUs,
            parameterSets: parameterSets,
            avccData: avccData
        )
    }
}

/// Compact binary framing for low-latency Int16 interleaved PCM audio chunks.
/// Binary layout:
///   [0..3]   sampleRate: UInt32 BE
///   [4]      channels: UInt8
///   [5..12]  timestampUs: UInt64 BE
///   [13..]   Int16 little-endian interleaved PCM samples
public struct AudioFramePacket: Equatable, Sendable {
    public let sampleRate: UInt32
    public let channels: UInt8
    public let timestampUs: UInt64
    public let pcmInt16Data: Data

    public init(sampleRate: UInt32, channels: UInt8, timestampUs: UInt64, pcmInt16Data: Data) {
        self.sampleRate = sampleRate
        self.channels = channels
        self.timestampUs = timestampUs
        self.pcmInt16Data = pcmInt16Data
    }

    public func encode() -> Data {
        var out = Data()
        out.reserveCapacity(13 + pcmInt16Data.count)
        out.appendUInt32BE(sampleRate)
        out.append(channels)
        out.appendUInt64BE(timestampUs)
        out.append(pcmInt16Data)
        return out
    }

    public static func decode(from data: Data) -> AudioFramePacket? {
        guard data.count >= 13 else { return nil }
        let base = data.startIndex
        guard let sampleRate = data.readUInt32BE(at: base),
              let timestampUs = data.readUInt64BE(at: base + 5) else {
            return nil
        }
        let channels = data[base + 4]
        let pcm = Data(data[(base + 13)..<data.endIndex])
        return AudioFramePacket(
            sampleRate: sampleRate,
            channels: channels,
            timestampUs: timestampUs,
            pcmInt16Data: pcm
        )
    }
}

// MARK: - Binary Helpers

extension Data {
    public mutating func appendUInt16BE(_ value: UInt16) {
        var be = value.bigEndian
        Swift.withUnsafeBytes(of: &be) { append(contentsOf: $0) }
    }

    public mutating func appendUInt32BE(_ value: UInt32) {
        var be = value.bigEndian
        Swift.withUnsafeBytes(of: &be) { append(contentsOf: $0) }
    }

    public mutating func appendUInt64BE(_ value: UInt64) {
        var be = value.bigEndian
        Swift.withUnsafeBytes(of: &be) { append(contentsOf: $0) }
    }

    public func readUInt16BE(at index: Int) -> UInt16? {
        guard index + 2 <= endIndex else { return nil }
        return (UInt16(self[index]) << 8) | UInt16(self[index + 1])
    }

    public func readUInt32BE(at index: Int) -> UInt32? {
        guard index + 4 <= endIndex else { return nil }
        return (UInt32(self[index]) << 24)
            | (UInt32(self[index + 1]) << 16)
            | (UInt32(self[index + 2]) << 8)
            | UInt32(self[index + 3])
    }

    public func readUInt64BE(at index: Int) -> UInt64? {
        guard index + 8 <= endIndex else { return nil }
        var result: UInt64 = 0
        for offset in 0..<8 {
            result = (result << 8) | UInt64(self[index + offset])
        }
        return result
    }
}
