#!/usr/bin/env node
'use strict';

/**
 * MacControl Zero-Knowledge Over-the-Internet Relay Server
 * - Pure Node.js standard library (zero npm dependencies required)
 * - RFC 6455 compliant WebSocket binary & text framing
 * - Forwards E2E-encrypted MacControl WireFrames between `role=host` and `role=client` in the same room
 * - Smart media backpressure: prioritizes control/handshake packets if a cellular link congests
 */

const http = require('node:http');
const crypto = require('node:crypto');
const { URL } = require('node:url');

const PORT = Number(process.env.PORT || 8787);
const MAX_FRAME_BYTES = 18 * 1024 * 1024; // 18 MB ceiling
const MEDIA_BACKPRESSURE_BYTES = 768 * 1024; // Drop queued media frames above 768 KB socket buffer
const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

/** @type {Map<string, { host: PeerConnection | null, client: PeerConnection | null }>} */
const rooms = new Map();

class PeerConnection {
  constructor(socket, room, role) {
    this.socket = socket;
    this.room = room;
    this.role = role;
    this.recvBuffer = Buffer.alloc(0);
    this.fragmentOpcode = 0;
    this.fragments = [];
    this.fragmentBytes = 0;
    this.closed = false;
  }

  pushData(chunk) {
    if (this.closed || chunk.length === 0) return;
    this.recvBuffer = this.recvBuffer.length === 0 ? chunk : Buffer.concat([this.recvBuffer, chunk]);

    while (this.recvBuffer.length >= 2) {
      const b0 = this.recvBuffer[0];
      const b1 = this.recvBuffer[1];
      const fin = (b0 & 0x80) !== 0;
      const opcode = b0 & 0x0f;
      const masked = (b1 & 0x80) !== 0;
      let payloadLen = b1 & 0x7f;
      let offset = 2;

      if (payloadLen === 126) {
        if (this.recvBuffer.length < 4) return;
        payloadLen = this.recvBuffer.readUInt16BE(2);
        offset = 4;
      } else if (payloadLen === 127) {
        if (this.recvBuffer.length < 10) return;
        const bigLen = this.recvBuffer.readBigUInt64BE(2);
        if (bigLen > BigInt(MAX_FRAME_BYTES)) {
          this.close(1009, 'Frame too large');
          return;
        }
        payloadLen = Number(bigLen);
        offset = 10;
      }

      if (payloadLen > MAX_FRAME_BYTES) {
        this.close(1009, 'Frame too large');
        return;
      }

      const maskLen = masked ? 4 : 0;
      const totalFrameLen = offset + maskLen + payloadLen;
      if (this.recvBuffer.length < totalFrameLen) return;

      const payload = Buffer.from(this.recvBuffer.subarray(offset + maskLen, totalFrameLen));
      if (masked) {
        const maskKey = this.recvBuffer.subarray(offset, offset + 4);
        for (let i = 0; i < payload.length; i++) {
          payload[i] ^= maskKey[i & 3];
        }
      }
      this.recvBuffer = this.recvBuffer.subarray(totalFrameLen);
      this.handleFrame(fin, opcode, payload);
      if (this.closed) return;
    }
  }

  handleFrame(fin, opcode, payload) {
    // Control opcodes (can arrive mid-fragmentation)
    if (opcode === 0x08) {
      this.close(1000, 'Normal closure');
      return;
    }
    if (opcode === 0x09) {
      this.sendRawFrame(0x0a, payload); // Pong
      return;
    }
    if (opcode === 0x0a) {
      return; // Pong received
    }

    // Data frames (text 0x01, binary 0x02, continuation 0x00)
    if (opcode === 0x01 || opcode === 0x02) {
      if (fin) {
        this.onCompleteMessage(opcode, payload);
      } else {
        this.fragmentOpcode = opcode;
        this.fragments = [payload];
        this.fragmentBytes = payload.length;
      }
    } else if (opcode === 0x00 && this.fragmentOpcode !== 0) {
      this.fragmentBytes += payload.length;
      if (this.fragmentBytes > MAX_FRAME_BYTES) {
        this.close(1009, 'Fragmented message too large');
        return;
      }
      this.fragments.push(payload);
      if (fin) {
        const full = Buffer.concat(this.fragments, this.fragmentBytes);
        const origOpcode = this.fragmentOpcode;
        this.fragmentOpcode = 0;
        this.fragments = [];
        this.fragmentBytes = 0;
        this.onCompleteMessage(origOpcode, full);
      }
    }
  }

  onCompleteMessage(opcode, data) {
    const entry = rooms.get(this.room);
    if (!entry) return;
    const peer = this.role === 'host' ? entry.client : entry.host;
    if (!peer || peer.closed) return;

    // Backpressure guard for encrypted video (0x20) & audio (0x21) WireFrames ('MC' magic = 0x4D 0x43)
    if (opcode === 0x02 && data.length >= 7 && data[0] === 0x4d && data[1] === 0x43) {
      const frameKind = data[2];
      const isMedia = frameKind === 0x20 || frameKind === 0x21;
      if (isMedia && peer.socket.writableLength > MEDIA_BACKPRESSURE_BYTES) {
        return;
      }
    }

    peer.sendRawFrame(opcode, data);
  }

  sendNotice(event, peerConnected) {
    const json = JSON.stringify({
      event,
      peerConnected,
      room: this.room,
    });
    this.sendRawFrame(0x01, Buffer.from(json, 'utf8'));
  }

  sendRawFrame(opcode, payload) {
    if (this.closed || this.socket.destroyed) return;
    const len = payload.length;
    let header;
    if (len < 126) {
      header = Buffer.allocUnsafe(2);
      header[0] = 0x80 | opcode;
      header[1] = len;
    } else if (len < 65536) {
      header = Buffer.allocUnsafe(4);
      header[0] = 0x80 | opcode;
      header[1] = 126;
      header.writeUInt16BE(len, 2);
    } else {
      header = Buffer.allocUnsafe(10);
      header[0] = 0x80 | opcode;
      header[1] = 127;
      header.writeBigUInt64BE(BigInt(len), 2);
    }
    this.socket.write(header);
    if (len > 0) {
      this.socket.write(payload);
    }
  }

  close(code = 1000, reason = '') {
    if (this.closed) return;
    this.closed = true;
    try {
      const reasonBuf = Buffer.from(reason.slice(0, 80), 'utf8');
      const closePayload = Buffer.allocUnsafe(2 + reasonBuf.length);
      closePayload.writeUInt16BE(code, 0);
      reasonBuf.copy(closePayload, 2);
      const header = Buffer.from([0x88, closePayload.length]);
      this.socket.write(Buffer.concat([header, closePayload]));
    } catch (_) {
      // Ignore write errors during shutdown
    }
    this.socket.destroy();
  }
}

function createRelayServer() {
  const server = http.createServer((req, res) => {
    if (req.url === '/health' || req.url === '/') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        service: 'MacControl E2E Relay',
        status: 'ok',
        activeRooms: rooms.size,
      }));
      return;
    }
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found. Connect via WebSocket to /relay?room=ROOM_ID&role=host|client');
  });

  server.on('upgrade', (req, socket, head) => {
    const parsed = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const room = (parsed.searchParams.get('room') || '').trim().toUpperCase();
    const role = (parsed.searchParams.get('role') || '').trim().toLowerCase();
    const wsKey = req.headers['sec-websocket-key'];

    if (!wsKey || !room || room.length > 64 || (role !== 'host' && role !== 'client')) {
      socket.write('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
      socket.destroy();
      return;
    }

    const acceptKey = crypto
      .createHash('sha1')
      .update(wsKey + WS_GUID)
      .digest('base64');

    socket.setNoDelay(true);
    socket.write(
      'HTTP/1.1 101 Switching Protocols\r\n' +
      'Upgrade: websocket\r\n' +
      'Connection: Upgrade\r\n' +
      `Sec-WebSocket-Accept: ${acceptKey}\r\n\r\n`
    );

    const peer = new PeerConnection(socket, room, role);
    let entry = rooms.get(room);
    if (!entry) {
      entry = { host: null, client: null };
      rooms.set(room, entry);
    }

    // Replace stale connection of the same role if reconnecting
    if (entry[role] && entry[role] !== peer) {
      entry[role].close(1000, 'Replaced by newer connection');
    }
    entry[role] = peer;

    const counterpart = role === 'host' ? entry.client : entry.host;
    const bothPresent = Boolean(counterpart && !counterpart.closed);
    peer.sendNotice('joined', bothPresent);
    if (bothPresent) {
      counterpart.sendNotice('peer_joined', true);
    }

    const cleanup = () => {
      peer.closed = true;
      const current = rooms.get(room);
      if (!current) return;
      if (current[role] === peer) {
        current[role] = null;
        const other = role === 'host' ? current.client : current.host;
        if (other && !other.closed) {
          other.sendNotice('peer_left', false);
        }
      }
      if (!current.host && !current.client) {
        rooms.delete(room);
      }
    };

    socket.on('data', (chunk) => peer.pushData(chunk));
    socket.on('close', cleanup);
    socket.on('end', cleanup);
    socket.on('error', cleanup);

    if (head && head.length > 0) {
      peer.pushData(head);
    }
  });

  // Periodic keepalive ping every 25s
  const pingInterval = setInterval(() => {
    for (const entry of rooms.values()) {
      if (entry.host && !entry.host.closed) entry.host.sendRawFrame(0x09, Buffer.alloc(0));
      if (entry.client && !entry.client.closed) entry.client.sendRawFrame(0x09, Buffer.alloc(0));
    }
  }, 25_000);
  pingInterval.unref();

  return server;
}

if (require.main === module) {
  const server = createRelayServer();
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[MacControl Relay] Listening on ws://0.0.0.0:${PORT}/relay (Health: http://0.0.0.0:${PORT}/health)`);
  });
}

module.exports = { createRelayServer };
