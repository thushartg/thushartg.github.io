'use strict';

const assert = require('node:assert');
const { createRelayServer } = require('./server');

async function runRelayIntegrationTest() {
  const server = createRelayServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();

  try {
    // 1. Verify health check endpoint
    const healthRes = await fetch(`http://127.0.0.1:${port}/health`);
    assert.strictEqual(healthRes.status, 200);
    const healthJson = await healthRes.json();
    assert.strictEqual(healthJson.status, 'ok');

    // 2. Connect Host & Client WebSockets to same room and verify peer discovery + binary WireFrame relay
    const room = 'MAC-TEST-9001';
    const hostWS = new WebSocket(`ws://127.0.0.1:${port}/relay?room=${room}&role=host`);
    hostWS.binaryType = 'arraybuffer';

    const hostNotices = [];
    const hostBinaryFrames = [];

    await new Promise((resolve, reject) => {
      hostWS.onmessage = (ev) => {
        if (typeof ev.data === 'string') {
          const parsed = JSON.parse(ev.data);
          hostNotices.push(parsed);
          if (hostNotices.length === 1) resolve();
        } else {
          hostBinaryFrames.push(Buffer.from(ev.data));
        }
      };
      hostWS.onerror = reject;
    });

    assert.strictEqual(hostNotices[0].peerConnected, false);

    const clientWS = new WebSocket(`ws://127.0.0.1:${port}/relay?room=${room}&role=client`);
    clientWS.binaryType = 'arraybuffer';

    const clientBinaryFrames = [];
    await new Promise((resolve, reject) => {
      clientWS.onmessage = (ev) => {
        if (typeof ev.data === 'string') {
          const parsed = JSON.parse(ev.data);
          if (parsed.peerConnected === true) resolve();
        } else {
          clientBinaryFrames.push(Buffer.from(ev.data));
        }
      };
      clientWS.onerror = reject;
    });

    // Send simulated encrypted control WireFrame ('M','C', 0x10, len=5, payload) Client -> Host
    const controlWireFrame = Buffer.from([0x4d, 0x43, 0x10, 0x00, 0x00, 0x00, 0x05, 1, 2, 3, 4, 5]);
    clientWS.send(controlWireFrame);

    // Send simulated 70 KB keyframe WireFrame ('M','C', 0x20, ...) Host -> Client (tests >64KB extended length framing!)
    const bigPayload = Buffer.alloc(70_000, 0xab);
    const header = Buffer.alloc(7);
    header[0] = 0x4d;
    header[1] = 0x43;
    header[2] = 0x20;
    header.writeUInt32BE(bigPayload.length, 3);
    const bigVideoFrame = Buffer.concat([header, bigPayload]);
    hostWS.send(bigVideoFrame);

    await new Promise((resolve) => {
      const check = setInterval(() => {
        if (hostBinaryFrames.length >= 1 && clientBinaryFrames.length >= 1) {
          clearInterval(check);
          resolve();
        }
      }, 10);
    });

    assert.deepStrictEqual(hostBinaryFrames[0], controlWireFrame);
    assert.deepStrictEqual(clientBinaryFrames[0], bigVideoFrame);

    hostWS.close();
    clientWS.close();
    console.log('PASS: Relay health, room pairing notices, and 70KB binary WireFrame forwarding verified.');
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
}

runRelayIntegrationTest().catch((err) => {
  console.error('Relay test failed:', err);
  process.exit(1);
});
