import MacControlCore
import SwiftUI
import UIKit

struct TrackpadModeView: View {
    @ObservedObject var session: ClientSession
    @State private var isDragLocked = false
    @State private var sensitivity: Double = 1.35

    var body: some View {
        VStack(spacing: 12) {
            // Top Trackpad Controls Bar
            HStack(spacing: 12) {
                Button {
                    UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
                    isDragLocked.toggle()
                    if !isDragLocked {
                        session.sendTrackpadDelta(dx: 0, dy: 0, isDragging: false)
                    }
                } label: {
                    Label(isDragLocked ? "Drag Locked" : "Drag Lock", systemImage: isDragLocked ? "hand.draw.fill" : "hand.draw")
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(isDragLocked ? Color.orange : Color.white.opacity(0.1), in: Capsule())
                        .foregroundStyle(isDragLocked ? .black : .white)
                }

                Spacer()

                HStack(spacing: 6) {
                    Image(systemName: "tortoise")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    Slider(value: $sensitivity, in: 0.6...2.6)
                        .frame(width: 110)
                    Image(systemName: "hare")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)

            // Main Magic Trackpad Surface
            ZStack {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [Color(white: 0.14), Color(white: 0.09)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .strokeBorder(isDragLocked ? Color.orange.opacity(0.8) : Color.white.opacity(0.12), lineWidth: 1.5)
                    )

                VStack(spacing: 6) {
                    Image(systemName: "hand.point.up.braille")
                        .font(.system(size: 28))
                        .foregroundStyle(.white.opacity(0.14))
                    Text("1-Finger Move & Tap • 2-Finger Scroll & Right-Click")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.25))
                }
                .allowsHitTesting(false)

                MagicTrackpadSurfaceRepresentable(
                    sensitivity: sensitivity,
                    isDragLocked: isDragLocked,
                    onMove: { dx, dy in
                        session.sendTrackpadDelta(dx: dx, dy: dy, isDragging: isDragLocked)
                    },
                    onClick: { button, count in
                        UIImpactFeedbackGenerator(style: button == .right ? .medium : .light).impactOccurred()
                        if isDragLocked && button == .left {
                            isDragLocked = false
                            session.sendTrackpadDelta(dx: 0, dy: 0, isDragging: false)
                        } else {
                            session.sendTrackpadClick(button: button, clickCount: count)
                        }
                    },
                    onScroll: { dx, dy, phase in
                        session.sendScroll(dx: dx, dy: dy, phase: phase)
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
            }
            .padding(.horizontal, 14)

            // Physical-style Left / Middle / Right Click Bar
            HStack(spacing: 10) {
                trackpadButton(title: "Left Click", subtitle: "Primary") {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    session.sendTrackpadClick(button: .left, clickCount: 1)
                }

                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    session.triggerSystem(.missionControl)
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "rectangle.3.group")
                            .font(.subheadline.weight(.semibold))
                        Text("Spaces")
                            .font(.system(size: 10, weight: .medium))
                    }
                    .frame(width: 72, height: 52)
                    .background(Color.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .foregroundStyle(.white)
                }

                trackpadButton(title: "Right Click", subtitle: "Secondary") {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    session.sendTrackpadClick(button: .right, clickCount: 1)
                }
            }
            .padding(.horizontal, 14)
            .padding(.bottom, 10)
        }
        .background(Color.black.ignoresSafeArea())
    }

    private func trackpadButton(title: String, subtitle: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 2) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                Text(subtitle)
                    .font(.system(size: 10))
                    .foregroundStyle(.white.opacity(0.55))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .background(Color.white.opacity(0.11), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .foregroundStyle(.white)
        }
    }
}

private struct MagicTrackpadSurfaceRepresentable: UIViewRepresentable {
    var sensitivity: Double
    var isDragLocked: Bool
    var onMove: (Double, Double) -> Void
    var onClick: (MouseButton, Int) -> Void
    var onScroll: (Double, Double, MacControlCore.ScrollPhase) -> Void

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        view.isMultipleTouchEnabled = true
        context.coordinator.attach(to: view)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        context.coordinator.parent = self
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    final class Coordinator: NSObject {
        var parent: MagicTrackpadSurfaceRepresentable

        init(parent: MagicTrackpadSurfaceRepresentable) {
            self.parent = parent
        }

        func attach(to view: UIView) {
            let singleTap = UITapGestureRecognizer(target: self, action: #selector(onSingleTap(_:)))
            singleTap.numberOfTapsRequired = 1
            singleTap.numberOfTouchesRequired = 1

            let doubleTap = UITapGestureRecognizer(target: self, action: #selector(onDoubleTap(_:)))
            doubleTap.numberOfTapsRequired = 2
            doubleTap.numberOfTouchesRequired = 1

            let twoFingerTap = UITapGestureRecognizer(target: self, action: #selector(onTwoFingerTap(_:)))
            twoFingerTap.numberOfTapsRequired = 1
            twoFingerTap.numberOfTouchesRequired = 2

            let oneFingerPan = UIPanGestureRecognizer(target: self, action: #selector(onOneFingerPan(_:)))
            oneFingerPan.minimumNumberOfTouches = 1
            oneFingerPan.maximumNumberOfTouches = 1

            let twoFingerPan = UIPanGestureRecognizer(target: self, action: #selector(onTwoFingerPan(_:)))
            twoFingerPan.minimumNumberOfTouches = 2
            twoFingerPan.maximumNumberOfTouches = 2

            view.addGestureRecognizer(singleTap)
            view.addGestureRecognizer(doubleTap)
            view.addGestureRecognizer(twoFingerTap)
            view.addGestureRecognizer(oneFingerPan)
            view.addGestureRecognizer(twoFingerPan)
        }

        @objc private func onSingleTap(_ gr: UITapGestureRecognizer) {
            if gr.state == .ended {
                parent.onClick(.left, 1)
            }
        }

        @objc private func onDoubleTap(_ gr: UITapGestureRecognizer) {
            if gr.state == .ended {
                parent.onClick(.left, 2)
            }
        }

        @objc private func onTwoFingerTap(_ gr: UITapGestureRecognizer) {
            if gr.state == .ended {
                parent.onClick(.right, 1)
            }
        }

        @objc private func onOneFingerPan(_ gr: UIPanGestureRecognizer) {
            guard let v = gr.view, gr.state == .changed else { return }
            let delta = gr.translation(in: v)
            gr.setTranslation(.zero, in: v)
            let gain = parent.sensitivity
            parent.onMove(Double(delta.x) * gain, Double(delta.y) * gain)
        }

        @objc private func onTwoFingerPan(_ gr: UIPanGestureRecognizer) {
            guard let v = gr.view else { return }
            let delta = gr.translation(in: v)
            gr.setTranslation(.zero, in: v)
            let phase: MacControlCore.ScrollPhase
            switch gr.state {
            case .began: phase = .began
            case .changed: phase = .changed
            default: phase = .ended
            }
            parent.onScroll(Double(delta.x * 1.6), Double(delta.y * 1.6), phase)
        }
    }
}
