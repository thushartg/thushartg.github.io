import MacControlCore
import SwiftUI
import UIKit

struct MacKeyboardBar: View {
    @ObservedObject var session: ClientSession
    @Binding var isKeyboardFocused: Bool
    @State private var showFunctionRow = false

    var body: some View {
        VStack(spacing: 6) {
            // Invisible UIKeyInput responder to capture iOS software keyboard, dictation & swipe typing
            KeyCaptureViewRepresentable(
                isFirstResponder: $isKeyboardFocused,
                onInsertText: { text in
                    session.sendTypedText(text)
                },
                onDeleteBackward: {
                    session.sendSpecialKey(MacKeyCode.delete)
                }
            )
            .frame(width: 1, height: 1)
            .opacity(0.01)

            if showFunctionRow {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        fnButton("F1", code: MacKeyCode.f1)
                        fnButton("F2", code: MacKeyCode.f2)
                        fnButton("F3", code: MacKeyCode.f3)
                        fnButton("F4", code: MacKeyCode.f4)
                        fnButton("F5", code: MacKeyCode.f5)
                        fnButton("F6", code: MacKeyCode.f6)
                        fnButton("F7", code: MacKeyCode.f7)
                        fnButton("F8", code: MacKeyCode.f8)
                        fnButton("F9", code: MacKeyCode.f9)
                        fnButton("F10", code: MacKeyCode.f10)
                        fnButton("F11", code: MacKeyCode.f11)
                        fnButton("F12", code: MacKeyCode.f12)
                    }
                    .padding(.horizontal, 10)
                }
            }

            // Primary Mac Modifiers, Navigation & Pro Shortcuts Strip
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    keyCap("esc") { session.sendSpecialKey(MacKeyCode.escape) }
                    keyCap("⇥") { session.sendSpecialKey(MacKeyCode.tab) }

                    modifierCap("⌘", mod: .command)
                    modifierCap("⌥", mod: .option)
                    modifierCap("⌃", mod: .control)
                    modifierCap("⇧", mod: .shift)

                    Divider().frame(height: 22)

                    keyCap("←") { session.sendSpecialKey(MacKeyCode.leftArrow) }
                    keyCap("↓") { session.sendSpecialKey(MacKeyCode.downArrow) }
                    keyCap("↑") { session.sendSpecialKey(MacKeyCode.upArrow) }
                    keyCap("→") { session.sendSpecialKey(MacKeyCode.rightArrow) }
                    keyCap("⌦") { session.sendSpecialKey(MacKeyCode.forwardDelete) }

                    Divider().frame(height: 22)

                    comboCap("⌘Space", code: MacKeyCode.space, mods: [.command])
                    comboCap("⌘Tab", code: MacKeyCode.tab, mods: [.command])
                    comboCap("⌘C", code: MacKeyCode.ansiC, mods: [.command])
                    comboCap("⌘V", code: MacKeyCode.ansiV, mods: [.command])
                    comboCap("⌘Z", code: MacKeyCode.ansiZ, mods: [.command])
                    comboCap("⌘W", code: MacKeyCode.ansiW, mods: [.command])

                    Button {
                        showFunctionRow.toggle()
                    } label: {
                        Text("Fn")
                            .font(.caption.weight(.bold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 7)
                            .background(showFunctionRow ? Color.blue : Color.white.opacity(0.14), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                            .foregroundStyle(.white)
                    }

                    Button {
                        isKeyboardFocused.toggle()
                    } label: {
                        Image(systemName: isKeyboardFocused ? "keyboard.chevron.compact.down" : "keyboard")
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 7)
                            .background(isKeyboardFocused ? Color.green.opacity(0.8) : Color.white.opacity(0.14), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                            .foregroundStyle(.white)
                    }
                }
                .padding(.horizontal, 10)
            }
        }
        .padding(.vertical, 6)
        .background(Color(white: 0.11))
    }

    private func modifierCap(_ symbol: String, mod: KeyModifiers) -> some View {
        let isLocked = session.lockedModifiers.contains(mod)
        let isArmed = session.oneShotModifiers.contains(mod)
        return Text(symbol)
            .font(.subheadline.weight(.bold))
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(
                isLocked ? Color.orange : (isArmed ? Color.blue : Color.white.opacity(0.14)),
                in: RoundedRectangle(cornerRadius: 8, style: .continuous)
            )
            .foregroundStyle(isLocked ? .black : .white)
            .onTapGesture(count: 2) {
                UISelectionFeedbackGenerator().selectionChanged()
                session.toggleModifier(mod, doubleTapped: true)
            }
            .onTapGesture(count: 1) {
                UISelectionFeedbackGenerator().selectionChanged()
                session.toggleModifier(mod, doubleTapped: false)
            }
    }

    private func keyCap(_ label: String, action: @escaping () -> Void) -> some View {
        Button {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            action()
        } label: {
            Text(label)
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(Color.white.opacity(0.14), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                .foregroundStyle(.white)
        }
    }

    private func comboCap(_ label: String, code: UInt16, mods: KeyModifiers) -> some View {
        Button {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            session.sendControl(.keyShortcut(keyCode: code, modifiers: mods))
        } label: {
            Text(label)
                .font(.caption2.weight(.semibold))
                .padding(.horizontal, 9)
                .padding(.vertical, 7)
                .background(Color.indigo.opacity(0.45), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                .foregroundStyle(.white)
        }
    }

    private func fnButton(_ title: String, code: UInt16) -> some View {
        keyCap(title) {
            session.sendSpecialKey(code, extraModifiers: [.function])
        }
    }
}

// MARK: - Invisible UIKeyInput Responder Bridge

private struct KeyCaptureViewRepresentable: UIViewRepresentable {
    @Binding var isFirstResponder: Bool
    var onInsertText: (String) -> Void
    var onDeleteBackward: () -> Void

    func makeUIView(context: Context) -> RawKeyCaptureUIView {
        let view = RawKeyCaptureUIView()
        view.onInsert = onInsertText
        view.onDelete = onDeleteBackward
        view.onResign = {
            DispatchQueue.main.async {
                if isFirstResponder {
                    isFirstResponder = false
                }
            }
        }
        return view
    }

    func updateUIView(_ uiView: RawKeyCaptureUIView, context: Context) {
        uiView.onInsert = onInsertText
        uiView.onDelete = onDeleteBackward
        if isFirstResponder && !uiView.isFirstResponder {
            DispatchQueue.main.async {
                _ = uiView.becomeFirstResponder()
            }
        } else if !isFirstResponder && uiView.isFirstResponder {
            DispatchQueue.main.async {
                _ = uiView.resignFirstResponder()
            }
        }
    }
}

private final class RawKeyCaptureUIView: UIView, UIKeyInput, UITextInputTraits {
    var onInsert: ((String) -> Void)?
    var onDelete: (() -> Void)?
    var onResign: (() -> Void)?

    var autocapitalizationType: UITextAutocapitalizationType = .none
    var autocorrectionType: UITextAutocorrectionType = .no
    var spellCheckingType: UITextSpellCheckingType = .no
    var smartQuotesType: UITextSmartQuotesType = .no
    var smartDashesType: UITextSmartDashesType = .no
    var keyboardAppearance: UIKeyboardAppearance = .dark
    var returnKeyType: UIReturnKeyType = .default

    override var canBecomeFirstResponder: Bool { true }

    var hasText: Bool { true }

    func insertText(_ text: String) {
        onInsert?(text)
    }

    func deleteBackward() {
        onDelete?()
    }

    override func resignFirstResponder() -> Bool {
        let res = super.resignFirstResponder()
        onResign?()
        return res
    }
}
