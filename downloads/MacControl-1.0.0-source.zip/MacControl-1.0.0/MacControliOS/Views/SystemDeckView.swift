import MacControlCore
import SwiftUI
import UIKit

struct SystemDeckView: View {
    @ObservedObject var session: ClientSession
    @State private var volumeSliderValue: Double = 0.5
    @State private var confirmPowerAction: PendingPowerAction?

    private enum PendingPowerAction: Identifiable {
        case sleepDisplay
        case lockScreen
        case sleepMac

        var id: String { title }
        var title: String {
            switch self {
            case .sleepDisplay: return "Sleep Mac Display?"
            case .lockScreen: return "Lock Mac Screen?"
            case .sleepMac: return "Put Mac to Sleep?"
            }
        }
        var action: SystemAction {
            switch self {
            case .sleepDisplay: return .sleepDisplay
            case .lockScreen: return .lockScreen
            case .sleepMac: return .sleepMac
            }
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                backgroundPersistenceCard
                audioAndBrightnessCard
                mediaTransportCard
                workspaceGridCard
                clipboardCard
                streamQualityCard
                powerSecurityCard
            }
            .padding(16)
        }
        .background(Color.black.ignoresSafeArea())
        .preferredColorScheme(.dark)
        .onAppear {
            if let vol = session.hostInfo?.volume {
                volumeSliderValue = Double(vol)
            }
        }
        .onChange(of: session.hostInfo?.volume) { _, newVal in
            if let newVal {
                volumeSliderValue = Double(newVal)
            }
        }
        .confirmationDialog(
            confirmPowerAction?.title ?? "",
            isPresented: Binding(
                get: { confirmPowerAction != nil },
                set: { if !$0 { confirmPowerAction = nil } }
            ),
            titleVisibility: .visible
        ) {
            if let pending = confirmPowerAction {
                Button(pending.title.replacingOccurrences(of: "?", with: ""), role: .destructive) {
                    session.triggerSystem(pending.action)
                    confirmPowerAction = nil
                }
            }
            Button("Cancel", role: .cancel) {
                confirmPowerAction = nil
            }
        }
    }

    private var backgroundPersistenceCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "bolt.horizontal.circle.fill")
                .font(.title2)
                .foregroundStyle(session.stayConnectedInBackground ? .green : .secondary)

            VStack(alignment: .leading, spacing: 2) {
                Text("Stay Connected When Minimized")
                    .font(.subheadline.weight(.semibold))
                Text("Keeps your encrypted Mac session & audio live when switching apps or locking iPhone.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Toggle("", isOn: $session.stayConnectedInBackground)
                .labelsHidden()
                .tint(.green)
        }
        .padding(14)
        .background(Color(white: 0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var audioAndBrightnessCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("Sound & Display", systemImage: "speaker.wave.3.fill")
                    .font(.subheadline.weight(.semibold))
                Spacer()
                Toggle(isOn: Binding(
                    get: { session.streamConfig.audioEnabled },
                    set: { enabled in
                        var cfg = session.streamConfig
                        cfg.audioEnabled = enabled
                        session.updateStreamConfiguration(cfg)
                    }
                )) {
                    Label("Stream Mac Audio to iPhone", systemImage: "airpodspro")
                        .font(.caption.weight(.medium))
                }
                .toggleStyle(.button)
                .tint(.blue)
            }

            HStack(spacing: 10) {
                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    session.triggerSystem(.toggleMute)
                } label: {
                    Image(systemName: (session.hostInfo?.isMuted == true) ? "speaker.slash.fill" : "speaker.wave.2.fill")
                        .frame(width: 36, height: 36)
                        .background(Color.white.opacity(0.12), in: Circle())
                }

                Slider(value: $volumeSliderValue, in: 0...1) { editing in
                    if !editing {
                        session.triggerSystem(.setVolume(Float(volumeSliderValue)))
                    }
                }

                Button {
                    session.triggerSystem(.volumeDown)
                } label: {
                    Image(systemName: "minus")
                        .frame(width: 32, height: 32)
                        .background(Color.white.opacity(0.1), in: Circle())
                }

                Button {
                    session.triggerSystem(.volumeUp)
                } label: {
                    Image(systemName: "plus")
                        .frame(width: 32, height: 32)
                        .background(Color.white.opacity(0.1), in: Circle())
                }
            }

            HStack(spacing: 12) {
                deckTile(title: "Brightness −", icon: "sun.min.fill") {
                    session.triggerSystem(.brightnessDown)
                }
                deckTile(title: "Brightness +", icon: "sun.max.fill") {
                    session.triggerSystem(.brightnessUp)
                }
            }
        }
        .padding(14)
        .background(Color(white: 0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var mediaTransportCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Media Playback", systemImage: "music.note")
                .font(.subheadline.weight(.semibold))

            HStack(spacing: 12) {
                deckTile(title: "Previous", icon: "backward.fill") {
                    session.triggerSystem(.mediaPrevious)
                }
                deckTile(title: "Play / Pause", icon: "playpause.fill", accent: .blue) {
                    session.triggerSystem(.mediaPlayPause)
                }
                deckTile(title: "Next", icon: "forward.fill") {
                    session.triggerSystem(.mediaNext)
                }
            }
        }
        .padding(14)
        .background(Color(white: 0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var workspaceGridCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("macOS Workspace", systemImage: "macwindow.on.rectangle")
                .font(.subheadline.weight(.semibold))

            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                deckTile(title: "Spotlight", icon: "magnifyingglass") {
                    session.triggerSystem(.spotlight)
                }
                deckTile(title: "Mission Control", icon: "rectangle.3.group") {
                    session.triggerSystem(.missionControl)
                }
                deckTile(title: "App Exposé", icon: "squares.below.rectangle") {
                    session.triggerSystem(.appExpose)
                }
                deckTile(title: "Show Desktop", icon: "menubar.dock.rectangle") {
                    session.triggerSystem(.showDesktop)
                }
            }
        }
        .padding(14)
        .background(Color(white: 0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var clipboardCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Two-Way Clipboard Sync", systemImage: "doc.on.clipboard")
                    .font(.subheadline.weight(.semibold))
                Spacer()
                Toggle("Auto", isOn: $session.autoClipboardSync)
                    .labelsHidden()
                Text("Auto")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if !session.latestMacClipboard.isEmpty {
                Text(session.latestMacClipboard)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(8)
                    .background(Color.black.opacity(0.35), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            }

            HStack(spacing: 10) {
                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    session.pushLocalClipboardToMac()
                } label: {
                    Label("Send iPhone → Mac", systemImage: "arrow.up.doc")
                        .font(.caption.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 9)
                        .background(Color.blue.opacity(0.85), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                }

                Button {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    session.sendControl(.requestClipboard)
                    session.copyMacClipboardToiPhone()
                } label: {
                    Label("Copy Mac → iPhone", systemImage: "arrow.down.doc")
                        .font(.caption.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 9)
                        .background(Color.white.opacity(0.14), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                }
            }
        }
        .padding(14)
        .background(Color(white: 0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var streamQualityCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Live Video Stream Settings", systemImage: "display")
                .font(.subheadline.weight(.semibold))

            if let displays = session.hostInfo?.displays, displays.count > 1 {
                Picker("Mac Display", selection: Binding(
                    get: { session.streamConfig.displayID ?? displays[0].id },
                    set: { newID in
                        var cfg = session.streamConfig
                        cfg.displayID = newID
                        session.updateStreamConfiguration(cfg)
                    }
                )) {
                    ForEach(displays) { disp in
                        Text(disp.name).tag(disp.id)
                    }
                }
                .pickerStyle(.menu)
            }

            HStack {
                Text("Quality")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Picker("Quality", selection: Binding(
                    get: { session.streamConfig.quality },
                    set: { q in
                        var cfg = session.streamConfig
                        cfg.quality = q
                        session.updateStreamConfiguration(cfg)
                    }
                )) {
                    ForEach(StreamQuality.allCases) { q in
                        Text(q.label).tag(q)
                    }
                }
                .pickerStyle(.menu)
            }

            HStack {
                Text("Frame Rate")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Picker("FPS", selection: Binding(
                    get: { session.streamConfig.fps },
                    set: { fps in
                        var cfg = session.streamConfig
                        cfg.fps = fps
                        session.updateStreamConfiguration(cfg)
                    }
                )) {
                    Text("30 FPS").tag(30)
                    Text("60 FPS").tag(60)
                }
                .pickerStyle(.segmented)
                .frame(width: 160)
            }
        }
        .padding(14)
        .background(Color(white: 0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var powerSecurityCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Power & Security", systemImage: "lock.fill")
                .font(.subheadline.weight(.semibold))

            HStack(spacing: 10) {
                deckTile(title: "Sleep Screen", icon: "moon.zzz.fill") {
                    confirmPowerAction = .sleepDisplay
                }
                deckTile(title: "Lock Mac", icon: "lock.desktopcomputer", accent: .orange) {
                    confirmPowerAction = .lockScreen
                }
                deckTile(title: "Sleep Mac", icon: "power", accent: .red) {
                    confirmPowerAction = .sleepMac
                }
            }
        }
        .padding(14)
        .background(Color(white: 0.12), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func deckTile(
        title: String,
        icon: String,
        accent: Color = .white,
        action: @escaping () -> Void
    ) -> some View {
        Button {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            action()
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(accent)
                Text(title)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.white)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 13)
            .background(Color.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
    }
}
