import AVFoundation
import MacControlCore
import SwiftUI
import UIKit

struct QRCodeScannerSheet: View {
    let onScanned: (PairingQRPayload) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var manualURI = ""
    @State private var scanError: String?

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                ZStack {
                    QRCameraPreviewRepresentable { code in
                        if let payload = PairingQRPayload.fromURIString(code) {
                            UINotificationFeedbackGenerator().notificationOccurred(.success)
                            onScanned(payload)
                            dismiss()
                        } else {
                            scanError = "Not a valid MacControl pairing QR code."
                        }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))

                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.45), lineWidth: 2)
                        .frame(width: 220, height: 220)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 320)
                .padding(.horizontal)

                Text("Point your iPhone camera at the QR code shown in MacControl Host on your Mac.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)

                if let scanError {
                    Text(scanError)
                        .font(.caption)
                        .foregroundStyle(.red)
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("Or paste Pairing URI:")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    HStack {
                        TextField("maccontrol://pair?...", text: $manualURI)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .textFieldStyle(.roundedBorder)
                        Button("Apply") {
                            if let payload = PairingQRPayload.fromURIString(manualURI) {
                                onScanned(payload)
                                dismiss()
                            } else {
                                scanError = "Invalid pairing URI."
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                .padding(.horizontal)

                Spacer()
            }
            .padding(.top, 12)
            .navigationTitle("Scan Mac QR Code")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
}

private struct QRCameraPreviewRepresentable: UIViewControllerRepresentable {
    let onCodeDetected: (String) -> Void

    func makeUIViewController(context: Context) -> QRCameraViewController {
        let vc = QRCameraViewController()
        vc.onCodeDetected = onCodeDetected
        return vc
    }

    func updateUIViewController(_ uiViewController: QRCameraViewController, context: Context) {}
}

private final class QRCameraViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onCodeDetected: ((String) -> Void)?
    private let session = AVCaptureSession()
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private var didEmit = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        guard let videoDevice = AVCaptureDevice.default(for: .video),
              let videoInput = try? AVCaptureDeviceInput(device: videoDevice),
              session.canAddInput(videoInput) else {
            let label = UILabel()
            label.text = "Camera unavailable on Simulator.\nPaste the pairing URI below or enter IP & PIN."
            label.textColor = .secondaryLabel
            label.font = .preferredFont(forTextStyle: .footnote)
            label.numberOfLines = 0
            label.textAlignment = .center
            label.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(label)
            NSLayoutConstraint.activate([
                label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                label.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                label.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 20),
                label.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -20)
            ])
            return
        }

        session.addInput(videoInput)
        let metadataOutput = AVCaptureMetadataOutput()
        if session.canAddOutput(metadataOutput) {
            session.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: .main)
            if metadataOutput.availableMetadataObjectTypes.contains(.qr) {
                metadataOutput.metadataObjectTypes = [.qr]
            }
        }

        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill
        layer.frame = view.bounds
        view.layer.addSublayer(layer)
        self.previewLayer = layer

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.session.startRunning()
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        let captureSession = session
        DispatchQueue.global(qos: .utility).async {
            if captureSession.isRunning {
                captureSession.stopRunning()
            }
        }
    }

    func metadataOutput(
        _ output: AVCaptureMetadataOutput,
        didOutput metadataObjects: [AVMetadataObject],
        from connection: AVCaptureConnection
    ) {
        guard !didEmit,
              let obj = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              obj.type == .qr,
              let str = obj.stringValue else {
            return
        }
        didEmit = true
        session.stopRunning()
        onCodeDetected?(str)
    }
}
