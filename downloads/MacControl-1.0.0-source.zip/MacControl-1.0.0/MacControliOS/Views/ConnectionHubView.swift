import MacControlCore
import SwiftUI

struct ConnectionHubView: View {
    @ObservedObject var session: ClientSession
    @StateObject private var bonjour = BonjourBrowserService()

    @State private var selectedTab: ConnectionTab = .local
    @State private var pinCode: String = ""
    @State private var directHost: String = ""
    @State private var directPort: String = String(MacControlConstants.defaultPort)
    @State private var relayURL: String = "wss://"
    @State private var relayRoomID: String = ""
    @State private var showQRScanner = false

    private enum ConnectionTab: String, CaseIterable {
        case local = "Wi-Fi / USB / VPN"
        case relay = "Internet Relay"
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    heroHeader

                    if let error = session.errorMessage {
                        HStack(spacing: 10) {
                            Image(systemName: "exclamationmark.octagon.fill")
                                .foregroundStyle(.red)
                            Text(error)
                                .font(.footnote.weight(.medium))
                            Spacer()
                            Button {
                                session.errorMessage = nil
                            } label: {
                                Image(systemName: "xmark")
                                    .font(.caption)
                            }
                        }
                        .padding(12)
                        .background(Color.red.opacity(0.14), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }

                    if case .connecting(let target) = session.phase {
                        connectingCard(title: "Connecting to \(target)…")
                    } else if case .authenticating = session.phase {
                        connectingCard(title: "Verifying E2E cryptographic PIN…")
                    } else if case .waitingForHostInRelay(let room) = session.phase {
                        connectingCard(title: "Waiting for Mac in relay room \(room)…")
                    }

                    if !session.savedProfiles.isEmpty {
                        savedMacsSection
                    }

                    pinEntryCard

                    Picker("Connection Mode", selection: $selectedTab) {
                        ForEach(ConnectionTab.allCases, id: \.self) { tab in
                            Text(tab.rawValue).tag(tab)
                        }
                    }
                    .pickerStyle(.segmented)

                    if selectedTab == .local {
                        bonjourSection
                        directHostSection
                    } else {
                        relaySection
                    }
                }
                .padding(18)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("MacControl")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showQRScanner = true
                    } label: {
                        Label("Scan QR", systemImage: "qrcode.viewfinder")
                    }
                }
            }
            .sheet(isPresented: $showQRScanner) {
                QRCodeScannerSheet { payload in
                    pinCode = payload.pin
                    if let lan = payload.localHost { directHost = lan }
                    directPort = String(payload.port)
                    if let rURL = payload.relayURL { relayURL = rURL }
                    if let rRoom = payload.relayRoomID { relayRoomID = rRoom }
                    session.applyScannedQR(payload, preferRemote: selectedTab == .relay)
                }
            }
            .onAppear {
                bonjour.startBrowsing()
            }
            .onDisappear {
                bonjour.stopBrowsing()
            }
        }
    }

    private var heroHeader: some View {
        HStack(spacing: 14) {
            Image("BrandIcon")
                .resizable()
                .scaledToFit()
                .frame(width: 56, height: 56)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .shadow(color: .black.opacity(0.25), radius: 6, y: 3)
            VStack(alignment: .leading, spacing: 3) {
                Text("Control Your Mac")
                    .font(.headline)
                Text("Live Retina touch stream, Magic Trackpad, full keyboard & system deck.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
    }

    private func connectingCard(title: String) -> some View {
        HStack(spacing: 12) {
            ProgressView()
            Text(title)
                .font(.subheadline.weight(.medium))
            Spacer()
            Button("Cancel", role: .destructive) {
                session.disconnect()
            }
            .font(.caption.weight(.semibold))
        }
        .padding(14)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var savedMacsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("SAVED MACS")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)

            ForEach(session.savedProfiles) { profile in
                HStack(spacing: 12) {
                    Image(systemName: "desktopcomputer")
                        .font(.title3)
                        .foregroundStyle(.blue)
                        .frame(width: 34)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(profile.name)
                            .font(.subheadline.weight(.semibold))
                        Text(profileSubtitle(profile))
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    if let lan = profile.localHost ?? profile.vpnHost, !lan.isEmpty {
                        Button("LAN/VPN") {
                            pinCode = profile.pin
                            session.connectDirect(host: lan, port: profile.port, pin: profile.pin, saveName: profile.name)
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.small)
                    }

                    if let rURL = profile.relayURL, let rRoom = profile.relayRoomID, !rURL.isEmpty, !rRoom.isEmpty {
                        Button("Relay") {
                            pinCode = profile.pin
                            session.connectRelay(relayURL: rURL, roomID: rRoom, pin: profile.pin, saveName: profile.name)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    }

                    Button(role: .destructive) {
                        session.removeSavedProfile(profile)
                    } label: {
                        Image(systemName: "trash")
                            .font(.caption)
                    }
                    .buttonStyle(.borderless)
                }
                .padding(12)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
        }
    }

    private func profileSubtitle(_ p: SavedMacProfile) -> String {
        var parts: [String] = []
        if let lan = p.localHost { parts.append(lan) }
        if let vpn = p.vpnHost { parts.append("VPN: \(vpn)") }
        if let room = p.relayRoomID { parts.append("Room: \(room)") }
        return parts.joined(separator: " • ")
    }

    private var pinEntryCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label("6-Digit Pairing PIN", systemImage: "key.fill")
                    .font(.subheadline.weight(.semibold))
                Spacer()
                Button {
                    showQRScanner = true
                } label: {
                    Label("Scan Mac QR", systemImage: "qrcode")
                        .font(.caption.weight(.semibold))
                }
            }
            TextField("Enter 6-digit PIN from MacControl Host", text: $pinCode)
                .keyboardType(.numberPad)
                .font(.system(.title3, design: .monospaced).bold())
                .padding(10)
                .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var bonjourSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("Nearby Macs (Bonjour Wi-Fi / USB)", systemImage: "dot.radiowaves.left.and.right")
                    .font(.subheadline.weight(.semibold))
                Spacer()
                ProgressView().scaleEffect(0.75)
            }

            if bonjour.discoveredMacs.isEmpty {
                Text("Searching for MacControl Host on your Wi-Fi or wired USB connection…")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.vertical, 6)
            } else {
                ForEach(bonjour.discoveredMacs) { mac in
                    Button {
                        session.connectBonjour(mac, pin: pinCode)
                    } label: {
                        HStack {
                            Image(systemName: "laptopcomputer")
                                .foregroundStyle(.green)
                            Text(mac.name)
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(.primary)
                            Spacer()
                            Text("Connect")
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(Color.blue, in: Capsule())
                                .foregroundStyle(.white)
                        }
                        .padding(10)
                        .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                }
            }
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var directHostSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Direct IP or Tailscale VPN", systemImage: "network")
                .font(.subheadline.weight(.semibold))

            HStack(spacing: 8) {
                TextField("IP or Hostname (e.g. 192.168.1.42 or 100.x.y.z)", text: $directHost)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .textFieldStyle(.roundedBorder)

                TextField("Port", text: $directPort)
                    .keyboardType(.numberPad)
                    .frame(width: 78)
                    .textFieldStyle(.roundedBorder)
            }

            Button {
                let port = UInt16(directPort) ?? MacControlConstants.defaultPort
                session.connectDirect(host: directHost, port: port, pin: pinCode)
            } label: {
                Text("Connect via Direct IP / VPN")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var relaySection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Over-the-Internet Relay", systemImage: "globe")
                .font(.subheadline.weight(.semibold))

            Text("Connect from cellular or any remote Wi-Fi without VPN. All screen video, audio, and touch input remain end-to-end encrypted with your PIN.")
                .font(.caption)
                .foregroundStyle(.secondary)

            TextField("Relay URL (e.g. wss://your-relay.up.railway.app)", text: $relayURL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.URL)
                .textFieldStyle(.roundedBorder)

            TextField("Room ID (e.g. MAC-7K2P-9X4M)", text: $relayRoomID)
                .textInputAutocapitalization(.characters)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)

            Button {
                session.connectRelay(relayURL: relayURL, roomID: relayRoomID, pin: pinCode)
            } label: {
                Text("Connect Over Internet Relay")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding(14)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
