import MacControlCore
import SwiftUI

enum WorkspaceControlMode: String, CaseIterable, Identifiable {
    case screen = "Screen"
    case trackpad = "Trackpad"
    case deck = "Deck"

    var id: String { rawValue }
    var icon: String {
        switch self {
        case .screen: return "rectangle.inset.filled.and.person.filled"
        case .trackpad: return "hand.point.up.left.fill"
        case .deck: return "slider.horizontal.below.square.filled.and.square"
        }
    }
}

struct ControllerWorkspaceView: View {
    @ObservedObject var session: ClientSession
    @ObservedObject var renderer: VideoStreamRenderer
    @State private var mode: WorkspaceControlMode = .screen
    @State private var isKeyboardOpen: Bool = false
    @State private var isImmersiveFullScreen: Bool = false

    init(session: ClientSession) {
        self.session = session
        self.renderer = session.videoRenderer
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            VStack(spacing: 0) {
                if !isImmersiveFullScreen {
                    topToolbar
                }

                if case .reconnecting(let target, let attempt) = session.phase {
                    HStack(spacing: 8) {
                        ProgressView()
                            .tint(.orange)
                            .scaleEffect(0.75)
                        Text("Reconnecting to \(target) (attempt \(attempt))…")
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.white)
                        Spacer()
                        Button("Retry Now") {
                            session.reconnectNow()
                        }
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.orange)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.orange.opacity(0.22))
                } else if let banner = session.statusBanner {
                    HStack(spacing: 8) {
                        Image(systemName: banner.isWarning ? "exclamationmark.triangle.fill" : "info.circle.fill")
                            .foregroundStyle(banner.isWarning ? .orange : .blue)
                        Text(banner.message)
                            .font(.caption)
                            .foregroundStyle(.white)
                        Spacer()
                        Button {
                            session.statusBanner = nil
                        } label: {
                            Image(systemName: "xmark")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color(white: 0.16))
                }

                // Active Mode Surface
                Group {
                    switch mode {
                    case .screen:
                        LiveScreenTouchView(session: session)
                    case .trackpad:
                        TrackpadModeView(session: session)
                    case .deck:
                        SystemDeckView(session: session)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                if mode != .deck && !isImmersiveFullScreen {
                    MacKeyboardBar(session: session, isKeyboardFocused: $isKeyboardOpen)
                }
            }

            // Floating restore button when in Immersive Full-Screen mode
            if isImmersiveFullScreen {
                HStack(spacing: 8) {
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            isImmersiveFullScreen = false
                        }
                    } label: {
                        HStack(spacing: 5) {
                            Circle()
                                .fill(session.phase == .connected ? Color.green : Color.orange)
                                .frame(width: 7, height: 7)
                            Image(systemName: "arrow.down.right.and.arrow.up.left")
                                .font(.caption2.weight(.bold))
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(.ultraThinMaterial, in: Capsule())
                        .foregroundStyle(.white)
                    }
                }
                .padding(.top, 8)
                .padding(.leading, 12)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .statusBarHidden(isImmersiveFullScreen)
        .preferredColorScheme(.dark)
        .onChange(of: mode) { _, newMode in
            var cfg = session.streamConfig
            let shouldStreamVideo = (newMode == .screen)
            if cfg.enabled != shouldStreamVideo {
                cfg.enabled = shouldStreamVideo
                session.updateStreamConfiguration(cfg)
            }
        }
    }

    private var topToolbar: some View {
        HStack(spacing: 8) {
            // Host badge + latency + FPS
            HStack(spacing: 6) {
                Circle()
                    .fill(session.phase == .connected ? Color.green : Color.orange)
                    .frame(width: 7, height: 7)
                Text(session.hostInfo?.hostName ?? "Mac")
                    .font(.caption.weight(.semibold))
                    .lineLimit(1)
                if let rtt = session.rttMilliseconds {
                    Text("\(rtt)ms")
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(.secondary)
                }
                if mode == .screen && renderer.currentFPS > 0 {
                    Text("\(renderer.currentFPS)fps")
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(.cyan.opacity(0.85))
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.white.opacity(0.09), in: Capsule())

            Spacer()

            // Mode switcher
            HStack(spacing: 3) {
                ForEach(WorkspaceControlMode.allCases) { item in
                    Button {
                        isKeyboardOpen = false
                        mode = item
                    } label: {
                        Text(item.rawValue)
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(mode == item ? Color.blue : Color.clear, in: Capsule())
                            .foregroundStyle(.white)
                    }
                }
            }
            .padding(3)
            .background(Color.white.opacity(0.1), in: Capsule())

            Spacer()

            if mode == .screen {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isKeyboardOpen = false
                        isImmersiveFullScreen = true
                    }
                } label: {
                    Image(systemName: "arrow.up.left.and.arrow.down.right")
                        .font(.caption.weight(.semibold))
                        .padding(7)
                        .background(Color.white.opacity(0.1), in: Circle())
                        .foregroundStyle(.white)
                }
            }

            // Audio stream quick toggle
            Button {
                var cfg = session.streamConfig
                cfg.audioEnabled.toggle()
                session.updateStreamConfiguration(cfg)
            } label: {
                Image(systemName: session.streamConfig.audioEnabled ? "speaker.wave.2.fill" : "speaker.slash")
                    .font(.caption.weight(.semibold))
                    .padding(7)
                    .background(session.streamConfig.audioEnabled ? Color.blue.opacity(0.85) : Color.white.opacity(0.1), in: Circle())
                    .foregroundStyle(.white)
            }

            // Disconnect button
            Button(role: .destructive) {
                isKeyboardOpen = false
                session.disconnect(clearError: true)
            } label: {
                Image(systemName: "power.circle.fill")
                    .font(.title3)
                    .foregroundStyle(.red.opacity(0.9))
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(Color(white: 0.08))
    }
}
