import MacControlCore
import SwiftUI
import UIKit

enum ScreenTouchInteractionStyle: String, CaseIterable {
    case directTouch = "Direct Touch"
    case virtualTrackpad = "Cursor Glide"
}

struct LiveScreenTouchView: View {
    @ObservedObject var session: ClientSession
    @ObservedObject var renderer: VideoStreamRenderer

    @State private var interactionStyle: ScreenTouchInteractionStyle = .directTouch
    @State private var zoomScale: CGFloat = 1.0
    @State private var panOffset: CGSize = .zero
    @State private var twoFingerMode: TwoFingerAction = .scrollMac
    @State private var tapRipplePoint: CGPoint?
    @State private var tapRippleID = UUID()

    private enum TwoFingerAction: String, CaseIterable {
        case scrollMac = "2F Scroll"
        case panZoom = "Pinch/Zoom"
    }

    init(session: ClientSession) {
        self.session = session
        self.renderer = session.videoRenderer
    }

    var body: some View {
        GeometryReader { geo in
            let containerSize = geo.size
            let fitted = aspectFitRect(in: containerSize, videoSize: renderer.videoSize)

            ZStack {
                Color.black.ignoresSafeArea()

                // Hardware decoded live Mac screen
                VideoDisplayLayerView(renderer: renderer)
                    .frame(width: fitted.width, height: fitted.height)
                    .scaleEffect(zoomScale)
                    .offset(panOffset)

                if !renderer.hasReceivedFirstFrame {
                    waitingForVideoOverlay
                }

                // Low-latency UIKit multi-touch overlay
                ScreenGestureOverlayRepresentable(
                    onSingleTap: { pt, count in
                        triggerRipple(at: pt)
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        if interactionStyle == .directTouch {
                            if let norm = normalizedPoint(from: pt, containerSize: containerSize, fittedRect: fitted) {
                                session.sendNormalizedButton(x: norm.x, y: norm.y, button: .left, isDown: true, clickCount: count)
                                session.sendNormalizedButton(x: norm.x, y: norm.y, button: .left, isDown: false, clickCount: count)
                            }
                        } else {
                            session.sendTrackpadClick(button: .left, clickCount: count)
                        }
                    },
                    onRightClick: { pt in
                        triggerRipple(at: pt)
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        if interactionStyle == .directTouch {
                            if let norm = normalizedPoint(from: pt, containerSize: containerSize, fittedRect: fitted) {
                                session.sendNormalizedButton(x: norm.x, y: norm.y, button: .right, isDown: true, clickCount: 1)
                                session.sendNormalizedButton(x: norm.x, y: norm.y, button: .right, isDown: false, clickCount: 1)
                            }
                        } else {
                            session.sendTrackpadClick(button: .right, clickCount: 1)
                        }
                    },
                    onOneFingerDrag: { pt, delta, phase in
                        if interactionStyle == .directTouch {
                            guard let norm = normalizedPoint(from: pt, containerSize: containerSize, fittedRect: fitted) else { return }
                            switch phase {
                            case .began:
                                session.sendNormalizedButton(x: norm.x, y: norm.y, button: .left, isDown: true, clickCount: 1)
                            case .changed:
                                session.sendNormalizedMove(x: norm.x, y: norm.y)
                            case .ended, .cancelled:
                                session.sendNormalizedButton(x: norm.x, y: norm.y, button: .left, isDown: false, clickCount: 1)
                            default:
                                break
                            }
                        } else {
                            if phase == .changed {
                                session.sendTrackpadDelta(dx: Double(delta.x), dy: Double(delta.y), isDragging: false)
                            }
                        }
                    },
                    onTwoFingerPan: { delta, phase in
                        if twoFingerMode == .scrollMac && zoomScale <= 1.02 {
                            let scrollPhase: MacControlCore.ScrollPhase = (phase == .began) ? .began : (phase == .ended ? .ended : .changed)
                            session.sendScroll(dx: Double(delta.x * 1.4), dy: Double(delta.y * 1.4), phase: scrollPhase)
                        } else {
                            let maxX = max(0, (fitted.width * zoomScale - containerSize.width) / 2 + 60)
                            let maxY = max(0, (fitted.height * zoomScale - containerSize.height) / 2 + 60)
                            let nx = min(maxX, max(-maxX, panOffset.width + delta.x))
                            let ny = min(maxY, max(-maxY, panOffset.height + delta.y))
                            panOffset = CGSize(width: nx, height: ny)
                        }
                    },
                    onPinchScale: { incrementalScale in
                        let updated = min(5.0, max(1.0, zoomScale * incrementalScale))
                        zoomScale = updated
                        if updated <= 1.02 {
                            panOffset = .zero
                        }
                    }
                )

                // Visual touch ripple indicator
                if let ripple = tapRipplePoint {
                    Circle()
                        .strokeBorder(Color.cyan.opacity(0.85), lineWidth: 2)
                        .frame(width: 34, height: 34)
                        .position(ripple)
                        .id(tapRippleID)
                        .transition(.scale.combined(with: .opacity))
                        .allowsHitTesting(false)
                }

                // Floating bottom-right HUD pill for touch style & zoom reset
                VStack {
                    Spacer()
                    HStack(spacing: 8) {
                        Picker("", selection: $interactionStyle) {
                            ForEach(ScreenTouchInteractionStyle.allCases, id: \.self) { style in
                                Text(style.rawValue).tag(style)
                            }
                        }
                        .pickerStyle(.segmented)
                        .frame(width: 210)

                        Button {
                            twoFingerMode = (twoFingerMode == .scrollMac) ? .panZoom : .scrollMac
                        } label: {
                            Label(twoFingerMode.rawValue, systemImage: twoFingerMode == .scrollMac ? "arrow.up.and.down.circle" : "plus.magnifyingglass")
                                .font(.caption2.weight(.semibold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(.ultraThinMaterial, in: Capsule())
                        }

                        if zoomScale > 1.05 {
                            Button {
                                withAnimation(.spring(duration: 0.25)) {
                                    zoomScale = 1.0
                                    panOffset = .zero
                                }
                            } label: {
                                Text("\(String(format: "%.1fx", zoomScale)) Reset")
                                    .font(.caption2.weight(.bold))
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(Color.blue, in: Capsule())
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                    .padding(.bottom, 8)
                }
            }
        }
    }

    private var waitingForVideoOverlay: some View {
        VStack(spacing: 10) {
            ProgressView()
                .tint(.white)
            Text(session.streamConfig.enabled ? "Starting live Mac screen stream…" : "Video stream paused")
                .font(.footnote.weight(.medium))
                .foregroundStyle(.white.opacity(0.85))
            if let info = session.hostInfo, !info.screenRecordingGranted {
                Text("Enable Screen Recording in MacControl Host on your Mac.")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        }
        .padding(18)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private func triggerRipple(at point: CGPoint) {
        tapRipplePoint = point
        tapRippleID = UUID()
        let currentID = tapRippleID
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.28) {
            if tapRippleID == currentID {
                tapRipplePoint = nil
            }
        }
    }

    private func aspectFitRect(in container: CGSize, videoSize: CGSize) -> CGRect {
        guard container.width > 0, container.height > 0, videoSize.width > 0, videoSize.height > 0 else {
            return CGRect(origin: .zero, size: container)
        }
        let scale = min(container.width / videoSize.width, container.height / videoSize.height)
        let w = videoSize.width * scale
        let h = videoSize.height * scale
        return CGRect(
            x: (container.width - w) / 2.0,
            y: (container.height - h) / 2.0,
            width: w,
            height: h
        )
    }

    private func normalizedPoint(from touch: CGPoint, containerSize: CGSize, fittedRect: CGRect) -> (x: Double, y: Double)? {
        guard fittedRect.width > 0, fittedRect.height > 0 else { return nil }
        let cx = containerSize.width / 2.0
        let cy = containerSize.height / 2.0
        let unzoomedX = (touch.x - cx - panOffset.width) / zoomScale + cx
        let unzoomedY = (touch.y - cy - panOffset.height) / zoomScale + cy

        let rawX = (unzoomedX - fittedRect.minX) / fittedRect.width
        let rawY = (unzoomedY - fittedRect.minY) / fittedRect.height
        // Ignore taps far outside letterboxed video area
        guard rawX >= -0.04, rawX <= 1.04, rawY >= -0.04, rawY <= 1.04 else {
            return nil
        }
        return (min(1.0, max(0.0, Double(rawX))), min(1.0, max(0.0, Double(rawY))))
    }
}

// MARK: - UIKit Multi-Touch Recognizer Layer

private struct ScreenGestureOverlayRepresentable: UIViewRepresentable {
    var onSingleTap: (CGPoint, Int) -> Void
    var onRightClick: (CGPoint) -> Void
    var onOneFingerDrag: (CGPoint, CGPoint, UIGestureRecognizer.State) -> Void
    var onTwoFingerPan: (CGPoint, UIGestureRecognizer.State) -> Void
    var onPinchScale: (CGFloat) -> Void

    func makeUIView(context: Context) -> ScreenGestureUIView {
        let view = ScreenGestureUIView()
        view.coordinator = context.coordinator
        context.coordinator.bind(to: view)
        return view
    }

    func updateUIView(_ uiView: ScreenGestureUIView, context: Context) {
        context.coordinator.parent = self
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var parent: ScreenGestureOverlayRepresentable
        private var lastOneFingerPoint: CGPoint = .zero

        init(parent: ScreenGestureOverlayRepresentable) {
            self.parent = parent
        }

        func bind(to view: UIView) {
            let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
            doubleTap.numberOfTapsRequired = 2
            doubleTap.numberOfTouchesRequired = 1

            let singleTap = UITapGestureRecognizer(target: self, action: #selector(handleSingleTap(_:)))
            singleTap.numberOfTapsRequired = 1
            singleTap.numberOfTouchesRequired = 1
            // Note: we do NOT require doubleTap to fail so single clicks stay instant; a second quick tap sends clickCount=2!

            let twoFingerTap = UITapGestureRecognizer(target: self, action: #selector(handleTwoFingerTap(_:)))
            twoFingerTap.numberOfTapsRequired = 1
            twoFingerTap.numberOfTouchesRequired = 2

            let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
            longPress.minimumPressDuration = 0.42
            longPress.allowableMovement = 10

            let oneFingerPan = UIPanGestureRecognizer(target: self, action: #selector(handleOneFingerPan(_:)))
            oneFingerPan.minimumNumberOfTouches = 1
            oneFingerPan.maximumNumberOfTouches = 1

            let twoFingerPan = UIPanGestureRecognizer(target: self, action: #selector(handleTwoFingerPan(_:)))
            twoFingerPan.minimumNumberOfTouches = 2
            twoFingerPan.maximumNumberOfTouches = 2
            twoFingerPan.delegate = self

            let pinch = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(_:)))
            pinch.delegate = self

            view.addGestureRecognizer(singleTap)
            view.addGestureRecognizer(doubleTap)
            view.addGestureRecognizer(twoFingerTap)
            view.addGestureRecognizer(longPress)
            view.addGestureRecognizer(oneFingerPan)
            view.addGestureRecognizer(twoFingerPan)
            view.addGestureRecognizer(pinch)
        }

        @objc private func handleSingleTap(_ gr: UITapGestureRecognizer) {
            guard gr.state == .ended, let v = gr.view else { return }
            parent.onSingleTap(gr.location(in: v), 1)
        }

        @objc private func handleDoubleTap(_ gr: UITapGestureRecognizer) {
            guard gr.state == .ended, let v = gr.view else { return }
            parent.onSingleTap(gr.location(in: v), 2)
        }

        @objc private func handleTwoFingerTap(_ gr: UITapGestureRecognizer) {
            guard gr.state == .ended, let v = gr.view else { return }
            parent.onRightClick(gr.location(in: v))
        }

        @objc private func handleLongPress(_ gr: UILongPressGestureRecognizer) {
            guard gr.state == .began, let v = gr.view else { return }
            parent.onRightClick(gr.location(in: v))
        }

        @objc private func handleOneFingerPan(_ gr: UIPanGestureRecognizer) {
            guard let v = gr.view else { return }
            let loc = gr.location(in: v)
            let delta = gr.translation(in: v)
            gr.setTranslation(.zero, in: v)
            parent.onOneFingerDrag(loc, delta, gr.state)
        }

        @objc private func handleTwoFingerPan(_ gr: UIPanGestureRecognizer) {
            guard let v = gr.view else { return }
            let delta = gr.translation(in: v)
            gr.setTranslation(.zero, in: v)
            parent.onTwoFingerPan(delta, gr.state)
        }

        @objc private func handlePinch(_ gr: UIPinchGestureRecognizer) {
            guard gr.state == .changed else { return }
            let scale = gr.scale
            gr.scale = 1.0
            parent.onPinchScale(scale)
        }

        func gestureRecognizer(
            _ gestureRecognizer: UIGestureRecognizer,
            shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer
        ) -> Bool {
            if (gestureRecognizer is UIPinchGestureRecognizer && otherGestureRecognizer is UIPanGestureRecognizer)
                || (gestureRecognizer is UIPanGestureRecognizer && otherGestureRecognizer is UIPinchGestureRecognizer) {
                return true
            }
            return false
        }
    }
}

private final class ScreenGestureUIView: UIView {
    weak var coordinator: ScreenGestureOverlayRepresentable.Coordinator?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isMultipleTouchEnabled = true
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
