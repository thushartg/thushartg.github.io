import MacControlCore
import SwiftUI
import UIKit

@main
struct MacControliOSApp: App {
    @StateObject private var session = ClientSession()

    var body: some Scene {
        WindowGroup {
            Group {
                if session.isWorkspaceActive {
                    ControllerWorkspaceView(session: session)
                } else {
                    ConnectionHubView(session: session)
                }
            }
            .onChange(of: session.phase) { _, newPhase in
                UIApplication.shared.isIdleTimerDisabled = (newPhase == .connected)
            }
            .onOpenURL { url in
                if let payload = MacControlCore.PairingQRPayload.fromURIString(url.absoluteString) {
                    session.applyScannedQR(payload)
                }
            }
        }
    }
}
