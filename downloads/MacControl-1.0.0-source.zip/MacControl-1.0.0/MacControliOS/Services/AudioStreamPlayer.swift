import AVFoundation
import Foundation
import MacControlCore

/// Plays low-latency Mac system audio AND maintains a lightweight `.mixWithOthers` silent keepalive loop
/// while the app is minimized so iOS never suspends the active MacControl connection.
final class AudioStreamPlayer: @unchecked Sendable {
    private let audioQueue = DispatchQueue(label: "com.maccontrol.ios.audio", qos: .userInteractive)
    private var engine: AVAudioEngine?
    private var playerNode: AVAudioPlayerNode?
    private var currentFormat: AVAudioFormat?
    private var scheduledBuffers = 0
    private let maxQueuedBuffers = 6
    private var isMutedLocally = false

    private var backgroundKeepaliveEnabled = false
    private var keepaliveTimer: DispatchSourceTimer?
    private var notificationObservers: [NSObjectProtocol] = []

    init() {
        registerSessionNotifications()
    }

    deinit {
        for obs in notificationObservers {
            NotificationCenter.default.removeObserver(obs)
        }
        keepaliveTimer?.cancel()
    }

    func setMuted(_ muted: Bool) {
        audioQueue.async { [weak self] in
            self?.isMutedLocally = muted
            self?.playerNode?.volume = muted ? 0.0 : 1.0
        }
    }

    /// Enables or disables continuous silent keepalive playback while minimized in the background.
    func setBackgroundKeepaliveActive(_ active: Bool) {
        audioQueue.async { [weak self] in
            guard let self else { return }
            self.backgroundKeepaliveEnabled = active
            if active {
                if self.engine == nil || !(self.engine?.isRunning ?? false) {
                    self.setupEngine(sampleRate: 24_000, channels: 2)
                }
                self.startKeepaliveTimerLocked()
                self.scheduleSilenceIfIdleLocked()
            } else {
                self.stopKeepaliveTimerLocked()
            }
        }
    }

    func stop(preserveBackgroundKeepalive: Bool = false) {
        audioQueue.async { [weak self] in
            guard let self else { return }
            if preserveBackgroundKeepalive && self.backgroundKeepaliveEnabled {
                return
            }
            self.backgroundKeepaliveEnabled = false
            self.stopKeepaliveTimerLocked()
            self.playerNode?.stop()
            self.engine?.stop()
            self.playerNode = nil
            self.engine = nil
            self.currentFormat = nil
            self.scheduledBuffers = 0
            try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        }
    }

    func enqueue(_ packet: AudioFramePacket) {
        audioQueue.async { [weak self] in
            guard let self, !self.isMutedLocally else { return }
            let channels = AVAudioChannelCount(max(1, min(2, Int(packet.channels))))
            let sampleRate = Double(max(8_000, packet.sampleRate))

            if self.engine == nil
                || !(self.engine?.isRunning ?? false)
                || self.currentFormat?.sampleRate != sampleRate
                || self.currentFormat?.channelCount != channels {
                self.setupEngine(sampleRate: sampleRate, channels: channels)
            }

            guard let format = self.currentFormat,
                  let player = self.playerNode,
                  let engine = self.engine,
                  engine.isRunning else {
                return
            }

            // Prevent latency buildup by dropping stale audio chunks if network jitter spikes
            if self.scheduledBuffers >= self.maxQueuedBuffers {
                return
            }

            let bytesPerSample = MemoryLayout<Int16>.size
            let frameCount = packet.pcmInt16Data.count / (bytesPerSample * Int(channels))
            guard frameCount > 0,
                  let pcmBuffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(frameCount)),
                  let floatChannelData = pcmBuffer.floatChannelData else {
                return
            }
            pcmBuffer.frameLength = AVAudioFrameCount(frameCount)

            packet.pcmInt16Data.withUnsafeBytes { rawBuf in
                guard let int16Ptr = rawBuf.bindMemory(to: Int16.self).baseAddress else { return }
                let chCount = Int(channels)
                for ch in 0..<chCount {
                    let dst = floatChannelData[ch]
                    for frame in 0..<frameCount {
                        dst[frame] = Float(int16Ptr[frame * chCount + ch]) / 32768.0
                    }
                }
            }

            self.scheduledBuffers += 1
            player.scheduleBuffer(pcmBuffer) { [weak self] in
                self?.audioQueue.async {
                    guard let self else { return }
                    self.scheduledBuffers = max(0, self.scheduledBuffers - 1)
                }
            }
            if !player.isPlaying {
                player.play()
            }
        }
    }

    // MARK: - Silent Keepalive Loop

    private func startKeepaliveTimerLocked() {
        guard keepaliveTimer == nil else { return }
        let timer = DispatchSource.makeTimerSource(queue: audioQueue)
        timer.schedule(deadline: .now() + 0.4, repeating: 0.85)
        timer.setEventHandler { [weak self] in
            self?.scheduleSilenceIfIdleLocked()
        }
        keepaliveTimer = timer
        timer.resume()
    }

    private func stopKeepaliveTimerLocked() {
        keepaliveTimer?.cancel()
        keepaliveTimer = nil
    }

    private func scheduleSilenceIfIdleLocked() {
        guard backgroundKeepaliveEnabled else { return }
        if engine == nil || !(engine?.isRunning ?? false) {
            setupEngine(sampleRate: currentFormat?.sampleRate ?? 24_000, channels: currentFormat?.channelCount ?? 2)
        }
        guard let format = currentFormat,
              let player = playerNode,
              let engine = engine,
              engine.isRunning else {
            return
        }
        // Only enqueue silent filler when fewer than 2 real/keepalive buffers are queued
        guard scheduledBuffers < 2 else { return }

        let silentFrames = AVAudioFrameCount(max(1024, Int(format.sampleRate))) // ~1.0s zero-amplitude buffer
        guard let silentBuffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: silentFrames),
              let floatChannels = silentBuffer.floatChannelData else {
            return
        }
        silentBuffer.frameLength = silentFrames
        let byteCount = Int(silentFrames) * MemoryLayout<Float>.size
        for ch in 0..<Int(format.channelCount) {
            memset(floatChannels[ch], 0, byteCount)
        }

        scheduledBuffers += 1
        player.scheduleBuffer(silentBuffer) { [weak self] in
            self?.audioQueue.async {
                guard let self else { return }
                self.scheduledBuffers = max(0, self.scheduledBuffers - 1)
            }
        }
        if !player.isPlaying {
            player.play()
        }
    }

    private func setupEngine(sampleRate: Double, channels: AVAudioChannelCount) {
        playerNode?.stop()
        engine?.stop()

        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try? session.setPreferredIOBufferDuration(0.01)
        try? session.setActive(true)

        guard let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: channels) else {
            return
        }
        let newEngine = AVAudioEngine()
        let node = AVAudioPlayerNode()
        node.volume = isMutedLocally ? 0.0 : 1.0
        newEngine.attach(node)
        newEngine.connect(node, to: newEngine.mainMixerNode, format: format)

        do {
            try newEngine.start()
            node.play()
            self.engine = newEngine
            self.playerNode = node
            self.currentFormat = format
            self.scheduledBuffers = 0
        } catch {
            self.engine = nil
            self.playerNode = nil
        }
    }

    private func registerSessionNotifications() {
        let center = NotificationCenter.default
        let intObs = center.addObserver(
            forName: AVAudioSession.interruptionNotification,
            object: nil,
            queue: nil
        ) { [weak self] note in
            let typeVal = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt
            guard typeVal == AVAudioSession.InterruptionType.ended.rawValue else { return }
            self?.audioQueue.async {
                guard let self, self.backgroundKeepaliveEnabled || self.engine != nil else { return }
                try? AVAudioSession.sharedInstance().setActive(true)
                try? self.engine?.start()
                self.playerNode?.play()
                self.scheduleSilenceIfIdleLocked()
            }
        }

        let resetObs = center.addObserver(
            forName: AVAudioSession.mediaServicesWereResetNotification,
            object: nil,
            queue: nil
        ) { [weak self] _ in
            self?.audioQueue.async {
                guard let self, self.backgroundKeepaliveEnabled else { return }
                self.engine = nil
                self.playerNode = nil
                self.setupEngine(sampleRate: 24_000, channels: 2)
                self.scheduleSilenceIfIdleLocked()
            }
        }
        notificationObservers = [intObs, resetObs]
    }
}
