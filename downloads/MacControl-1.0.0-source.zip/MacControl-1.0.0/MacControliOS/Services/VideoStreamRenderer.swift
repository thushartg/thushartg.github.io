import AVFoundation
import CoreMedia
import Foundation
import MacControlCore
import SwiftUI
import UIKit

/// Hardware-accelerated compressed H.264 / HEVC renderer backed by `AVSampleBufferDisplayLayer`.
/// Automatically pauses GPU video decoding while the app is minimized to prevent iOS background GPU faults.
final class VideoStreamRenderer: ObservableObject, @unchecked Sendable {
    @MainActor @Published private(set) var videoSize: CGSize = CGSize(width: 1920, height: 1200)
    @MainActor @Published private(set) var hasReceivedFirstFrame: Bool = false
    @MainActor @Published private(set) var currentFPS: Int = 0

    var onNeedKeyframe: (() -> Void)?

    let displayLayer: AVSampleBufferDisplayLayer = {
        let layer = AVSampleBufferDisplayLayer()
        layer.videoGravity = .resizeAspect
        return layer
    }()

    private let decodeQueue = DispatchQueue(label: "com.maccontrol.ios.videodecode", qos: .userInteractive)
    private var formatDescription: CMVideoFormatDescription?
    private var activeCodec: VideoCodecKind?
    private var lastKeyframeRequestDate: Date = .distantPast
    private var isBackgrounded: Bool = false

    private var frameCounter: Int = 0
    private var fpsWindowStart: Date = Date()

    func setBackgrounded(_ backgrounded: Bool) {
        decodeQueue.async { [weak self] in
            guard let self else { return }
            self.isBackgrounded = backgrounded
            if backgrounded {
                DispatchQueue.main.async {
                    self.displayLayer.flush()
                    self.currentFPS = 0
                }
            } else {
                self.lastKeyframeRequestDate = .distantPast
                DispatchQueue.main.async {
                    if self.displayLayer.status == .failed {
                        self.displayLayer.flush()
                    }
                }
                self.requestKeyframeThrottled()
            }
        }
    }

    func reset() {
        decodeQueue.async { [weak self] in
            guard let self else { return }
            self.formatDescription = nil
            self.activeCodec = nil
            self.frameCounter = 0
            DispatchQueue.main.async {
                self.displayLayer.flushAndRemoveImage()
                self.hasReceivedFirstFrame = false
                self.currentFPS = 0
            }
        }
    }

    func enqueuePacket(_ packet: VideoFramePacket) {
        decodeQueue.async { [weak self] in
            guard let self, !self.isBackgrounded else { return }

            if packet.isKeyframe && !packet.parameterSets.isEmpty {
                if let newDesc = Self.makeFormatDescription(codec: packet.codec, parameterSets: packet.parameterSets) {
                    self.formatDescription = newDesc
                    self.activeCodec = packet.codec
                }
            }

            guard let formatDesc = self.formatDescription, self.activeCodec == packet.codec else {
                self.requestKeyframeThrottled()
                return
            }

            let naluData = packet.avccData
            let length = naluData.count
            guard length > 0 else { return }

            var blockBuffer: CMBlockBuffer?
            let allocStatus = CMBlockBufferCreateWithMemoryBlock(
                allocator: kCFAllocatorDefault,
                memoryBlock: nil,
                blockLength: length,
                blockAllocator: kCFAllocatorDefault,
                customBlockSource: nil,
                offsetToData: 0,
                dataLength: length,
                flags: 0,
                blockBufferOut: &blockBuffer
            )
            guard allocStatus == kCMBlockBufferNoErr, let blockBuffer else { return }

            let replaceStatus = naluData.withUnsafeBytes { rawPtr -> OSStatus in
                guard let base = rawPtr.baseAddress else { return -1 }
                return CMBlockBufferReplaceDataBytes(
                    with: base,
                    blockBuffer: blockBuffer,
                    offsetIntoDestination: 0,
                    dataLength: length
                )
            }
            guard replaceStatus == kCMBlockBufferNoErr else { return }

            var sampleSize = length
            var timing = CMSampleTimingInfo(
                duration: .invalid,
                presentationTimeStamp: CMTime(value: CMTimeValue(packet.timestampUs), timescale: 1_000_000),
                decodeTimeStamp: .invalid
            )

            var sampleBuffer: CMSampleBuffer?
            let sbStatus = CMSampleBufferCreateReady(
                allocator: kCFAllocatorDefault,
                dataBuffer: blockBuffer,
                formatDescription: formatDesc,
                sampleCount: 1,
                sampleTimingEntryCount: 1,
                sampleTimingArray: &timing,
                sampleSizeEntryCount: 1,
                sampleSizeArray: &sampleSize,
                sampleBufferOut: &sampleBuffer
            )
            guard sbStatus == noErr, let sampleBuffer else { return }

            if let attachments = CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, createIfNecessary: true) {
                let dict = unsafeBitCast(CFArrayGetValueAtIndex(attachments, 0), to: CFMutableDictionary.self)
                CFDictionarySetValue(
                    dict,
                    Unmanaged.passUnretained(kCMSampleAttachmentKey_DisplayImmediately).toOpaque(),
                    Unmanaged.passUnretained(kCFBooleanTrue).toOpaque()
                )
            }

            let w = CGFloat(max(1, packet.width))
            let h = CGFloat(max(1, packet.height))

            self.frameCounter += 1
            let now = Date()
            let elapsed = now.timeIntervalSince(self.fpsWindowStart)
            var measuredFPS: Int?
            if elapsed >= 1.0 {
                measuredFPS = Int(Double(self.frameCounter) / elapsed)
                self.frameCounter = 0
                self.fpsWindowStart = now
            }

            DispatchQueue.main.async { [weak self] in
                guard let self, !self.isBackgrounded else { return }
                if self.displayLayer.status == .failed {
                    self.displayLayer.flush()
                    self.requestKeyframeThrottled()
                    return
                }
                self.displayLayer.enqueue(sampleBuffer)
                if self.videoSize.width != w || self.videoSize.height != h {
                    self.videoSize = CGSize(width: w, height: h)
                }
                if !self.hasReceivedFirstFrame {
                    self.hasReceivedFirstFrame = true
                }
                if let measuredFPS {
                    self.currentFPS = measuredFPS
                }
            }
        }
    }

    private func requestKeyframeThrottled() {
        let now = Date()
        guard now.timeIntervalSince(lastKeyframeRequestDate) > 0.30 else { return }
        lastKeyframeRequestDate = now
        onNeedKeyframe?()
    }

    private static func makeFormatDescription(codec: VideoCodecKind, parameterSets: [Data]) -> CMVideoFormatDescription? {
        guard !parameterSets.isEmpty else { return nil }
        let count = parameterSets.count
        var pointers = [UnsafePointer<UInt8>?](repeating: nil, count: count)
        var sizes = [Int](repeating: 0, count: count)

        let nsDatas = parameterSets.map { $0 as NSData }
        for idx in 0..<count {
            pointers[idx] = nsDatas[idx].bytes.assumingMemoryBound(to: UInt8.self)
            sizes[idx] = nsDatas[idx].length
        }

        let nonOptionalPointers = pointers.compactMap { $0 }
        guard nonOptionalPointers.count == count else { return nil }

        var formatDesc: CMFormatDescription?
        let status: OSStatus = nonOptionalPointers.withUnsafeBufferPointer { ptrBuf in
            sizes.withUnsafeBufferPointer { sizeBuf in
                guard let ptrBase = ptrBuf.baseAddress, let sizeBase = sizeBuf.baseAddress else {
                    return -1
                }
                switch codec {
                case .h264:
                    return CMVideoFormatDescriptionCreateFromH264ParameterSets(
                        allocator: kCFAllocatorDefault,
                        parameterSetCount: count,
                        parameterSetPointers: ptrBase,
                        parameterSetSizes: sizeBase,
                        nalUnitHeaderLength: 4,
                        formatDescriptionOut: &formatDesc
                    )
                case .hevc:
                    return CMVideoFormatDescriptionCreateFromHEVCParameterSets(
                        allocator: kCFAllocatorDefault,
                        parameterSetCount: count,
                        parameterSetPointers: ptrBase,
                        parameterSetSizes: sizeBase,
                        nalUnitHeaderLength: 4,
                        extensions: nil,
                        formatDescriptionOut: &formatDesc
                    )
                }
            }
        }
        return status == noErr ? formatDesc : nil
    }
}

struct VideoDisplayLayerView: UIViewRepresentable {
    let renderer: VideoStreamRenderer

    func makeUIView(context: Context) -> VideoContainerUIView {
        let view = VideoContainerUIView()
        view.attach(layer: renderer.displayLayer)
        return view
    }

    func updateUIView(_ uiView: VideoContainerUIView, context: Context) {
        uiView.attach(layer: renderer.displayLayer)
    }
}

final class VideoContainerUIView: UIView {
    private weak var hostedVideoLayer: AVSampleBufferDisplayLayer?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        isUserInteractionEnabled = false
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func attach(layer videoLayer: AVSampleBufferDisplayLayer) {
        if hostedVideoLayer !== videoLayer {
            hostedVideoLayer?.removeFromSuperlayer()
            videoLayer.frame = bounds
            layer.addSublayer(videoLayer)
            hostedVideoLayer = videoLayer
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        hostedVideoLayer?.frame = bounds
        CATransaction.commit()
    }
}
