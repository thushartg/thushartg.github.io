import Combine
import Foundation
import MacControlCore
import Network
import UIKit

struct SavedMacProfile: Codable, Identifiable, Equatable {
    var id: String { "\(name)|\(localHost ?? "")|\(vpnHost ?? "")|\(relayRoomID ?? "")" }
    var name: String
    var localHost: String?
    var vpnHost: String?
    var port: UInt16
    var relayURL: String?
    var relayRoomID: String?
    var pin: String
}

enum ClientConnectionPhase: Equatable {
    case disconnected
    case connecting(String)
    case waitingForHostInRelay(String)
    case authenticating
    case connected
    case reconnecting(String, Int)
}

private enum ActiveConnectionTarget {
    case bonjour(DiscoveredBonjourMac, pin: String)
    case direct(host: String, port: UInt16, pin: String, label: String)
    case relay(url: String, room: String, pin: String, label: String)

    var label: String {
        switch self {
        case .bonjour(let mac, _): return mac.name
        case .direct(_, _, _, let label): return label
        case .relay(_, _, _, let label): return label
        }
    }
}

@MainActor
final class ClientSession: ObservableObject {
    @Published var phase: ClientConnectionPhase = .disconnected
    @Published var errorMessage: String?
    @Published var statusBanner: (message: String, isWarning: Bool)?

    @Published var hostInfo: HostInfo?
    @Published var rttMilliseconds: Int?
    @Published var latestMacClipboard: String = ""
    @Published var autoClipboardSync: Bool = true

    /// Keeps the encrypted control link & audio alive even when the app is minimized or the iPhone screen locks.
    @Published var stayConnectedInBackground: Bool = {
        if UserDefaults.standard.object(forKey: "mc.ios.stayConnectedBG") == nil { return true }
        return UserDefaults.standard.bool(forKey: "mc.ios.stayConnectedBG")
    }() {
        didSet {
            UserDefaults.standard.set(stayConnectedInBackground, forKey: "mc.ios.stayConnectedBG")
            if isAppInBackground && isWorkspaceActive {
                audioPlayer.setBackgroundKeepaliveActive(stayConnectedInBackground)
            }
        }
    }

    @Published var streamConfig = StreamConfiguration(
        enabled: true,
        fps: 60,
        quality: .high,
        codec: .hevc,
        audioEnabled: false,
        displayID: nil
    )

    // Active sticky/locked modifiers from the on-screen Mac keyboard strip
    @Published var oneShotModifiers: KeyModifiers = []
    @Published var lockedModifiers: KeyModifiers = []

    @Published var savedProfiles: [SavedMacProfile] = []

    let videoRenderer = VideoStreamRenderer()
    let audioPlayer = AudioStreamPlayer()

    private var transport: WireTransport?
    private var handshakeContext: HandshakeContext?
    private var derivedMaterial: DerivedHandshakeMaterial?
    private var cryptoSession: CryptoSession?
    private var activePIN: String = ""

    private var activeTarget: ActiveConnectionTarget?
    private var reconnectTask: Task<Void, Never>?
    private var reconnectAttempt: Int = 0
    private var isAppInBackground: Bool = false
    private var backgroundTaskID: UIBackgroundTaskIdentifier = .invalid

    private var pingTimer: DispatchSourceTimer?
    private var clipboardPollTimer: Timer?
    private var lastLocalClipboardChangeCount: Int = UIPasteboard.general.changeCount
    private var lastReceivedRemoteClipboard: String?
    private var lifecycleObservers: [NSObjectProtocol] = []

    var isWorkspaceActive: Bool {
        switch phase {
        case .connected, .reconnecting:
            return true
        default:
            return false
        }
    }

    var effectiveModifiers: KeyModifiers {
        oneShotModifiers.union(lockedModifiers)
    }

    init() {
        loadSavedProfiles()
        registerAppLifecycleObservers()
        videoRenderer.onNeedKeyframe = { [weak self] in
            Task { @MainActor in
                guard let self, !self.isAppInBackground else { return }
                self.sendControl(.requestKeyframe)
            }
        }
    }

    // MARK: - Connection Entry Points

    func connectBonjour(_ mac: DiscoveredBonjourMac, pin: String) {
        let trimmedPIN = pin.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedPIN.isEmpty else {
            errorMessage = "Enter the 6-digit Pairing PIN shown on your Mac."
            return
        }
        errorMessage = nil
        reconnectAttempt = 0
        activeTarget = .bonjour(mac, pin: trimmedPIN)
        activePIN = trimmedPIN
        let tcp = TCPWireTransport(endpoint: mac.endpoint, label: mac.name)
        startDirectTransport(tcp, label: mac.name, isReconnect: false)
    }

    func connectDirect(host: String, port: UInt16, pin: String, saveName: String? = nil) {
        let cleanHost = host.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanPIN = pin.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanHost.isEmpty else {
            errorMessage = "Enter your Mac's local IP or Tailscale IP."
            return
        }
        guard !cleanPIN.isEmpty else {
            errorMessage = "Enter the 6-digit Pairing PIN shown on your Mac."
            return
        }
        let label = saveName ?? cleanHost
        errorMessage = nil
        reconnectAttempt = 0
        activeTarget = .direct(host: cleanHost, port: port, pin: cleanPIN, label: label)
        activePIN = cleanPIN

        let tcp = TCPWireTransport(host: cleanHost, port: port)
        startDirectTransport(tcp, label: label, isReconnect: false)

        upsertProfile(SavedMacProfile(
            name: label,
            localHost: cleanHost,
            vpnHost: nil,
            port: port,
            relayURL: nil,
            relayRoomID: nil,
            pin: cleanPIN
        ))
    }

    func connectRelay(relayURL: String, roomID: String, pin: String, saveName: String? = nil) {
        let cleanURL = relayURL.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanRoom = roomID.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        let cleanPIN = pin.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanURL.isEmpty, !cleanRoom.isEmpty else {
            errorMessage = "Enter both the Relay Server URL and Room ID."
            return
        }
        guard !cleanPIN.isEmpty else {
            errorMessage = "Enter the 6-digit Pairing PIN shown on your Mac."
            return
        }
        let label = saveName ?? cleanRoom
        errorMessage = nil
        reconnectAttempt = 0
        activeTarget = .relay(url: cleanURL, room: cleanRoom, pin: cleanPIN, label: label)
        activePIN = cleanPIN
        streamConfig.quality = .balanced
        streamConfig.fps = 30

        startRelayTransport(cleanURL: cleanURL, cleanRoom: cleanRoom, isReconnect: false)

        upsertProfile(SavedMacProfile(
            name: label,
            localHost: nil,
            vpnHost: nil,
            port: MacControlConstants.defaultPort,
            relayURL: cleanURL,
            relayRoomID: cleanRoom,
            pin: cleanPIN
        ))
    }

    func applyScannedQR(_ payload: PairingQRPayload, preferRemote: Bool = false) {
        upsertProfile(SavedMacProfile(
            name: payload.hostName,
            localHost: payload.localHost,
            vpnHost: payload.vpnHost,
            port: payload.port,
            relayURL: payload.relayURL,
            relayRoomID: payload.relayRoomID,
            pin: payload.pin
        ))

        if !preferRemote, let lan = payload.localHost, !lan.isEmpty {
            connectDirect(host: lan, port: payload.port, pin: payload.pin, saveName: payload.hostName)
        } else if let vpn = payload.vpnHost, !vpn.isEmpty {
            connectDirect(host: vpn, port: payload.port, pin: payload.pin, saveName: payload.hostName)
        } else if let relay = payload.relayURL, let room = payload.relayRoomID, !relay.isEmpty, !room.isEmpty {
            connectRelay(relayURL: relay, roomID: room, pin: payload.pin, saveName: payload.hostName)
        }
    }

    func reconnectNow() {
        guard let target = activeTarget else { return }
        reconnectTask?.cancel()
        reconnectTask = nil
        performTargetLaunch(target, isReconnect: true)
    }

    /// Explicit user-initiated disconnect — stops background keepalive and clears auto-reconnect target.
    func disconnect(clearError: Bool = false) {
        reconnectTask?.cancel()
        reconnectTask = nil
        activeTarget = nil
        reconnectAttempt = 0
        endOSBackgroundTask()

        let old = transport
        transport = nil
        handshakeContext = nil
        derivedMaterial = nil
        cryptoSession = nil
        stopTimers()
        videoRenderer.reset()
        audioPlayer.stop(preserveBackgroundKeepalive: false)
        hostInfo = nil
        rttMilliseconds = nil
        statusBanner = nil
        phase = .disconnected
        if clearError {
            errorMessage = nil
        }
        old?.close()
    }

    // MARK: - App Minimize / Foreground Lifecycle

    private func registerAppLifecycleObservers() {
        let center = NotificationCenter.default
        let bgObs = center.addObserver(
            forName: UIApplication.didEnterBackgroundNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.handleAppDidEnterBackground()
            }
        }

        let fgObs = center.addObserver(
            forName: UIApplication.willEnterForegroundNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.handleAppWillEnterForeground()
            }
        }

        lifecycleObservers = [bgObs, fgObs]
    }

    private func handleAppDidEnterBackground() {
        isAppInBackground = true
        clipboardPollTimer?.invalidate()
        clipboardPollTimer = nil
        videoRenderer.setBackgrounded(true)

        guard isWorkspaceActive || activeTarget != nil else { return }

        beginOSBackgroundTask()
        if stayConnectedInBackground {
            audioPlayer.setBackgroundKeepaliveActive(true)
        }

        // Pause Mac video encoding while minimized to avoid background GPU work & TCP buffer bloat,
        // while keeping encrypted control link and optional Mac audio active.
        if phase == .connected && streamConfig.enabled {
            var backgroundStream = streamConfig
            backgroundStream.enabled = false
            sendControl(.configureStream(backgroundStream))
        }
    }

    private func handleAppWillEnterForeground() {
        isAppInBackground = false
        endOSBackgroundTask()
        videoRenderer.setBackgrounded(false)

        if !streamConfig.audioEnabled {
            audioPlayer.setBackgroundKeepaliveActive(false)
        }

        if phase == .connected {
            sendPingNow()
            startClipboardPolling()
            // Immediately resume full-rate video stream and request a fresh IDR keyframe
            sendControl(.configureStream(streamConfig))
            if streamConfig.enabled {
                sendControl(.requestKeyframe)
            }
        } else if activeTarget != nil {
            reconnectNow()
        }
    }

    private func beginOSBackgroundTask() {
        guard backgroundTaskID == .invalid else { return }
        backgroundTaskID = UIApplication.shared.beginBackgroundTask(withName: "MacControlKeepAlive") { [weak self] in
            Task { @MainActor in
                self?.endOSBackgroundTask()
            }
        }
    }

    private func endOSBackgroundTask() {
        guard backgroundTaskID != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundTaskID)
        backgroundTaskID = .invalid
    }

    // MARK: - Input & Control Senders

    func sendNormalizedMove(x: Double, y: Double) {
        sendControl(.pointerMoveNormalized(x: x, y: y, displayID: streamConfig.displayID))
    }

    func sendNormalizedButton(x: Double?, y: Double?, button: MouseButton, isDown: Bool, clickCount: Int = 1) {
        sendControl(.pointerButton(x: x, y: y, button: button, isDown: isDown, clickCount: clickCount, displayID: streamConfig.displayID))
    }

    func sendTrackpadDelta(dx: Double, dy: Double, isDragging: Bool) {
        sendControl(.trackpadDelta(dx: dx, dy: dy, isDragging: isDragging))
    }

    func sendTrackpadClick(button: MouseButton, clickCount: Int = 1) {
        sendControl(.trackpadClick(button: button, clickCount: clickCount))
    }

    func sendScroll(dx: Double, dy: Double, phase: ScrollPhase) {
        sendControl(.scroll(dx: dx, dy: dy, phase: phase))
    }

    func sendSpecialKey(_ keyCode: UInt16, extraModifiers: KeyModifiers = []) {
        let mods = effectiveModifiers.union(extraModifiers)
        sendControl(.keyShortcut(keyCode: keyCode, modifiers: mods))
        oneShotModifiers = []
    }

    func sendTypedText(_ text: String) {
        guard !text.isEmpty else { return }
        let mods = effectiveModifiers
        if !mods.isEmpty && mods != [.shift],
           text.count == 1,
           let ch = text.first,
           let mapped = MacKeyCode.keyCode(forCharacter: ch) {
            var finalMods = mods
            if mapped.needsShift { finalMods.insert(.shift) }
            sendControl(.keyShortcut(keyCode: mapped.keyCode, modifiers: finalMods))
            oneShotModifiers = []
            return
        }
        sendControl(.textInput(text: text))
        oneShotModifiers = []
    }

    func toggleModifier(_ mod: KeyModifiers, doubleTapped: Bool = false) {
        if doubleTapped {
            if lockedModifiers.contains(mod) {
                lockedModifiers.remove(mod)
            } else {
                lockedModifiers.insert(mod)
                oneShotModifiers.remove(mod)
            }
            return
        }
        if lockedModifiers.contains(mod) {
            lockedModifiers.remove(mod)
            oneShotModifiers.remove(mod)
        } else if oneShotModifiers.contains(mod) {
            oneShotModifiers.remove(mod)
        } else {
            oneShotModifiers.insert(mod)
        }
    }

    func triggerSystem(_ action: SystemAction) {
        sendControl(.systemCommand(action))
    }

    func updateStreamConfiguration(_ updated: StreamConfiguration) {
        streamConfig = updated
        if !updated.audioEnabled && !(isAppInBackground && stayConnectedInBackground) {
            audioPlayer.stop(preserveBackgroundKeepalive: true)
        }
        if !isAppInBackground {
            sendControl(.configureStream(updated))
        }
    }

    func pushLocalClipboardToMac() {
        guard let str = UIPasteboard.general.string, !str.isEmpty else { return }
        sendControl(.setClipboard(text: str))
    }

    func copyMacClipboardToiPhone() {
        guard !latestMacClipboard.isEmpty else { return }
        lastReceivedRemoteClipboard = latestMacClipboard
        UIPasteboard.general.string = latestMacClipboard
        lastLocalClipboardChangeCount = UIPasteboard.general.changeCount
    }

    func removeSavedProfile(_ profile: SavedMacProfile) {
        savedProfiles.removeAll { $0.id == profile.id }
        persistProfiles()
    }

    // MARK: - Transport & Auto-Reconnect Internals

    private func teardownTransportOnly() {
        let old = transport
        transport = nil
        handshakeContext = nil
        derivedMaterial = nil
        cryptoSession = nil
        stopTimers()
        old?.close()
    }

    private func startDirectTransport(_ tcp: TCPWireTransport, label: String, isReconnect: Bool) {
        teardownTransportOnly()
        if !isReconnect {
            streamConfig.quality = .high
            streamConfig.fps = 60
            phase = .connecting(label)
        } else {
            phase = .reconnecting(label, max(1, reconnectAttempt))
        }
        transport = tcp

        tcp.onStateChange = { [weak self, weak tcp] state in
            Task { @MainActor in
                guard let self, let tcp, self.transport === tcp else { return }
                switch state {
                case .connecting:
                    if !isReconnect && !self.isWorkspaceActive {
                        self.phase = .connecting(label)
                    }
                case .connected:
                    self.beginClientHandshake(over: tcp)
                case .disconnected(let err):
                    self.handleUnexpectedDrop(reason: err)
                }
            }
        }

        tcp.onFrame = { [weak self, weak tcp] frame in
            Task { @MainActor in
                guard let self, let tcp, self.transport === tcp else { return }
                self.handleIncomingFrame(frame, over: tcp)
            }
        }

        tcp.start()
    }

    private func startRelayTransport(cleanURL: String, cleanRoom: String, isReconnect: Bool) {
        guard let ws = WebSocketRelayTransport(baseRelayURL: cleanURL, roomID: cleanRoom, role: .client) else {
            errorMessage = "Invalid Relay URL."
            return
        }
        teardownTransportOnly()
        phase = isReconnect ? .reconnecting("Relay \(cleanRoom)", max(1, reconnectAttempt)) : .connecting("Relay \(cleanRoom)")
        transport = ws

        ws.onStateChange = { [weak self, weak ws] state in
            Task { @MainActor in
                guard let self, let ws, self.transport === ws else { return }
                switch state {
                case .connecting:
                    if !isReconnect && !self.isWorkspaceActive {
                        self.phase = .connecting("Relay \(cleanRoom)")
                    }
                case .connected:
                    if !isReconnect {
                        self.phase = .waitingForHostInRelay(cleanRoom)
                    }
                case .disconnected(let err):
                    self.handleUnexpectedDrop(reason: err)
                }
            }
        }

        ws.onRelayEvent = { [weak self, weak ws] notice in
            Task { @MainActor in
                guard let self, let ws, self.transport === ws else { return }
                if notice.peerConnected {
                    self.beginClientHandshake(over: ws)
                } else if !self.isWorkspaceActive {
                    self.phase = .waitingForHostInRelay(cleanRoom)
                } else {
                    self.cryptoSession = nil
                    self.phase = .reconnecting("Relay \(cleanRoom)", max(1, self.reconnectAttempt))
                }
            }
        }

        ws.onFrame = { [weak self, weak ws] frame in
            Task { @MainActor in
                guard let self, let ws, self.transport === ws else { return }
                self.handleIncomingFrame(frame, over: ws)
            }
        }

        ws.start()
    }

    private func performTargetLaunch(_ target: ActiveConnectionTarget, isReconnect: Bool) {
        switch target {
        case .bonjour(let mac, let pin):
            activePIN = pin
            let tcp = TCPWireTransport(endpoint: mac.endpoint, label: mac.name)
            startDirectTransport(tcp, label: mac.name, isReconnect: isReconnect)

        case .direct(let host, let port, let pin, let label):
            activePIN = pin
            let tcp = TCPWireTransport(host: host, port: port)
            startDirectTransport(tcp, label: label, isReconnect: isReconnect)

        case .relay(let url, let room, let pin, _):
            activePIN = pin
            startRelayTransport(cleanURL: url, cleanRoom: room, isReconnect: isReconnect)
        }
    }

    private func beginClientHandshake(over activeTransport: WireTransport) {
        if !isWorkspaceActive {
            phase = .authenticating
        }
        let hs = HandshakeContext(role: .client, deviceName: UIDevice.current.name)
        self.handshakeContext = hs
        self.derivedMaterial = nil
        if let helloBytes = try? JSONEncoder().encode(hs.makeHello()) {
            activeTransport.send(WireFrame(kind: .handshakeHello, payload: helloBytes), isDroppableMedia: false)
        }
    }

    private func handleIncomingFrame(_ frame: WireFrame, over activeTransport: WireTransport) {
        switch frame.kind {
        case .handshakeHello:
            guard let hs = handshakeContext,
                  let hostHello = try? JSONDecoder().decode(HandshakeHello.self, from: frame.payload) else {
                return
            }
            do {
                self.derivedMaterial = try hs.deriveKeys(peerHello: hostHello, pin: activePIN)
            } catch {
                handleAuthFailure(reason: error.localizedDescription)
            }

        case .handshakeHostAuth:
            guard let material = derivedMaterial,
                  let hostProof = try? JSONDecoder().decode(HandshakeAuthProof.self, from: frame.payload) else {
                return
            }
            guard material.verifyPeerProof(hostProof) else {
                handleAuthFailure(reason: "Incorrect Pairing PIN. Check the 6-digit PIN on your Mac.")
                return
            }
            if let myProofData = try? JSONEncoder().encode(material.myAuthProof()) {
                activeTransport.send(WireFrame(kind: .handshakeClientAuth, payload: myProofData), isDroppableMedia: false)
            }
            self.cryptoSession = material.buildCryptoSession()
            self.handshakeContext = nil
            self.derivedMaterial = nil
            self.reconnectAttempt = 0
            self.reconnectTask?.cancel()
            self.reconnectTask = nil
            self.phase = .connected
            startTimers()

            if isAppInBackground {
                var bgConfig = streamConfig
                bgConfig.enabled = false
                sendControl(.configureStream(bgConfig))
                if stayConnectedInBackground {
                    audioPlayer.setBackgroundKeepaliveActive(true)
                }
            } else {
                sendControl(.configureStream(streamConfig))
                if streamConfig.enabled {
                    sendControl(.requestKeyframe)
                }
            }

        case .handshakeReject:
            if let rej = try? JSONDecoder().decode(HandshakeReject.self, from: frame.payload) {
                handleAuthFailure(reason: rej.reason)
            } else {
                handleAuthFailure(reason: "Connection rejected by Mac host.")
            }

        case .encryptedControl:
            guard let crypto = cryptoSession,
                  let plain = try? crypto.open(frame.payload, associatedKind: .encryptedControl),
                  let message = try? JSONDecoder().decode(HostControlMessage.self, from: plain) else {
                return
            }
            handleHostMessage(message)

        case .encryptedVideo:
            guard !isAppInBackground,
                  let crypto = cryptoSession,
                  let plain = try? crypto.open(frame.payload, associatedKind: .encryptedVideo),
                  let packet = VideoFramePacket.decode(from: plain) else {
                return
            }
            videoRenderer.enqueuePacket(packet)

        case .encryptedAudio:
            guard streamConfig.audioEnabled,
                  let crypto = cryptoSession,
                  let plain = try? crypto.open(frame.payload, associatedKind: .encryptedAudio),
                  let packet = AudioFramePacket.decode(from: plain) else {
                return
            }
            audioPlayer.enqueue(packet)

        default:
            break
        }
    }

    private func handleHostMessage(_ message: HostControlMessage) {
        switch message {
        case .hostInfo(let info):
            self.hostInfo = info
            if streamConfig.displayID == nil, let activeID = info.activeDisplayID {
                streamConfig.displayID = activeID
            }

        case .clipboardUpdate(let text):
            latestMacClipboard = text
            if autoClipboardSync && !isAppInBackground {
                lastReceivedRemoteClipboard = text
                UIPasteboard.general.string = text
                lastLocalClipboardChangeCount = UIPasteboard.general.changeCount
            }

        case .cursorPosition:
            break

        case .pong(let sentMs):
            let nowMs = UInt64(Date().timeIntervalSince1970 * 1000)
            if nowMs >= sentMs {
                rttMilliseconds = Int(nowMs - sentMs)
            }

        case .statusBanner(let msg, let isWarning):
            statusBanner = (msg, isWarning)
        }
    }

    func sendControl(_ msg: ClientControlMessage) {
        guard let crypto = cryptoSession,
              let activeTransport = transport,
              let plain = try? JSONEncoder().encode(msg),
              let sealed = try? crypto.seal(plain, associatedKind: .encryptedControl) else {
            return
        }
        activeTransport.send(WireFrame(kind: .encryptedControl, payload: sealed), isDroppableMedia: false)
    }

    private func handleAuthFailure(reason: String) {
        activeTarget = nil
        disconnect(clearError: false)
        errorMessage = reason
    }

    private func handleUnexpectedDrop(reason: String?) {
        teardownTransportOnly()

        // If we had an authenticated session (or user is actively trying to stay connected), auto-reconnect seamlessly
        guard let target = activeTarget else {
            phase = .disconnected
            if let reason, !reason.isEmpty {
                errorMessage = reason
            }
            return
        }

        // If initial first-time connect failed before ever entering workspace, show error on ConnectionHub
        if hostInfo == nil && !isWorkspaceActive {
            activeTarget = nil
            phase = .disconnected
            errorMessage = reason ?? "Could not reach \(target.label)."
            return
        }

        if isAppInBackground && stayConnectedInBackground {
            audioPlayer.setBackgroundKeepaliveActive(true)
        }

        reconnectAttempt += 1
        phase = .reconnecting(target.label, reconnectAttempt)
        let delaySeconds = min(5.0, 0.5 * pow(1.6, Double(min(reconnectAttempt - 1, 5))))

        reconnectTask?.cancel()
        reconnectTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(delaySeconds * 1_000_000_000))
            guard let self, !Task.isCancelled, let currentTarget = self.activeTarget else { return }
            self.performTargetLaunch(currentTarget, isReconnect: true)
        }
    }

    // MARK: - Timers (GCD Timer for Background Reliability)

    private func startTimers() {
        stopTimers()
        sendPingNow()

        let gcdPing = DispatchSource.makeTimerSource(queue: DispatchQueue.main)
        gcdPing.schedule(deadline: .now() + 3.0, repeating: 3.0)
        gcdPing.setEventHandler { [weak self] in
            self?.sendPingNow()
        }
        pingTimer = gcdPing
        gcdPing.resume()

        if !isAppInBackground {
            startClipboardPolling()
        }
    }

    private func startClipboardPolling() {
        clipboardPollTimer?.invalidate()
        lastLocalClipboardChangeCount = UIPasteboard.general.changeCount
        clipboardPollTimer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.pollLocalClipboardIfNeeded()
            }
        }
    }

    private func stopTimers() {
        pingTimer?.cancel()
        pingTimer = nil
        clipboardPollTimer?.invalidate()
        clipboardPollTimer = nil
    }

    private func sendPingNow() {
        let nowMs = UInt64(Date().timeIntervalSince1970 * 1000)
        sendControl(.ping(timestampMs: nowMs))
    }

    private func pollLocalClipboardIfNeeded() {
        guard autoClipboardSync, !isAppInBackground else { return }
        let pb = UIPasteboard.general
        guard pb.changeCount != lastLocalClipboardChangeCount else { return }
        lastLocalClipboardChangeCount = pb.changeCount
        guard let str = pb.string, !str.isEmpty else { return }
        if str == lastReceivedRemoteClipboard {
            lastReceivedRemoteClipboard = nil
            return
        }
        sendControl(.setClipboard(text: str))
    }

    // MARK: - Saved Profiles Persistence

    private func loadSavedProfiles() {
        guard let data = UserDefaults.standard.data(forKey: "mc.ios.savedProfiles"),
              let list = try? JSONDecoder().decode([SavedMacProfile].self, from: data) else {
            return
        }
        savedProfiles = list
    }

    private func upsertProfile(_ profile: SavedMacProfile) {
        if let idx = savedProfiles.firstIndex(where: { $0.name == profile.name }) {
            var merged = savedProfiles[idx]
            merged.pin = profile.pin
            if let lh = profile.localHost { merged.localHost = lh }
            if let vh = profile.vpnHost { merged.vpnHost = vh }
            if let ru = profile.relayURL { merged.relayURL = ru }
            if let rr = profile.relayRoomID { merged.relayRoomID = rr }
            merged.port = profile.port
            savedProfiles[idx] = merged
        } else {
            savedProfiles.insert(profile, at: 0)
        }
        persistProfiles()
    }

    private func persistProfiles() {
        if let data = try? JSONEncoder().encode(savedProfiles) {
            UserDefaults.standard.set(data, forKey: "mc.ios.savedProfiles")
        }
    }
}
