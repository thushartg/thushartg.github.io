import Foundation
import MacControlCore
import Network

struct DiscoveredBonjourMac: Identifiable, Hashable {
    let id: String
    let name: String
    let endpoint: NWEndpoint
}

@MainActor
final class BonjourBrowserService: ObservableObject {
    @Published private(set) var discoveredMacs: [DiscoveredBonjourMac] = []
    @Published private(set) var browseError: String?

    private var browser: NWBrowser?
    private let queue = DispatchQueue(label: "com.maccontrol.ios.bonjour", qos: .userInitiated)

    func startBrowsing() {
        stopBrowsing()
        let params = NWParameters()
        params.includePeerToPeer = true
        let descriptor = NWBrowser.Descriptor.bonjour(type: MacControlConstants.bonjourServiceType, domain: nil)
        let nwBrowser = NWBrowser(for: descriptor, using: params)

        nwBrowser.stateUpdateHandler = { [weak self] state in
            Task { @MainActor in
                guard let self else { return }
                switch state {
                case .ready:
                    self.browseError = nil
                case .failed(let err):
                    self.browseError = err.localizedDescription
                case .waiting(let err):
                    self.browseError = err.localizedDescription
                default:
                    break
                }
            }
        }

        nwBrowser.browseResultsChangedHandler = { [weak self] results, _ in
            let items: [DiscoveredBonjourMac] = results.compactMap { result in
                if case let .service(name, _, _, _) = result.endpoint {
                    return DiscoveredBonjourMac(
                        id: "\(name)-\(result.endpoint.debugDescription)",
                        name: name,
                        endpoint: result.endpoint
                    )
                }
                return nil
            }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }

            Task { @MainActor in
                self?.discoveredMacs = items
            }
        }

        nwBrowser.start(queue: queue)
        self.browser = nwBrowser
    }

    func stopBrowsing() {
        browser?.cancel()
        browser = nil
    }
}
