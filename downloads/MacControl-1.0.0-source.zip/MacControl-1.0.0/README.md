# MacControl — Full Touchscreen Mac Control from iPhone

A native **macOS Host App** + **iOS Controller App** + **Zero-Knowledge Internet Relay Server** built in Swift (`ScreenCaptureKit`, `VideoToolbox`, `CoreGraphics`, `Network.framework`, `CryptoKit`, `AVFoundation`).

---

## Project Structure

- `MacControl.xcodeproj` — Unified Xcode project containing both app targets:
  - **`MacControlHost`** (macOS 14+): Menu bar & dashboard host app capturing live display video + system audio and injecting mouse, multi-touch trackpad, keyboard, media, and system actions.
  - **`MacControliOS`** (iOS 17+): Native iPhone/iPad controller app with hardware HEVC/H.264 decoding, Direct Touch + Cursor Glide modes, Magic Trackpad, Mac modifier keyboard bar, System Deck, audio playback, and QR code pairing.
- `Packages/MacControlCore` — Shared Swift package implementing:
  - Ephemeral **X25519 + Pairing PIN (`HKDF-SHA256`)** mutual handshake and **ChaCha20-Poly1305** end-to-end encryption with replay protection.
  - Zero-base64 binary media framing (`VideoFramePacket`, `AudioFramePacket`, `WireStreamDeframer`).
  - Low-latency `NWConnection` (`TCP_NODELAY`) and `URLSessionWebSocketTask` transports.
- `RelayServer/` — Zero-dependency Node.js WebSocket relay (`server.js` + `Dockerfile`) for over-the-internet control across cellular/NAT without VPN.

---

## Launching Standalone (No Xcode Build Needed)

Both apps are built and signed as standalone Release applications with custom icons:

1. **On Your Mac:**
   - Open **`MacControlHost.app`** directly from **`/Applications/MacControlHost.app`** (or Spotlight `⌘Space` → **MacControl Host**). Keep `/Applications/MacControlHost.app` as the single installed copy so macOS Accessibility & Screen Recording permissions always stay bound to it.
   - Enable **Start Automatically at Login** in the MacControl Host dashboard (or menu bar icon) so it runs automatically whenever your Mac starts.
   - Ensure **Accessibility** and **Screen Recording** are granted once in System Settings (use **Reset Stuck Toggle** / **Relaunch App** in the Permissions card if macOS ever caches an older signature).

2. **On Your iPhone:**
   - Tap the **MacControl** app icon directly on your iPhone Home Screen (installed as an untethered Release build — Xcode does not need to be open or connected).
   - **Background Persistence:** Minimizing the app or locking your iPhone keeps the encrypted control session and Mac audio stream alive automatically, and seamlessly resumes 60fps live screen video the instant you return.

---

## Rebuilding from Source in Xcode (Optional)

1. **Open the Project**
   Open `MacControl.xcodeproj` in Xcode (`/Applications/Xcode-beta.app`).

2. **Build & Launch `MacControlHost` on Your Mac**
   - Select the **`MacControlHost`** scheme → destination **My Mac** → press **⌘R**.
   - In the MacControl Host window, click:
     - **Grant Accessibility** (enables mouse, trackpad, keyboard, and shortcuts)
     - **Grant Screen Recording** (enables live display video and Mac system audio)

3. **Build & Install `MacControliOS` on Your iPhone**
   - Connect your iPhone via USB (or wireless debugging).
   - Select the **`MacControliOS`** target → **Signing & Capabilities** → select your **Team** (Personal Apple ID or Apple Developer Team) and adjust the **Bundle Identifier** if needed (e.g. `com.yourname.maccontrol.ios`).
   - Select the **`MacControliOS`** scheme → choose your **iPhone** → press **⌘R**.
   - *(If using a free Personal Apple ID, go to **Settings → General → VPN & Device Management** on your iPhone once to trust your developer certificate, and ensure **Settings → Privacy & Security → Developer Mode** is enabled.)*

4. **Pair & Connect**
   - Tap **Scan QR** in the iPhone app to scan the QR code displayed in `MacControlHost`, **or** tap your Mac under **Nearby Macs (Bonjour Wi-Fi / USB)** and enter the **6-digit Pairing PIN**.

---

## Connecting Away From Home (Over the Internet)

### Option A: Self-Hosted Relay Server (Works Over Cellular / Any Firewall, No VPN Needed)
All video, audio, clipboard, and input frames are **end-to-end encrypted (`ChaCha20-Poly1305`)** between your Mac and iPhone — the relay server only forwards opaque encrypted frames.

**Run locally to test:**
```bash
node RelayServer/server.js
```

**Deploy to Railway / Render / Fly.io / Any VPS (Docker or Node 20+):**
- Point your cloud service at the `RelayServer/` folder (`npm start` or `Dockerfile`, listens on `PORT`, default `8787`).
- In **MacControl Host**, toggle **Enable Relay**, paste `wss://your-relay-domain.com`, and scan the updated QR code (or enter the **Room ID** + **PIN**) on your iPhone under the **Internet Relay** tab.

### Option B: Direct VPN (Tailscale / WireGuard)
- Install Tailscale on both your Mac and iPhone.
- `MacControlHost` automatically detects your Mac's `100.x.y.z` Tailscale IP and embeds it directly into the QR code and Saved Mac profile.

---

## iPhone Touchscreen Controls Reference

| Mode | Gesture / Control | Mac Action |
| :--- | :--- | :--- |
| **Screen (Direct Touch)** | 1-finger tap / double-tap | Left click / Double-click at exact tapped pixel |
| **Screen (Direct Touch)** | Long-press or 2-finger tap | Right-click at tapped pixel |
| **Screen (Direct Touch)** | 1-finger drag | Click-and-drag windows, sliders, or text selections |
| **Screen (Direct Touch)** | Pinch / 2-finger pan | Zoom up to `5.0x` for tiny menus, or 2-finger pixel scroll |
| **Screen (Cursor Glide)** | Slide anywhere while watching live video | Relative trackpad cursor movement without finger occlusion |
| **Trackpad Mode** | 1-finger glide / tap / 2-finger tap / 2-finger pan | Magic Trackpad move, click, right-click, smooth pixel scroll, plus **Drag Lock** |
| **Keyboard Bar** | `⌘` `⌥` `⌃` `⇧` (tap = next key, double-tap = lock) | Full iOS keyboard + Dictation + Emoji + `Esc`, `Tab`, Arrows, `Fn` (`F1`–`F12`), `⌘Space`, `⌘Tab`, `⌘C`/`⌘V` |
| **System Deck** | Sound, Display, Media, Workspace, Clipboard & Power | Volume slider, Mac→iPhone audio stream, Brightness, Play/Pause/Next, Mission Control, Two-Way Clipboard, Lock/Sleep |

---

## CLI Verification Commands

```bash
# 1. Run shared crypto & binary protocol unit tests
DEVELOPER_DIR=/Applications/Xcode-beta.app/Contents/Developer swift test --package-path Packages/MacControlCore

# 2. Run WebSocket Relay integration test
node RelayServer/test_relay.js
```
