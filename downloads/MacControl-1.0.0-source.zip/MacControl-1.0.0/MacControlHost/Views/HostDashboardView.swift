import AppKit
import CoreImage
import CoreImage.CIFilterBuiltins
import MacControlCore
import SwiftUI

struct HostDashboardView: View {
    @ObservedObject var coordinator: HostCoordinator
    @ObservedObject var permissions: PermissionManager
    @State private var showPIN = true

    init(coordinator: HostCoordinator) {
        self.coordinator = coordinator
        self.permissions = coordinator.permissions
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                headerCard

                HStack(alignment: .top, spacing: 16) {
                    VStack(spacing: 16) {
                        permissionsCard
                        preferencesCard
                        networkEndpointsCard
                        relayCard
                    }
                    .frame(maxWidth: .infinity)

                    qrPairingCard
                        .frame(width: 280)
                }
            }
            .padding(24)
        }
        .frame(minWidth: 760, minHeight: 580)
        .background(Color(nsColor: .windowBackgroundColor))
    }

    private var headerCard: some View {
        HStack(spacing: 16) {
            Image("BrandIcon")
                .resizable()
                .scaledToFit()
                .frame(width: 56, height: 56)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .shadow(color: .black.opacity(0.25), radius: 6, y: 3)

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 8) {
                    Text(coordinator.hostComputerName)
                        .font(.title2.bold())
                    statusPill
                }
                Text(coordinator.statusLog)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if coordinator.connectedDeviceName != nil {
                VStack(alignment: .trailing, spacing: 6) {
                    if let transport = coordinator.activeTransportLabel {
                        Text(transport)
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.secondary)
                    }
                    Button(role: .destructive) {
                        coordinator.disconnectActiveClient()
                    } label: {
                        Label("Disconnect", systemImage: "xmark.circle.fill")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                }
            }
        }
        .padding(18)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private var statusPill: some View {
        let connected = coordinator.connectedDeviceName != nil
        return HStack(spacing: 5) {
            Circle()
                .fill(connected ? Color.green : (coordinator.isListeningLAN ? Color.blue : Color.orange))
                .frame(width: 8, height: 8)
            Text(connected ? "Connected: \(coordinator.connectedDeviceName!)" : (coordinator.isListeningLAN ? "Listening" : "Offline"))
                .font(.caption.weight(.semibold))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
        .background((connected ? Color.green : Color.blue).opacity(0.14), in: Capsule())
    }

    private var permissionsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("macOS System Permissions", systemImage: "lock.shield")
                    .font(.headline)
                Spacer()
                if !permissions.inputControlReady || !permissions.screenRecordingGranted {
                    Button("Reset Stuck Toggle") {
                        permissions.resetAndRepromptPermissions()
                    }
                    .controlSize(.small)
                    .help("Clears old Xcode build entries if System Settings shows ON while permissions still report untrusted.")

                    Button("Relaunch App") {
                        permissions.relaunchApp()
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
                    .help("Relaunches MacControl Host so macOS activates newly granted Screen Recording access.")
                }
            }

            permissionRow(
                title: "Accessibility (Mouse, Trackpad & Keyboard)",
                subtitle: "Required to click, drag, scroll, and type across macOS.",
                granted: permissions.inputControlReady,
                actionTitle: "Grant Accessibility",
                action: { permissions.requestAccessibility() }
            )

            Divider()

            permissionRow(
                title: "Screen & System Audio Recording",
                subtitle: "Required for Live Screen Touch streaming and Mac audio (click Relaunch App after enabling).",
                granted: permissions.screenRecordingGranted,
                actionTitle: "Grant Screen Recording",
                action: { permissions.requestScreenRecording() }
            )
        }
        .padding(16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func permissionRow(
        title: String,
        subtitle: String,
        granted: Bool,
        actionTitle: String,
        action: @escaping () -> Void
    ) -> some View {
        HStack(spacing: 12) {
            Image(systemName: granted ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .foregroundStyle(granted ? .green : .orange)
                .font(.title3)

            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }

            Spacer()

            if granted {
                Text("Ready")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.green)
            } else {
                Button(actionTitle, action: action)
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
            }
        }
    }

    private var preferencesCard: some View {
        HStack(spacing: 24) {
            Toggle(isOn: Binding(
                get: { coordinator.launchAtLogin },
                set: { coordinator.setLaunchAtLogin($0) }
            )) {
                Label("Start Automatically at Login", systemImage: "power.circle")
                    .font(.subheadline.weight(.medium))
            }
            .toggleStyle(.switch)

            Divider().frame(height: 20)

            Toggle(isOn: $coordinator.keepMacAwakeWhileConnected) {
                Label("Keep Mac Awake While iPhone Connected", systemImage: "bolt.shield")
                    .font(.subheadline.weight(.medium))
            }
            .toggleStyle(.switch)

            Spacer()
        }
        .padding(14)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var networkEndpointsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Local Wi-Fi, USB & Tailscale VPN", systemImage: "wifi")
                    .font(.headline)
                Spacer()
                Button {
                    coordinator.refreshNetworkAddresses()
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .buttonStyle(.borderless)
                .help("Refresh network interfaces")
            }

            endpointLine(
                label: "Bonjour Auto-Discovery",
                value: coordinator.isListeningLAN ? "\(coordinator.hostComputerName) (Port \(coordinator.listenPort))" : "Stopped"
            )

            endpointLine(
                label: "Local LAN / USB IP",
                value: coordinator.discoveredAddresses.localLANAddresses.isEmpty
                    ? "No LAN IPv4 detected"
                    : coordinator.discoveredAddresses.localLANAddresses.map { "\($0):\(coordinator.listenPort)" }.joined(separator: ", ")
            )

            endpointLine(
                label: "Tailscale / VPN IP",
                value: coordinator.discoveredAddresses.vpnTailscaleAddresses.isEmpty
                    ? "Not active (install Tailscale for direct VPN access)"
                    : coordinator.discoveredAddresses.vpnTailscaleAddresses.map { "\($0):\(coordinator.listenPort)" }.joined(separator: ", ")
            )
        }
        .padding(16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func endpointLine(label: String, value: String) -> some View {
        HStack {
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .font(.system(.caption, design: .monospaced))
                .textSelection(.enabled)
        }
    }

    private var relayCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Internet Relay (Anywhere Access)", systemImage: "globe")
                    .font(.headline)
                Spacer()
                Toggle("Enable Relay", isOn: $coordinator.relayEnabled)
                    .toggleStyle(.switch)
            }

            Text("End-to-end encrypted with X25519 + ChaCha20-Poly1305. The relay server only forwards opaque encrypted frames.")
                .font(.caption)
                .foregroundStyle(.secondary)

            HStack(spacing: 8) {
                TextField("Relay URL (e.g. wss://your-relay.example.com)", text: $coordinator.relayServerURL)
                    .textFieldStyle(.roundedBorder)
                    .font(.system(.caption, design: .monospaced))

                Button("Reconnect") {
                    coordinator.updateRelayConnection()
                }
                .disabled(!coordinator.relayEnabled)
            }

            HStack {
                Text("Room ID:")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(coordinator.relayRoomID)
                    .font(.system(.callout, design: .monospaced).bold())
                    .textSelection(.enabled)
                Button {
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(coordinator.relayRoomID, forType: .string)
                } label: {
                    Image(systemName: "doc.on.doc")
                }
                .buttonStyle(.borderless)

                Button("New Room") {
                    coordinator.regenerateRoomID()
                }
                .controlSize(.small)

                Spacer()

                Text(coordinator.relayStatusText)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var qrPairingCard: some View {
        VStack(spacing: 14) {
            Label("Pair iPhone", systemImage: "qrcode.viewfinder")
                .font(.headline)

            if let qrImage = generateQRCodeImage(from: coordinator.makeQRPayload().toURIString()) {
                Image(nsImage: qrImage)
                    .interpolation(.none)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 190, height: 190)
                    .padding(10)
                    .background(Color.white, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }

            Text("Scan from the MacControl iOS app or enter this Pairing PIN:")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            HStack(spacing: 8) {
                Text(showPIN ? coordinator.pairingPIN : "••••••")
                    .font(.system(size: 26, weight: .bold, design: .monospaced))
                    .tracking(3)

                Button {
                    showPIN.toggle()
                } label: {
                    Image(systemName: showPIN ? "eye.slash" : "eye")
                }
                .buttonStyle(.borderless)
            }
            .padding(.vertical, 6)
            .padding(.horizontal, 14)
            .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 10, style: .continuous))

            HStack(spacing: 10) {
                Button {
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(coordinator.pairingPIN, forType: .string)
                } label: {
                    Label("Copy PIN", systemImage: "doc.on.doc")
                }
                .controlSize(.small)

                Button {
                    coordinator.regeneratePIN()
                } label: {
                    Label("Reset PIN", systemImage: "arrow.triangle.2.circlepath")
                }
                .controlSize(.small)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func generateQRCodeImage(from text: String) -> NSImage? {
        let context = CIContext()
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(text.utf8)
        filter.correctionLevel = "M"
        guard let output = filter.outputImage else { return nil }
        let scaled = output.transformed(by: CGAffineTransform(scaleX: 10, y: 10))
        guard let cgImg = context.createCGImage(scaled, from: scaled.extent) else { return nil }
        return NSImage(cgImage: cgImg, size: NSSize(width: scaled.extent.width, height: scaled.extent.height))
    }
}
