import SwiftUI

@main
struct MacControlHostApp: App {
    @StateObject private var coordinator = HostCoordinator()
    @Environment(\.openWindow) private var openWindow

    var body: some Scene {
        Window("MacControl Host", id: "dashboard") {
            HostDashboardView(coordinator: coordinator)
        }
        .defaultSize(width: 800, height: 610)

        MenuBarExtra {
            VStack(alignment: .leading, spacing: 8) {
                if let device = coordinator.connectedDeviceName {
                    Label("Connected: \(device)", systemImage: "checkmark.circle.fill")
                    if let transport = coordinator.activeTransportLabel {
                        Text(transport)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Button("Disconnect iPhone", role: .destructive) {
                        coordinator.disconnectActiveClient()
                    }
                } else {
                    Label("Waiting for iPhone (PIN: \(coordinator.pairingPIN))", systemImage: "antenna.radiowaves.left.and.right")
                }

                Divider()

                Button("Open MacControl Dashboard…") {
                    openWindow(id: "dashboard")
                    NSApplication.shared.activate(ignoringOtherApps: true)
                }

                Button("Regenerate Pairing PIN") {
                    coordinator.regeneratePIN()
                }

                Toggle("Start at Login", isOn: Binding(
                    get: { coordinator.launchAtLogin },
                    set: { coordinator.setLaunchAtLogin($0) }
                ))

                Divider()

                Button("Quit MacControl Host") {
                    NSApplication.shared.terminate(nil)
                }
            }
            .padding(4)
        } label: {
            Image(systemName: coordinator.connectedDeviceName != nil ? "iphone.radiowaves.left.and.right" : "laptopcomputer.and.iphone")
        }
    }
}
