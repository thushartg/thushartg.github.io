import AppKit
import Combine
import Foundation
import IOKit.pwr_mgt
import MacControlCore
import Network
import ServiceManagement

@MainActor
final class HostCoordinator: ObservableObject {
    @Published var isListeningLAN: Bool = false
    @Published var listenPort: UInt16 = MacControlConstants.defaultPort
    @Published var pairingPIN: String
    @Published var discoveredAddresses = DiscoveredHostAddresses()

    @Published var relayEnabled: Bool = false {
        didSet {
            UserDefaults.standard.set(relayEnabled, forKey: "mc.relayEnabled")
            updateRelayConnection()
        }
    }
    @Published var relayServerURL: String {
        didSet {
            UserDefaults.standard.set(relayServerURL, forKey: "mc.relayServerURL")
        }
    }
    @Published var relayRoomID: String {
        didSet {
            UserDefaults.standard.set(relayRoomID, forKey: "mc.relayRoomID")
        }
    }
    @Published var relayStatusText: String = "Disabled"

    @Published var connectedDeviceName: String?
    @Published var activeTransportLabel: String?
    @Published var streamConfig = StreamConfiguration()
    @Published var statusLog: String = "Ready to accept iPhone connection"
    @Published var videoFramesSent: Int = 0
    @Published var launchAtLogin: Bool = (SMAppService.mainApp.status == .enabled)
    @Published var keepMacAwakeWhileConnected: Bool = {
        if UserDefaults.standard.object(forKey: "mc.keepMacAwake") == nil { return true }
        return UserDefaults.standard.bool(forKey: "mc.keepMacAwake")
    }() {
        didSet {
            UserDefaults.standard.set(keepMacAwakeWhileConnected, forKey: "mc.keepMacAwake")
            updateSleepAssertion()
        }
    }

    private var sleepAssertionID: IOPMAssertionID = 0

    let permissions = PermissionManager()
    private let inputInjector = MacInputInjector()
    private lazy var systemController = SystemController(inputInjector: inputInjector)
    private let clipboardMonitor = ClipboardMonitor()
    private let streamEngine = ScreenStreamEngine()

    private var listener: NWListener?
    private let listenerQueue = DispatchQueue(label: "com.maccontrol.host.listener", qos: .userInteractive)

    private var relayTransport: WebSocketRelayTransport?
    private var relayReconnectTask: Task<Void, Never>?

    // Active peer session state
    private var activeTransport: WireTransport?
    private var pendingHandshakeMaterial: DerivedHandshakeMaterial?
    private var cryptoSession: CryptoSession?

    // Rate limiting against online PIN brute force
    private var failedPinTimestamps: [Date] = []
    private var addressRefreshTimer: Timer?

    var hostComputerName: String {
        Host.current().localizedName ?? ProcessInfo.processInfo.hostName
    }

    init() {
        let savedPIN = UserDefaults.standard.string(forKey: "mc.pairingPIN")
        if let savedPIN, savedPIN.count == 6 {
            self.pairingPIN = savedPIN
        } else {
            let generated = String(format: "%06d", Int.random(in: 100_000...999_999))
            self.pairingPIN = generated
            UserDefaults.standard.set(generated, forKey: "mc.pairingPIN")
        }

        self.relayServerURL = UserDefaults.standard.string(forKey: "mc.relayServerURL") ?? "ws://localhost:8787"
        if let savedRoom = UserDefaults.standard.string(forKey: "mc.relayRoomID"), !savedRoom.isEmpty {
            self.relayRoomID = savedRoom
        } else {
            let room = Self.generateRoomCode()
            self.relayRoomID = room
            UserDefaults.standard.set(room, forKey: "mc.relayRoomID")
        }
        let wasRelayEnabled = UserDefaults.standard.bool(forKey: "mc.relayEnabled")

        setupCallbacks()
        refreshNetworkAddresses()
        startAddressPolling()
        startLANListener()

        if wasRelayEnabled {
            self.relayEnabled = true
        }
    }

    func regeneratePIN() {
        let newPIN = String(format: "%06d", Int.random(in: 100_000...999_999))
        pairingPIN = newPIN
        UserDefaults.standard.set(newPIN, forKey: "mc.pairingPIN")
        statusLog = "Generated new Pairing PIN."
    }

    func regenerateRoomID() {
        relayRoomID = Self.generateRoomCode()
        if relayEnabled {
            updateRelayConnection()
        }
    }

    func disconnectActiveClient() {
        teardownActiveSession(status: "Disconnected active iPhone session.")
        if relayEnabled {
            updateRelayConnection()
        }
    }

    func makeQRPayload() -> PairingQRPayload {
        PairingQRPayload(
            hostName: hostComputerName,
            localHost: discoveredAddresses.primaryLAN,
            vpnHost: discoveredAddresses.primaryVPN,
            port: listenPort,
            relayURL: relayEnabled ? relayServerURL : nil,
            relayRoomID: relayEnabled ? relayRoomID : nil,
            pin: pairingPIN
        )
    }

    func refreshNetworkAddresses() {
        discoveredAddresses = NetworkAddressDiscovery.currentIPv4Addresses()
    }

    func setLaunchAtLogin(_ enabled: Bool) {
        do {
            if enabled {
                try SMAppService.mainApp.register()
            } else {
                try SMAppService.mainApp.unregister()
            }
            launchAtLogin = (SMAppService.mainApp.status == .enabled)
        } catch {
            launchAtLogin = (SMAppService.mainApp.status == .enabled)
            statusLog = "Launch at Login requires running MacControl Host from /Applications."
        }
    }

    private func updateSleepAssertion() {
        let shouldHold = keepMacAwakeWhileConnected && (connectedDeviceName != nil)
        if shouldHold && sleepAssertionID == 0 {
            let reason = "MacControl active remote session" as CFString
            IOPMAssertionCreateWithName(
                kIOPMAssertionTypePreventUserIdleDisplaySleep as CFString,
                IOPMAssertionLevel(kIOPMAssertionLevelOn),
                reason,
                &sleepAssertionID
            )
        } else if !shouldHold && sleepAssertionID != 0 {
            IOPMAssertionRelease(sleepAssertionID)
            sleepAssertionID = 0
        }
    }

    // MARK: - Setup & Wiring

    private func setupCallbacks() {
        permissions.onPermissionsChanged = { [weak self] inputReady, screenReady in
            Task { @MainActor in
                guard let self else { return }
                if self.connectedDeviceName != nil {
                    self.sendHostInfoSnapshot()
                    if inputReady && screenReady {
                        self.sendControlMessage(.statusBanner(message: "Mac permissions active.", isWarning: false))
                    }
                    if screenReady && (self.streamConfig.enabled || self.streamConfig.audioEnabled) {
                        _ = await self.streamEngine.refreshDisplays()
                        await self.streamEngine.startOrUpdate(with: self.streamConfig)
                    }
                }
            }
        }

        clipboardMonitor.onLocalClipboardChange = { [weak self] newText in
            guard let self else { return }
            self.sendControlMessage(.clipboardUpdate(text: newText))
        }

        streamEngine.onVideoPacket = { [weak self] packet in
            guard let self else { return }
            self.sendEncryptedMedia(payload: packet.encode(), kind: .encryptedVideo, droppable: !packet.isKeyframe)
            Task { @MainActor in
                self.videoFramesSent &+= 1
            }
        }

        streamEngine.onAudioPacket = { [weak self] packet in
            guard let self else { return }
            self.sendEncryptedMedia(payload: packet.encode(), kind: .encryptedAudio, droppable: true)
        }

        streamEngine.onStreamError = { [weak self] message in
            Task { @MainActor in
                guard let self else { return }
                self.statusLog = message
                self.sendControlMessage(.statusBanner(message: message, isWarning: true))
            }
        }
    }

    private func startAddressPolling() {
        addressRefreshTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.refreshNetworkAddresses()
            }
        }
    }

    // MARK: - LAN / USB / Tailscale Listener (Bonjour + Direct TCP)

    func startLANListener() {
        listener?.cancel()
        do {
            let port = NWEndpoint.Port(rawValue: listenPort) ?? NWEndpoint.Port(integerLiteral: MacControlConstants.defaultPort)
            let nwListener = try NWListener(using: TCPWireTransport.makeLowLatencyParameters(), on: port)
            nwListener.service = NWListener.Service(name: hostComputerName, type: MacControlConstants.bonjourServiceType)

            nwListener.stateUpdateHandler = { [weak self] state in
                Task { @MainActor in
                    guard let self else { return }
                    switch state {
                    case .ready:
                        self.isListeningLAN = true
                        if let actualPort = nwListener.port?.rawValue {
                            self.listenPort = actualPort
                        }
                        self.statusLog = "Listening on port \(self.listenPort) (Wi-Fi / USB / Tailscale)"
                    case .failed(let error):
                        self.isListeningLAN = false
                        self.statusLog = "Listener error: \(error.localizedDescription)"
                    case .cancelled:
                        self.isListeningLAN = false
                    default:
                        break
                    }
                }
            }

            nwListener.newConnectionHandler = { [weak self] nwConn in
                Task { @MainActor in
                    guard let self else { return }
                    let label = "Local / Direct (\(nwConn.endpoint.debugDescription))"
                    let transport = TCPWireTransport(connection: nwConn, label: label)
                    self.acceptIncomingTransport(transport, isFromRelay: false)
                }
            }

            nwListener.start(queue: listenerQueue)
            self.listener = nwListener
        } catch {
            isListeningLAN = false
            statusLog = "Could not start listener: \(error.localizedDescription)"
        }
    }

    // MARK: - Internet Relay Connection

    func updateRelayConnection() {
        relayReconnectTask?.cancel()
        relayReconnectTask = nil
        relayTransport?.close()
        relayTransport = nil

        guard relayEnabled else {
            relayStatusText = "Disabled"
            return
        }

        guard let ws = WebSocketRelayTransport(baseRelayURL: relayServerURL, roomID: relayRoomID, role: .host) else {
            relayStatusText = "Invalid Relay URL or Room ID"
            return
        }

        relayStatusText = "Connecting to relay…"
        ws.onStateChange = { [weak self, weak ws] state in
            Task { @MainActor in
                guard let self, let ws, self.relayTransport === ws else { return }
                switch state {
                case .connecting:
                    self.relayStatusText = "Connecting…"
                case .connected:
                    self.relayStatusText = "Waiting in room \(self.relayRoomID)"
                case .disconnected(let reason):
                    if self.activeTransport === ws {
                        self.teardownActiveSession(status: "Relay session ended.")
                    }
                    self.relayStatusText = reason.map { "Disconnected: \($0)" } ?? "Disconnected"
                    self.scheduleRelayReconnect()
                }
            }
        }

        ws.onRelayEvent = { [weak self, weak ws] notice in
            Task { @MainActor in
                guard let self, let ws, self.relayTransport === ws else { return }
                if notice.peerConnected {
                    self.relayStatusText = "iPhone joined room \(self.relayRoomID)"
                    self.acceptIncomingTransport(ws, isFromRelay: true)
                } else if self.activeTransport === ws {
                    self.teardownActiveSession(status: "iPhone left relay room.")
                    self.relayStatusText = "Waiting in room \(self.relayRoomID)"
                }
            }
        }

        ws.onFrame = { [weak self, weak ws] frame in
            Task { @MainActor in
                guard let self, let ws else { return }
                if self.activeTransport !== ws {
                    self.acceptIncomingTransport(ws, isFromRelay: true)
                }
                self.handleIncomingFrame(frame, from: ws)
            }
        }

        self.relayTransport = ws
        ws.start()
    }

    private func scheduleRelayReconnect() {
        guard relayEnabled else { return }
        relayReconnectTask?.cancel()
        relayReconnectTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            guard let self, !Task.isCancelled, self.relayEnabled else { return }
            self.updateRelayConnection()
        }
    }

    // MARK: - Session & Handshake Lifecycle

    private func acceptIncomingTransport(_ transport: WireTransport, isFromRelay: Bool) {
        if let existing = activeTransport, existing !== transport {
            if existing !== relayTransport {
                existing.close()
            }
        }
        cryptoSession = nil
        pendingHandshakeMaterial = nil
        activeTransport = transport
        activeTransportLabel = isFromRelay ? "Internet Relay (\(relayRoomID))" : "Local / VPN"

        if !isFromRelay {
            transport.onStateChange = { [weak self, weak transport] state in
                Task { @MainActor in
                    guard let self, let transport, self.activeTransport === transport else { return }
                    if case .disconnected(let err) = state {
                        self.teardownActiveSession(status: err ?? "iPhone disconnected.")
                    }
                }
            }
            transport.onFrame = { [weak self, weak transport] frame in
                Task { @MainActor in
                    guard let self, let transport, self.activeTransport === transport else { return }
                    self.handleIncomingFrame(frame, from: transport)
                }
            }
            transport.start()
        }
    }

    private func teardownActiveSession(status: String) {
        let previous = activeTransport
        activeTransport = nil
        activeTransportLabel = nil
        connectedDeviceName = nil
        pendingHandshakeMaterial = nil
        cryptoSession = nil
        clipboardMonitor.stop()
        updateSleepAssertion()
        statusLog = status

        if let previous, previous !== relayTransport {
            previous.close()
        }
        Task {
            await streamEngine.stop()
        }
    }

    private func handleIncomingFrame(_ frame: WireFrame, from transport: WireTransport) {
        switch frame.kind {
        case .handshakeHello:
            handleClientHello(frame.payload, from: transport)

        case .handshakeClientAuth:
            handleClientAuth(frame.payload, from: transport)

        case .encryptedControl:
            guard let crypto = cryptoSession else { return }
            do {
                let plain = try crypto.open(frame.payload, associatedKind: .encryptedControl)
                let message = try JSONDecoder().decode(ClientControlMessage.self, from: plain)
                handleControlMessage(message)
            } catch {
                statusLog = "Security decode error: \(error.localizedDescription)"
            }

        default:
            break
        }
    }

    private func handleClientHello(_ payload: Data, from transport: WireTransport) {
        // Check brute-force rate limit (max 5 failed attempts in 60 seconds)
        let now = Date()
        failedPinTimestamps.removeAll { now.timeIntervalSince($0) > 60 }
        if failedPinTimestamps.count >= 5 {
            let reject = HandshakeReject(reason: "Too many failed PIN attempts. Wait 60 seconds.", retryAfterSeconds: 60)
            if let data = try? JSONEncoder().encode(reject) {
                transport.send(WireFrame(kind: .handshakeReject, payload: data), isDroppableMedia: false)
            }
            if transport !== relayTransport {
                transport.close()
            }
            statusLog = "Blocked connection due to PIN rate limit."
            return
        }

        guard let clientHello = try? JSONDecoder().decode(HandshakeHello.self, from: payload) else {
            return
        }

        do {
            let hs = HandshakeContext(role: .host, deviceName: hostComputerName)
            let hostHello = hs.makeHello()
            let material = try hs.deriveKeys(peerHello: clientHello, pin: pairingPIN)
            self.pendingHandshakeMaterial = material

            let helloBytes = try JSONEncoder().encode(hostHello)
            let proofBytes = try JSONEncoder().encode(material.myAuthProof())
            transport.send(WireFrame(kind: .handshakeHello, payload: helloBytes), isDroppableMedia: false)
            transport.send(WireFrame(kind: .handshakeHostAuth, payload: proofBytes), isDroppableMedia: false)
        } catch {
            statusLog = "Handshake failed: \(error.localizedDescription)"
        }
    }

    private func handleClientAuth(_ payload: Data, from transport: WireTransport) {
        guard let material = pendingHandshakeMaterial,
              let proof = try? JSONDecoder().decode(HandshakeAuthProof.self, from: payload) else {
            return
        }

        guard material.verifyPeerProof(proof) else {
            failedPinTimestamps.append(Date())
            pendingHandshakeMaterial = nil
            let reject = HandshakeReject(reason: "Incorrect Pairing PIN.")
            if let data = try? JSONEncoder().encode(reject) {
                transport.send(WireFrame(kind: .handshakeReject, payload: data), isDroppableMedia: false)
            }
            if transport !== relayTransport {
                transport.close()
            }
            statusLog = "Rejected connection (wrong Pairing PIN)."
            return
        }

        failedPinTimestamps.removeAll()
        pendingHandshakeMaterial = nil
        cryptoSession = material.buildCryptoSession()
        connectedDeviceName = material.peerDeviceName
        videoFramesSent = 0
        updateSleepAssertion()
        statusLog = "Connected to \(material.peerDeviceName)"

        permissions.refresh()
        clipboardMonitor.start()

        Task { @MainActor in
            _ = await streamEngine.refreshDisplays()
            sendHostInfoSnapshot()
            if let clip = clipboardMonitor.currentText(), !clip.isEmpty {
                sendControlMessage(.clipboardUpdate(text: clip))
            }
            if !permissions.inputControlReady {
                sendControlMessage(.statusBanner(
                    message: "Grant Accessibility in MacControl Host on your Mac to enable mouse & keyboard control.",
                    isWarning: true
                ))
            }
            if streamConfig.enabled || streamConfig.audioEnabled {
                await streamEngine.startOrUpdate(with: streamConfig)
            }
        }
    }

    // MARK: - Control Message Execution

    private func handleControlMessage(_ message: ClientControlMessage) {
        switch message {
        case .pointerMoveNormalized(let x, let y, let displayID):
            inputInjector.movePointerNormalized(x: x, y: y, displayID: displayID ?? streamEngine.activeDisplayID)

        case .pointerButton(let x, let y, let button, let isDown, let clickCount, let displayID):
            inputInjector.sendPointerButton(
                normalizedX: x,
                normalizedY: y,
                button: button,
                isDown: isDown,
                clickCount: clickCount,
                displayID: displayID ?? streamEngine.activeDisplayID
            )

        case .trackpadDelta(let dx, let dy, let isDragging):
            inputInjector.moveTrackpadDelta(dx: dx, dy: dy, isDragging: isDragging)

        case .trackpadClick(let button, let clickCount):
            inputInjector.sendTrackpadClick(button: button, clickCount: clickCount)

        case .scroll(let dx, let dy, let phase):
            inputInjector.sendScroll(dx: dx, dy: dy, phase: phase)

        case .keyEvent(let keyCode, let modifiers, let isDown):
            inputInjector.sendKeyEvent(keyCode: keyCode, modifiers: modifiers, isDown: isDown)

        case .keyShortcut(let keyCode, let modifiers):
            inputInjector.sendKeyShortcut(keyCode: keyCode, modifiers: modifiers)

        case .textInput(let text):
            inputInjector.sendUnicodeText(text)

        case .systemCommand(let action):
            systemController.execute(action)
            sendHostInfoSnapshot()

        case .configureStream(let newConfig):
            self.streamConfig = newConfig
            Task { @MainActor in
                permissions.refresh()
                _ = await streamEngine.refreshDisplays()
                await streamEngine.startOrUpdate(with: newConfig)
                sendHostInfoSnapshot()
            }

        case .requestKeyframe:
            streamEngine.requestKeyframe()

        case .setClipboard(let text):
            clipboardMonitor.writeFromRemote(text)

        case .requestClipboard:
            if let text = clipboardMonitor.currentText() {
                sendControlMessage(.clipboardUpdate(text: text))
            }

        case .ping(let clientTs):
            sendControlMessage(.pong(clientTimestampMs: clientTs))
        }
    }

    private func sendHostInfoSnapshot() {
        let audio = systemController.readAudioState()
        let info = HostInfo(
            hostName: hostComputerName,
            osVersion: ProcessInfo.processInfo.operatingSystemVersionString,
            displays: streamEngine.availableDisplays,
            activeDisplayID: streamEngine.activeDisplayID,
            accessibilityGranted: permissions.inputControlReady,
            screenRecordingGranted: permissions.screenRecordingGranted,
            volume: audio.volume,
            isMuted: audio.isMuted,
            streamConfig: streamConfig
        )
        sendControlMessage(.hostInfo(info))
    }

    private func sendControlMessage(_ message: HostControlMessage) {
        guard let crypto = cryptoSession,
              let transport = activeTransport,
              let encoded = try? JSONEncoder().encode(message),
              let sealed = try? crypto.seal(encoded, associatedKind: .encryptedControl) else {
            return
        }
        transport.send(WireFrame(kind: .encryptedControl, payload: sealed), isDroppableMedia: false)
    }

    nonisolated private func sendEncryptedMedia(payload: Data, kind: FrameKind, droppable: Bool) {
        Task { @MainActor [weak self] in
            guard let self,
                  let crypto = self.cryptoSession,
                  let transport = self.activeTransport,
                  let sealed = try? crypto.seal(payload, associatedKind: kind) else {
                return
            }
            transport.send(WireFrame(kind: kind, payload: sealed), isDroppableMedia: droppable)
        }
    }

    private static func generateRoomCode() -> String {
        let chars = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        let p1 = String((0..<4).map { _ in chars.randomElement()! })
        let p2 = String((0..<4).map { _ in chars.randomElement()! })
        return "MAC-\(p1)-\(p2)"
    }
}
