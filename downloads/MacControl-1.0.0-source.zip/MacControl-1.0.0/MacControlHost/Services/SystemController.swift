import AppKit
import AudioToolbox
import CoreAudio
import Foundation
import MacControlCore

/// Executes macOS hardware media/volume/brightness HID events, CoreAudio volume adjustments,
/// Mission Control / workspace triggers, and display/system sleep/lock commands.
final class SystemController {
    // IOKit / hidsystem NX_KEYTYPE constants
    private enum NXKeyType: Int32 {
        case soundUp = 0
        case soundDown = 1
        case brightnessUp = 2
        case brightnessDown = 3
        case mute = 7
        case play = 16
        case next = 17
        case previous = 18
    }

    private let inputInjector: MacInputInjector

    init(inputInjector: MacInputInjector) {
        self.inputInjector = inputInjector
    }

    func execute(_ action: SystemAction) {
        switch action {
        case .volumeUp:
            postHIDAuxKey(.soundUp)
        case .volumeDown:
            postHIDAuxKey(.soundDown)
        case .setVolume(let level):
            setOutputVolume(level)
        case .toggleMute:
            postHIDAuxKey(.mute)
        case .brightnessUp:
            postHIDAuxKey(.brightnessUp)
        case .brightnessDown:
            postHIDAuxKey(.brightnessDown)
        case .mediaPlayPause:
            postHIDAuxKey(.play)
        case .mediaNext:
            postHIDAuxKey(.next)
        case .mediaPrevious:
            postHIDAuxKey(.previous)
        case .missionControl:
            launchSystemApp(named: "Mission Control")
        case .appExpose:
            inputInjector.sendKeyShortcut(keyCode: MacKeyCode.downArrow, modifiers: [.control])
        case .showDesktop:
            inputInjector.sendKeyShortcut(keyCode: MacKeyCode.f11, modifiers: [.function])
        case .launchpad:
            launchSystemApp(named: "Apps") ?? launchSystemApp(named: "Launchpad")
        case .spotlight:
            inputInjector.sendKeyShortcut(keyCode: MacKeyCode.space, modifiers: [.command])
        case .lockScreen:
            // Native macOS Lock Screen shortcut (Ctrl + Cmd + Q)
            inputInjector.sendKeyShortcut(keyCode: MacKeyCode.ansiQ, modifiers: [.control, .command])
        case .sleepDisplay:
            runDetachedProcess("/usr/bin/pmset", arguments: ["displaysleepnow"])
        case .sleepMac:
            runDetachedProcess("/usr/bin/pmset", arguments: ["sleepnow"])
        }
    }

    func readAudioState() -> (volume: Float, isMuted: Bool) {
        guard let deviceID = defaultOutputAudioDevice() else {
            return (0.5, false)
        }
        var vol: Float32 = 0.5
        var volSize = UInt32(MemoryLayout<Float32>.size)
        var volAddr = AudioObjectPropertyAddress(
            mSelector: kAudioHardwareServiceDeviceProperty_VirtualMainVolume,
            mScope: kAudioDevicePropertyScopeOutput,
            mElement: kAudioObjectPropertyElementMain
        )
        if AudioObjectHasProperty(deviceID, &volAddr) {
            AudioObjectGetPropertyData(deviceID, &volAddr, 0, nil, &volSize, &vol)
        }

        var muted: UInt32 = 0
        var muteSize = UInt32(MemoryLayout<UInt32>.size)
        var muteAddr = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyMute,
            mScope: kAudioDevicePropertyScopeOutput,
            mElement: kAudioObjectPropertyElementMain
        )
        if AudioObjectHasProperty(deviceID, &muteAddr) {
            AudioObjectGetPropertyData(deviceID, &muteAddr, 0, nil, &muteSize, &muted)
        }
        return (min(1.0, max(0.0, vol)), muted != 0)
    }

    // MARK: - Internals

    private func setOutputVolume(_ requested: Float) {
        let clamped = min(1.0, max(0.0, requested))
        guard let deviceID = defaultOutputAudioDevice() else { return }

        var volume = Float32(clamped)
        let size = UInt32(MemoryLayout<Float32>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwareServiceDeviceProperty_VirtualMainVolume,
            mScope: kAudioDevicePropertyScopeOutput,
            mElement: kAudioObjectPropertyElementMain
        )
        if AudioObjectHasProperty(deviceID, &address) {
            AudioObjectSetPropertyData(deviceID, &address, 0, nil, size, &volume)
        }

        // Unmute automatically if setting positive volume
        if clamped > 0.01 {
            var unmute: UInt32 = 0
            let muteSize = UInt32(MemoryLayout<UInt32>.size)
            var muteAddr = AudioObjectPropertyAddress(
                mSelector: kAudioDevicePropertyMute,
                mScope: kAudioDevicePropertyScopeOutput,
                mElement: kAudioObjectPropertyElementMain
            )
            if AudioObjectHasProperty(deviceID, &muteAddr) {
                AudioObjectSetPropertyData(deviceID, &muteAddr, 0, nil, muteSize, &unmute)
            }
        }
    }

    private func defaultOutputAudioDevice() -> AudioDeviceID? {
        var deviceID = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultOutputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain
        )
        let status = AudioObjectGetPropertyData(
            AudioObjectID(kAudioObjectSystemObject),
            &address,
            0,
            nil,
            &size,
            &deviceID
        )
        return status == noErr && deviceID != kAudioObjectUnknown ? deviceID : nil
    }

    private func postHIDAuxKey(_ key: NXKeyType) {
        func send(down: Bool) {
            let flags = NSEvent.ModifierFlags(rawValue: down ? 0x0a00 : 0x0b00)
            let data1 = Int((key.rawValue << 16) | Int32(down ? 0x0a00 : 0x0b00))
            let nsEvent = NSEvent.otherEvent(
                with: .systemDefined,
                location: .zero,
                modifierFlags: flags,
                timestamp: 0,
                windowNumber: 0,
                context: nil,
                subtype: 8,
                data1: data1,
                data2: -1
            )
            nsEvent?.cgEvent?.post(tap: .cghidEventTap)
        }
        send(down: true)
        send(down: false)
    }

    @discardableResult
    private func launchSystemApp(named appName: String) -> Bool? {
        let candidates = [
            "/System/Applications/\(appName).app",
            "/Applications/\(appName).app"
        ]
        for path in candidates where FileManager.default.fileExists(atPath: path) {
            NSWorkspace.shared.openApplication(
                at: URL(fileURLWithPath: path),
                configuration: NSWorkspace.OpenConfiguration()
            )
            return true
        }
        return nil
    }

    private func runDetachedProcess(_ executable: String, arguments: [String]) {
        let proc = Process()
        proc.executableURL = URL(fileURLWithPath: executable)
        proc.arguments = arguments
        try? proc.run()
    }
}
