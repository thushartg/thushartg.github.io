import AppKit
import Foundation

@MainActor
final class ClipboardMonitor {
    var onLocalClipboardChange: ((String) -> Void)?

    private var timer: Timer?
    private var lastObservedChangeCount: Int
    private var lastInjectedString: String?

    init() {
        self.lastObservedChangeCount = NSPasteboard.general.changeCount
    }

    func start() {
        stop()
        lastObservedChangeCount = NSPasteboard.general.changeCount
        timer = Timer.scheduledTimer(withTimeInterval: 0.8, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.checkPasteboard()
            }
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
    }

    func currentText() -> String? {
        NSPasteboard.general.string(forType: .string)
    }

    func writeFromRemote(_ text: String) {
        lastInjectedString = text
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.setString(text, forType: .string)
        lastObservedChangeCount = pb.changeCount
    }

    private func checkPasteboard() {
        let pb = NSPasteboard.general
        guard pb.changeCount != lastObservedChangeCount else { return }
        lastObservedChangeCount = pb.changeCount
        guard let str = pb.string(forType: .string), !str.isEmpty else { return }
        if str == lastInjectedString {
            lastInjectedString = nil
            return
        }
        onLocalClipboardChange?(str)
    }
}
