import AppKit
import ApplicationServices
import CoreGraphics
import Foundation
import MacControlCore

final class MacInputInjector {
    private var cachedEventSource: CGEventSource?
    private var wasTrustedWhenCreated = false
    private var isLeftButtonDown = false
    private var isRightButtonDown = false
    private var isCenterButtonDown = false
    private var isTrackpadDragging = false

    init() {}

    /// Dynamically refreshes CGEventSource once Accessibility/PostEvent permission becomes active,
    /// avoiding a stale untrusted source created prior to user approval.
    private var eventSource: CGEventSource? {
        let trustedNow = AXIsProcessTrusted() && CGPreflightPostEventAccess()
        if cachedEventSource == nil || (trustedNow && !wasTrustedWhenCreated) {
            let src = CGEventSource(stateID: .hidSystemState) ?? CGEventSource(stateID: .combinedSessionState)
            src?.localEventsSuppressionInterval = 0.0
            cachedEventSource = src
            wasTrustedWhenCreated = trustedNow
        }
        return cachedEventSource
    }

    // MARK: - Absolute Screen Touch

    func movePointerNormalized(x: Double, y: Double, displayID: UInt32?) {
        let point = quartzPoint(normalizedX: x, normalizedY: y, displayID: displayID)
        let eventType: CGEventType
        let mouseButton: CGMouseButton
        if isLeftButtonDown {
            eventType = .leftMouseDragged
            mouseButton = .left
        } else if isRightButtonDown {
            eventType = .rightMouseDragged
            mouseButton = .right
        } else {
            eventType = .mouseMoved
            mouseButton = .left
        }
        guard let event = CGEvent(
            mouseEventSource: eventSource,
            mouseType: eventType,
            mouseCursorPosition: point,
            mouseButton: mouseButton
        ) else { return }
        event.post(tap: .cghidEventTap)
    }

    func sendPointerButton(
        normalizedX: Double?,
        normalizedY: Double?,
        button: MouseButton,
        isDown: Bool,
        clickCount: Int,
        displayID: UInt32?
    ) {
        let point: CGPoint
        if let nx = normalizedX, let ny = normalizedY {
            point = quartzPoint(normalizedX: nx, normalizedY: ny, displayID: displayID)
        } else {
            point = currentCursorQuartzLocation()
        }
        postMouseButton(at: point, button: button, isDown: isDown, clickCount: max(1, clickCount))
    }

    // MARK: - Relative Magic Trackpad

    func moveTrackpadDelta(dx: Double, dy: Double, isDragging: Bool) {
        if isDragging && !isTrackpadDragging {
            isTrackpadDragging = true
            isLeftButtonDown = true
            let start = currentCursorQuartzLocation()
            postMouseButton(at: start, button: .left, isDown: true, clickCount: 1)
        } else if !isDragging && isTrackpadDragging {
            isTrackpadDragging = false
            isLeftButtonDown = false
            let end = currentCursorQuartzLocation()
            postMouseButton(at: end, button: .left, isDown: false, clickCount: 1)
        }

        let speed = hypot(dx, dy)
        // Natural Magic-Trackpad-like curve: 1.0x for fine pixel targeting, up to 2.4x for fast swipes
        let gain = min(2.4, 1.05 + speed * 0.045)
        let scaledDX = CGFloat(dx * gain)
        let scaledDY = CGFloat(dy * gain)

        let current = currentCursorQuartzLocation()
        let next = clampToActiveDisplays(CGPoint(x: current.x + scaledDX, y: current.y + scaledDY))

        let eventType: CGEventType = isLeftButtonDown ? .leftMouseDragged : .mouseMoved
        guard let event = CGEvent(
            mouseEventSource: eventSource,
            mouseType: eventType,
            mouseCursorPosition: next,
            mouseButton: .left
        ) else { return }
        event.setIntegerValueField(.mouseEventDeltaX, value: Int64(scaledDX.rounded()))
        event.setIntegerValueField(.mouseEventDeltaY, value: Int64(scaledDY.rounded()))
        event.post(tap: .cghidEventTap)
    }

    func sendTrackpadClick(button: MouseButton, clickCount: Int) {
        if isTrackpadDragging {
            isTrackpadDragging = false
            isLeftButtonDown = false
            let loc = currentCursorQuartzLocation()
            postMouseButton(at: loc, button: .left, isDown: false, clickCount: 1)
            return
        }
        let loc = currentCursorQuartzLocation()
        let count = max(1, clickCount)
        for step in 1...count {
            postMouseButton(at: loc, button: button, isDown: true, clickCount: step)
            postMouseButton(at: loc, button: button, isDown: false, clickCount: step)
        }
    }

    func sendScroll(dx: Double, dy: Double, phase: ScrollPhase) {
        guard let event = CGEvent(
            scrollWheelEvent2Source: eventSource,
            units: .pixel,
            wheelCount: 2,
            wheel1: Int32(dy.rounded()),
            wheel2: Int32(dx.rounded()),
            wheel3: 0
        ) else { return }
        event.setIntegerValueField(.scrollWheelEventIsContinuous, value: 1)
        event.post(tap: .cghidEventTap)
    }

    // MARK: - Keyboard & Text

    func sendKeyEvent(keyCode: UInt16, modifiers: KeyModifiers, isDown: Bool) {
        guard let event = CGEvent(keyboardEventSource: eventSource, virtualKey: CGKeyCode(keyCode), keyDown: isDown) else {
            return
        }
        event.flags = cgEventFlags(from: modifiers)
        event.post(tap: .cghidEventTap)
    }

    func sendKeyShortcut(keyCode: UInt16, modifiers: KeyModifiers) {
        sendKeyEvent(keyCode: keyCode, modifiers: modifiers, isDown: true)
        sendKeyEvent(keyCode: keyCode, modifiers: modifiers, isDown: false)
    }

    func sendUnicodeText(_ text: String) {
        guard !text.isEmpty else { return }
        // Handle single control characters via native virtual keycodes for full compatibility in Terminal/IDEs
        if text == "\n" || text == "\r" {
            sendKeyShortcut(keyCode: MacKeyCode.returnKey, modifiers: [])
            return
        }
        if text == "\t" {
            sendKeyShortcut(keyCode: MacKeyCode.tab, modifiers: [])
            return
        }
        if text.count == 1, let ch = text.first, let mapped = MacKeyCode.keyCode(forCharacter: ch) {
            let mods: KeyModifiers = mapped.needsShift ? [.shift] : []
            sendKeyShortcut(keyCode: mapped.keyCode, modifiers: mods)
            return
        }

        // Arbitrary Unicode / Emoji / Dictation phrases
        let utf16 = Array(text.utf16)
        let chunkSize = 16
        var idx = 0
        while idx < utf16.count {
            let end = min(idx + chunkSize, utf16.count)
            var slice = Array(utf16[idx..<end])
            if let down = CGEvent(keyboardEventSource: eventSource, virtualKey: 0, keyDown: true),
               let up = CGEvent(keyboardEventSource: eventSource, virtualKey: 0, keyDown: false) {
                down.keyboardSetUnicodeString(stringLength: slice.count, unicodeString: &slice)
                up.keyboardSetUnicodeString(stringLength: slice.count, unicodeString: &slice)
                down.post(tap: .cghidEventTap)
                up.post(tap: .cghidEventTap)
            }
            idx = end
        }
    }

    func currentNormalizedCursor(for displayID: UInt32?) -> (Double, Double) {
        let targetID = resolvedDisplay(displayID)
        let bounds = CGDisplayBounds(targetID)
        let loc = currentCursorQuartzLocation()
        guard bounds.width > 0, bounds.height > 0 else { return (0.5, 0.5) }
        let nx = min(1.0, max(0.0, Double((loc.x - bounds.origin.x) / bounds.width)))
        let ny = min(1.0, max(0.0, Double((loc.y - bounds.origin.y) / bounds.height)))
        return (nx, ny)
    }

    // MARK: - Helpers

    private func postMouseButton(at point: CGPoint, button: MouseButton, isDown: Bool, clickCount: Int) {
        let cgButton: CGMouseButton
        let cgType: CGEventType
        switch button {
        case .left:
            isLeftButtonDown = isDown
            cgButton = .left
            cgType = isDown ? .leftMouseDown : .leftMouseUp
        case .right:
            isRightButtonDown = isDown
            cgButton = .right
            cgType = isDown ? .rightMouseDown : .rightMouseUp
        case .center:
            isCenterButtonDown = isDown
            cgButton = .center
            cgType = isDown ? .otherMouseDown : .otherMouseUp
        }

        guard let event = CGEvent(
            mouseEventSource: eventSource,
            mouseType: cgType,
            mouseCursorPosition: point,
            mouseButton: cgButton
        ) else { return }
        event.setIntegerValueField(.mouseEventClickState, value: Int64(clickCount))
        event.post(tap: .cghidEventTap)
    }

    private func quartzPoint(normalizedX: Double, normalizedY: Double, displayID: UInt32?) -> CGPoint {
        let clampedX = min(1.0, max(0.0, normalizedX))
        let clampedY = min(1.0, max(0.0, normalizedY))
        let bounds = CGDisplayBounds(resolvedDisplay(displayID))
        let px = bounds.origin.x + CGFloat(clampedX) * max(1, bounds.width - 1)
        let py = bounds.origin.y + CGFloat(clampedY) * max(1, bounds.height - 1)
        return CGPoint(x: px, y: py)
    }

    private func resolvedDisplay(_ requested: UInt32?) -> CGDirectDisplayID {
        if let requested, CGDisplayBounds(requested).width > 0 {
            return requested
        }
        return CGMainDisplayID()
    }

    private func currentCursorQuartzLocation() -> CGPoint {
        CGEvent(source: nil)?.location ?? .zero
    }

    private func clampToActiveDisplays(_ point: CGPoint) -> CGPoint {
        var displayCount: UInt32 = 0
        CGGetActiveDisplayList(0, nil, &displayCount)
        guard displayCount > 0 else { return point }
        var displays = [CGDirectDisplayID](repeating: 0, count: Int(displayCount))
        CGGetActiveDisplayList(displayCount, &displays, &displayCount)

        for id in displays where CGDisplayBounds(id).contains(point) {
            return point
        }

        // Clamp to nearest active display rectangle
        var bestPoint = point
        var bestDistance = CGFloat.greatestFiniteMagnitude
        for id in displays {
            let rect = CGDisplayBounds(id)
            guard rect.width > 0, rect.height > 0 else { continue }
            let cx = min(max(point.x, rect.minX), rect.maxX - 1)
            let cy = min(max(point.y, rect.minY), rect.maxY - 1)
            let dist = hypot(point.x - cx, point.y - cy)
            if dist < bestDistance {
                bestDistance = dist
                bestPoint = CGPoint(x: cx, y: cy)
            }
        }
        return bestPoint
    }

    private func cgEventFlags(from modifiers: KeyModifiers) -> CGEventFlags {
        var flags: CGEventFlags = []
        if modifiers.contains(.command) { flags.insert(.maskCommand) }
        if modifiers.contains(.shift) { flags.insert(.maskShift) }
        if modifiers.contains(.option) { flags.insert(.maskAlternate) }
        if modifiers.contains(.control) { flags.insert(.maskControl) }
        if modifiers.contains(.function) { flags.insert(.maskSecondaryFn) }
        return flags
    }
}
