import AppKit
import ApplicationServices
import CoreGraphics
import Foundation
import ScreenCaptureKit

@MainActor
final class PermissionManager: ObservableObject {
    @Published private(set) var accessibilityGranted: Bool = false
    @Published private(set) var postEventGranted: Bool = false
    @Published private(set) var screenRecordingGranted: Bool = false

    var onPermissionsChanged: ((Bool, Bool) -> Void)?

    var inputControlReady: Bool {
        accessibilityGranted && postEventGranted
    }

    var runningAppPath: String {
        Bundle.main.bundleURL.path
    }

    private var pollTimer: Timer?
    private var isCheckingScreenCapture = false

    init() {
        refresh()
        startMonitoring()
    }

    func refresh() {
        let prevInput = inputControlReady
        let prevScreen = screenRecordingGranted

        accessibilityGranted = AXIsProcessTrusted()
        postEventGranted = CGPreflightPostEventAccess()

        if CGPreflightScreenCaptureAccess() {
            screenRecordingGranted = true
            notifyIfChanged(prevInput: prevInput, prevScreen: prevScreen)
        } else if !isCheckingScreenCapture {
            isCheckingScreenCapture = true
            Task { @MainActor [weak self] in
                guard let self else { return }
                defer { self.isCheckingScreenCapture = false }
                do {
                    let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
                    self.screenRecordingGranted = !content.displays.isEmpty
                } catch {
                    self.screenRecordingGranted = false
                }
                self.notifyIfChanged(prevInput: prevInput, prevScreen: prevScreen)
            }
            return
        }

        notifyIfChanged(prevInput: prevInput, prevScreen: prevScreen)
    }

    func requestAccessibility() {
        let promptKey = kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String
        let options = [promptKey: true] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(options)
        _ = CGRequestPostEventAccess()
        refresh()
        if !inputControlReady,
           let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") {
            NSWorkspace.shared.open(url)
        }
    }

    func requestScreenRecording() {
        _ = CGRequestScreenCaptureAccess()
        Task { @MainActor in
            _ = try? await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
            refresh()
            if !screenRecordingGranted,
               let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture") {
                NSWorkspace.shared.open(url)
            }
        }
    }

    /// Resets stale macOS TCC entries (e.g. left over from an earlier ad-hoc Xcode build) and re-prompts cleanly.
    func resetAndRepromptPermissions() {
        guard let bundleID = Bundle.main.bundleIdentifier else { return }
        for service in ["Accessibility", "PostEvent", "ScreenCapture"] {
            let proc = Process()
            proc.executableURL = URL(fileURLWithPath: "/usr/bin/tccutil")
            proc.arguments = ["reset", service, bundleID]
            try? proc.run()
            proc.waitUntilExit()
        }
        accessibilityGranted = false
        postEventGranted = false
        screenRecordingGranted = false
        requestAccessibility()
        requestScreenRecording()
    }

    /// Relaunches the running app bundle so macOS applies newly toggled Screen Recording permissions immediately.
    func relaunchApp() {
        let appPath = Bundle.main.bundleURL.path
        let proc = Process()
        proc.executableURL = URL(fileURLWithPath: "/bin/sh")
        proc.arguments = ["-c", "sleep 0.4 && open -a \"\(appPath)\""]
        try? proc.run()
        NSApplication.shared.terminate(nil)
    }

    private func notifyIfChanged(prevInput: Bool, prevScreen: Bool) {
        if prevInput != inputControlReady || prevScreen != screenRecordingGranted {
            onPermissionsChanged?(inputControlReady, screenRecordingGranted)
        }
    }

    private func startMonitoring() {
        pollTimer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.refresh()
            }
        }
    }
}
