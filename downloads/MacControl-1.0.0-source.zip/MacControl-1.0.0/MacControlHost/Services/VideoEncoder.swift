import CoreMedia
import CoreVideo
import Foundation
import MacControlCore
import VideoToolbox

final class VideoEncoder: @unchecked Sendable {
    var onEncodedFrame: ((VideoFramePacket) -> Void)?

    private let queue = DispatchQueue(label: "com.maccontrol.video.encoder", qos: .userInteractive)
    private var session: VTCompressionSession?
    private var currentWidth: Int32 = 0
    private var currentHeight: Int32 = 0
    private var currentCodec: VideoCodecKind = .hevc
    private var currentBitrate: Int = 0
    private var currentFPS: Int = 60
    private var forceKeyframeFlag = true

    init() {}

    deinit {
        if let session {
            VTCompressionSessionInvalidate(session)
        }
    }

    func requestKeyframe() {
        queue.async { [weak self] in
            self?.forceKeyframeFlag = true
        }
    }

    func reset() {
        queue.async { [weak self] in
            self?.teardownSession()
        }
    }

    func encode(
        imageBuffer: CVImageBuffer,
        presentationTimeStamp: CMTime,
        codec: VideoCodecKind,
        bitrateBps: Int,
        fps: Int
    ) {
        queue.async { [weak self] in
            guard let self else { return }
            let width = Int32(CVPixelBufferGetWidth(imageBuffer))
            let height = Int32(CVPixelBufferGetHeight(imageBuffer))
            guard width > 0, height > 0 else { return }

            if self.session == nil
                || self.currentWidth != width
                || self.currentHeight != height
                || self.currentCodec != codec {
                self.recreateSession(width: width, height: height, codec: codec, bitrateBps: bitrateBps, fps: fps)
            } else if self.currentBitrate != bitrateBps || self.currentFPS != fps {
                self.updateDynamicRates(bitrateBps: bitrateBps, fps: fps)
            }

            guard let activeSession = self.session else { return }

            var frameProperties: CFDictionary?
            if self.forceKeyframeFlag {
                self.forceKeyframeFlag = false
                frameProperties = [
                    kVTEncodeFrameOptionKey_ForceKeyFrame as String: true
                ] as CFDictionary
            }

            var infoFlags = VTEncodeInfoFlags()
            VTCompressionSessionEncodeFrame(
                activeSession,
                imageBuffer: imageBuffer,
                presentationTimeStamp: presentationTimeStamp,
                duration: .invalid,
                frameProperties: frameProperties,
                infoFlagsOut: &infoFlags
            ) { [weak self] status, _, sampleBuffer in
                guard let self, status == noErr, let sampleBuffer else { return }
                self.handleCompressedSampleBuffer(sampleBuffer, codec: codec, width: UInt16(width), height: UInt16(height))
            }
        }
    }

    // MARK: - Session Management

    private func recreateSession(width: Int32, height: Int32, codec: VideoCodecKind, bitrateBps: Int, fps: Int) {
        teardownSession()
        let cmCodec: CMVideoCodecType = (codec == .hevc) ? kCMVideoCodecType_HEVC : kCMVideoCodecType_H264
        let encoderSpec: [String: Any] = [
            kVTVideoEncoderSpecification_EnableLowLatencyRateControl as String: true
        ]

        var newSession: VTCompressionSession?
        var status = VTCompressionSessionCreate(
            allocator: kCFAllocatorDefault,
            width: width,
            height: height,
            codecType: cmCodec,
            encoderSpecification: encoderSpec as CFDictionary,
            imageBufferAttributes: nil,
            compressedDataAllocator: nil,
            outputCallback: nil,
            refcon: nil,
            compressionSessionOut: &newSession
        )
        if status != noErr || newSession == nil {
            // Fallback without low-latency spec if hardware doesn't support that hint
            status = VTCompressionSessionCreate(
                allocator: kCFAllocatorDefault,
                width: width,
                height: height,
                codecType: cmCodec,
                encoderSpecification: nil,
                imageBufferAttributes: nil,
                compressedDataAllocator: nil,
                outputCallback: nil,
                refcon: nil,
                compressionSessionOut: &newSession
            )
        }
        guard status == noErr, let created = newSession else { return }

        VTSessionSetProperty(created, key: kVTCompressionPropertyKey_RealTime, value: kCFBooleanTrue)
        VTSessionSetProperty(created, key: kVTCompressionPropertyKey_AllowFrameReordering, value: kCFBooleanFalse)
        if codec == .h264 {
            VTSessionSetProperty(created, key: kVTCompressionPropertyKey_ProfileLevel, value: kVTProfileLevel_H264_High_AutoLevel)
        } else {
            VTSessionSetProperty(created, key: kVTCompressionPropertyKey_ProfileLevel, value: kVTProfileLevel_HEVC_Main_AutoLevel)
        }

        self.session = created
        self.currentWidth = width
        self.currentHeight = height
        self.currentCodec = codec
        self.forceKeyframeFlag = true
        updateDynamicRates(bitrateBps: bitrateBps, fps: fps)
        VTCompressionSessionPrepareToEncodeFrames(created)
    }

    private func updateDynamicRates(bitrateBps: Int, fps: Int) {
        guard let session else { return }
        currentBitrate = bitrateBps
        currentFPS = fps
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_AverageBitRate, value: bitrateBps as CFNumber)
        let byteLimitPerSec = Int(Double(bitrateBps) / 8.0 * 1.5)
        let dataRateLimits: [Int] = [byteLimitPerSec, 1]
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_DataRateLimits, value: dataRateLimits as CFArray)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_ExpectedFrameRate, value: fps as CFNumber)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_MaxKeyFrameInterval, value: max(30, fps * 2) as CFNumber)
        VTSessionSetProperty(session, key: kVTCompressionPropertyKey_MaxKeyFrameIntervalDuration, value: 2.0 as CFNumber)
    }

    private func teardownSession() {
        if let session {
            VTCompressionSessionInvalidate(session)
            self.session = nil
        }
    }

    // MARK: - Packet Serialization

    private func handleCompressedSampleBuffer(_ sampleBuffer: CMSampleBuffer, codec: VideoCodecKind, width: UInt16, height: UInt16) {
        guard CMSampleBufferDataIsReady(sampleBuffer),
              let dataBuffer = CMSampleBufferGetDataBuffer(sampleBuffer) else {
            return
        }

        let isKeyframe = Self.isSampleBufferKeyframe(sampleBuffer)
        var parameterSets: [Data] = []
        if isKeyframe, let formatDesc = CMSampleBufferGetFormatDescription(sampleBuffer) {
            parameterSets = Self.extractParameterSets(from: formatDesc, codec: codec)
        }

        let totalLength = CMBlockBufferGetDataLength(dataBuffer)
        guard totalLength > 0 else { return }
        var avccBytes = Data(count: totalLength)
        let copyStatus = avccBytes.withUnsafeMutableBytes { rawBuffer -> OSStatus in
            guard let baseAddress = rawBuffer.baseAddress else { return -1 }
            return CMBlockBufferCopyDataBytes(dataBuffer, atOffset: 0, dataLength: totalLength, destination: baseAddress)
        }
        guard copyStatus == kCMBlockBufferNoErr else { return }

        let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        let seconds = CMTimeGetSeconds(pts)
        let timestampUs = seconds.isFinite && seconds >= 0 ? UInt64(seconds * 1_000_000) : 0

        let packet = VideoFramePacket(
            codec: codec,
            isKeyframe: isKeyframe,
            width: width,
            height: height,
            timestampUs: timestampUs,
            parameterSets: parameterSets,
            avccData: avccBytes
        )
        onEncodedFrame?(packet)
    }

    private static func isSampleBufferKeyframe(_ sampleBuffer: CMSampleBuffer) -> Bool {
        guard let attachments = CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, createIfNecessary: false) as? [[CFString: Any]],
              let first = attachments.first else {
            return true
        }
        if let notSync = first[kCMSampleAttachmentKey_NotSync] as? Bool {
            return !notSync
        }
        return true
    }

    private static func extractParameterSets(from formatDesc: CMFormatDescription, codec: VideoCodecKind) -> [Data] {
        var count: Int = 0
        switch codec {
        case .h264:
            guard CMVideoFormatDescriptionGetH264ParameterSetAtIndex(formatDesc, parameterSetIndex: 0, parameterSetPointerOut: nil, parameterSetSizeOut: nil, parameterSetCountOut: &count, nalUnitHeaderLengthOut: nil) == noErr else {
                return []
            }
            var sets: [Data] = []
            for idx in 0..<count {
                var ptr: UnsafePointer<UInt8>?
                var size: Int = 0
                if CMVideoFormatDescriptionGetH264ParameterSetAtIndex(formatDesc, parameterSetIndex: idx, parameterSetPointerOut: &ptr, parameterSetSizeOut: &size, parameterSetCountOut: nil, nalUnitHeaderLengthOut: nil) == noErr,
                   let ptr, size > 0 {
                    sets.append(Data(bytes: ptr, count: size))
                }
            }
            return sets

        case .hevc:
            guard CMVideoFormatDescriptionGetHEVCParameterSetAtIndex(formatDesc, parameterSetIndex: 0, parameterSetPointerOut: nil, parameterSetSizeOut: nil, parameterSetCountOut: &count, nalUnitHeaderLengthOut: nil) == noErr else {
                return []
            }
            var sets: [Data] = []
            for idx in 0..<count {
                var ptr: UnsafePointer<UInt8>?
                var size: Int = 0
                if CMVideoFormatDescriptionGetHEVCParameterSetAtIndex(formatDesc, parameterSetIndex: idx, parameterSetPointerOut: &ptr, parameterSetSizeOut: &size, parameterSetCountOut: nil, nalUnitHeaderLengthOut: nil) == noErr,
                   let ptr, size > 0 {
                    sets.append(Data(bytes: ptr, count: size))
                }
            }
            return sets
        }
    }
}
