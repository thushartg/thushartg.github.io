import AudioToolbox
import CoreGraphics
import CoreMedia
import Foundation
import MacControlCore
import ScreenCaptureKit

final class ScreenStreamEngine: NSObject, SCStreamOutput, SCStreamDelegate, @unchecked Sendable {
    var onVideoPacket: ((VideoFramePacket) -> Void)?
    var onAudioPacket: ((AudioFramePacket) -> Void)?
    var onStreamError: ((String) -> Void)?

    private let videoQueue = DispatchQueue(label: "com.maccontrol.scstream.video", qos: .userInteractive)
    private let audioQueue = DispatchQueue(label: "com.maccontrol.scstream.audio", qos: .userInteractive)
    private let encoder = VideoEncoder()

    private var stream: SCStream?
    private var activeConfig = StreamConfiguration()
    private(set) var availableDisplays: [DisplayMetadata] = []
    private(set) var activeDisplayID: UInt32?

    override init() {
        super.init()
        encoder.onEncodedFrame = { [weak self] packet in
            self?.onVideoPacket?(packet)
        }
    }

    func refreshDisplays() async -> [DisplayMetadata] {
        do {
            let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
            let mainID = CGMainDisplayID()
            let list: [DisplayMetadata] = content.displays.enumerated().map { index, display in
                let isMain = display.displayID == mainID
                let title = isMain ? "Main Display (\(display.width)×\(display.height))" : "Display \(index + 1) (\(display.width)×\(display.height))"
                return DisplayMetadata(
                    id: display.displayID,
                    name: title,
                    width: display.width,
                    height: display.height,
                    isMain: isMain
                )
            }
            self.availableDisplays = list
            return list
        } catch {
            // Fallback to CoreGraphics display list if Screen Recording isn't granted yet
            let mainID = CGMainDisplayID()
            let bounds = CGDisplayBounds(mainID)
            let fallback = [
                DisplayMetadata(
                    id: mainID,
                    name: "Main Display (\(Int(bounds.width))×\(Int(bounds.height)))",
                    width: max(1280, Int(bounds.width)),
                    height: max(800, Int(bounds.height)),
                    isMain: true
                )
            ]
            self.availableDisplays = fallback
            return fallback
        }
    }

    func startOrUpdate(with config: StreamConfiguration) async {
        self.activeConfig = config
        guard config.enabled || config.audioEnabled else {
            await stop()
            return
        }

        do {
            let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
            guard !content.displays.isEmpty else {
                onStreamError?("No active displays available for capture.")
                return
            }

            let mainID = CGMainDisplayID()
            let chosenDisplay: SCDisplay
            if let requestedID = config.displayID,
               let match = content.displays.first(where: { $0.displayID == requestedID }) {
                chosenDisplay = match
            } else if let mainMatch = content.displays.first(where: { $0.displayID == mainID }) {
                chosenDisplay = mainMatch
            } else {
                chosenDisplay = content.displays[0]
            }
            self.activeDisplayID = chosenDisplay.displayID

            let scConfig = makeSCStreamConfiguration(for: chosenDisplay, config: config)
            let filter = SCContentFilter(display: chosenDisplay, excludingWindows: [])

            if let existing = stream {
                try await existing.updateContentFilter(filter)
                try await existing.updateConfiguration(scConfig)
                encoder.requestKeyframe()
            } else {
                encoder.reset()
                let newStream = SCStream(filter: filter, configuration: scConfig, delegate: self)
                try newStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: videoQueue)
                try newStream.addStreamOutput(self, type: .audio, sampleHandlerQueue: audioQueue)
                try await newStream.startCapture()
                self.stream = newStream
            }
        } catch {
            onStreamError?("ScreenCaptureKit error: \(error.localizedDescription)")
        }
    }

    func stop() async {
        if let existing = stream {
            self.stream = nil
            try? await existing.stopCapture()
        }
        encoder.reset()
    }

    func requestKeyframe() {
        encoder.requestKeyframe()
    }

    // MARK: - SCStreamOutput

    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of outputType: SCStreamOutputType) {
        guard CMSampleBufferIsValid(sampleBuffer) else { return }

        switch outputType {
        case .screen:
            guard activeConfig.enabled else { return }
            guard let attachments = CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, createIfNecessary: false) as? [[SCStreamFrameInfo: Any]],
                  let statusRaw = attachments.first?[.status] as? Int,
                  let status = SCFrameStatus(rawValue: statusRaw),
                  status == .complete,
                  let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
                return
            }
            let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
            encoder.encode(
                imageBuffer: pixelBuffer,
                presentationTimeStamp: pts,
                codec: activeConfig.codec,
                bitrateBps: activeConfig.quality.targetBitrateBps,
                fps: max(15, min(60, activeConfig.fps))
            )

        case .audio:
            guard activeConfig.audioEnabled else { return }
            if let packet = Self.convertAudioSampleBuffer(sampleBuffer) {
                onAudioPacket?(packet)
            }

        @unknown default:
            break
        }
    }

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        self.stream = nil
        onStreamError?("Screen capture stopped: \(error.localizedDescription)")
    }

    // MARK: - Helpers

    private func makeSCStreamConfiguration(for display: SCDisplay, config: StreamConfiguration) -> SCStreamConfiguration {
        let sc = SCStreamConfiguration()
        let srcW = Double(max(1, display.width))
        let srcH = Double(max(1, display.height))
        let maxDim = Double(config.quality.maxDimension)
        let scale = min(1.5, maxDim / max(srcW, srcH))
        // Keep even pixel dimensions for hardware H.264/HEVC macroblocks
        let outW = config.enabled ? max(640, Int((srcW * scale) / 2.0) * 2) : 320
        let outH = config.enabled ? max(400, Int((srcH * scale) / 2.0) * 2) : 200

        sc.width = outW
        sc.height = outH
        let clampedFPS = config.enabled ? max(15, min(60, config.fps)) : 1
        sc.minimumFrameInterval = CMTime(value: 1, timescale: CMTimeScale(clampedFPS))
        sc.pixelFormat = kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange
        sc.showsCursor = true
        sc.queueDepth = 3

        sc.capturesAudio = config.audioEnabled
        sc.sampleRate = 48_000
        sc.channelCount = 2
        sc.excludesCurrentProcessAudio = true
        return sc
    }

    /// Downsamples 48kHz Float32 planar/interleaved ScreenCaptureKit audio into 24kHz Stereo Int16 PCM packets.
    private static func convertAudioSampleBuffer(_ sampleBuffer: CMSampleBuffer) -> AudioFramePacket? {
        guard let formatDesc = CMSampleBufferGetFormatDescription(sampleBuffer),
              let asbdPtr = CMAudioFormatDescriptionGetStreamBasicDescription(formatDesc) else {
            return nil
        }
        let asbd = asbdPtr.pointee
        let totalFrames = CMSampleBufferGetNumSamples(sampleBuffer)
        guard totalFrames > 0 else { return nil }

        var blockBuffer: CMBlockBuffer?
        let bufferListSize = MemoryLayout<AudioBufferList>.size + MemoryLayout<AudioBuffer>.size * 2
        let rawListPtr = UnsafeMutableRawPointer.allocate(byteCount: bufferListSize, alignment: MemoryLayout<AudioBufferList>.alignment)
        defer { rawListPtr.deallocate() }
        let audioBufferListPtr = rawListPtr.bindMemory(to: AudioBufferList.self, capacity: 1)

        let status = CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(
            sampleBuffer,
            bufferListSizeNeededOut: nil,
            bufferListOut: audioBufferListPtr,
            bufferListSize: bufferListSize,
            blockBufferAllocator: nil,
            blockBufferMemoryAllocator: nil,
            flags: kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment,
            blockBufferOut: &blockBuffer
        )
        guard status == noErr else { return nil }

        let abl = UnsafeMutableAudioBufferListPointer(audioBufferListPtr)
        let isFloat = (asbd.mFormatFlags & kAudioFormatFlagIsFloat) != 0
        let isNonInterleaved = (asbd.mFormatFlags & kAudioFormatFlagIsNonInterleaved) != 0
        guard isFloat, abl.count >= 1 else { return nil }

        // Decimate 2:1 when input is ~48kHz to halve network overhead while keeping full 12kHz bandwidth
        let decimateStep = asbd.mSampleRate >= 44_100 ? 2 : 1
        let outSampleRate = UInt32(asbd.mSampleRate / Double(decimateStep))
        let outFrameCount = totalFrames / decimateStep
        guard outFrameCount > 0 else { return nil }

        var outSamples = [Int16](repeating: 0, count: outFrameCount * 2)

        if isNonInterleaved {
            guard let leftData = abl[0].mData?.assumingMemoryBound(to: Float32.self) else { return nil }
            let rightData = (abl.count > 1 ? abl[1].mData?.assumingMemoryBound(to: Float32.self) : nil) ?? leftData
            for outIdx in 0..<outFrameCount {
                let srcIdx = outIdx * decimateStep
                let l = max(-1.0, min(1.0, leftData[srcIdx]))
                let r = max(-1.0, min(1.0, rightData[srcIdx]))
                outSamples[outIdx * 2] = Int16(l * 32767.0)
                outSamples[outIdx * 2 + 1] = Int16(r * 32767.0)
            }
        } else {
            guard let interleaved = abl[0].mData?.assumingMemoryBound(to: Float32.self) else { return nil }
            let chCount = max(1, Int(asbd.mChannelsPerFrame))
            for outIdx in 0..<outFrameCount {
                let srcFrame = outIdx * decimateStep
                let l = max(-1.0, min(1.0, interleaved[srcFrame * chCount]))
                let r = chCount > 1 ? max(-1.0, min(1.0, interleaved[srcFrame * chCount + 1])) : l
                outSamples[outIdx * 2] = Int16(l * 32767.0)
                outSamples[outIdx * 2 + 1] = Int16(r * 32767.0)
            }
        }

        let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        let secs = CMTimeGetSeconds(pts)
        let tsUs = secs.isFinite && secs >= 0 ? UInt64(secs * 1_000_000) : 0

        let pcmData = outSamples.withUnsafeBufferPointer { Data(buffer: $0) }
        return AudioFramePacket(
            sampleRate: outSampleRate,
            channels: 2,
            timestampUs: tsUs,
            pcmInt16Data: pcmData
        )
    }
}
