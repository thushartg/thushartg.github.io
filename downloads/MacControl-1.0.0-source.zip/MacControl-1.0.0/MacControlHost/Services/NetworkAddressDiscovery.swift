import Darwin
import Foundation

struct DiscoveredHostAddresses: Equatable {
    var localLANAddresses: [String] = []
    var vpnTailscaleAddresses: [String] = []

    var primaryLAN: String? { localLANAddresses.first }
    var primaryVPN: String? { vpnTailscaleAddresses.first }
}

enum NetworkAddressDiscovery {
    static func currentIPv4Addresses() -> DiscoveredHostAddresses {
        var result = DiscoveredHostAddresses()
        var ifaddrPtr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddrPtr) == 0, let firstAddr = ifaddrPtr else {
            return result
        }
        defer { freeifaddrs(firstAddr) }

        var ptr: UnsafeMutablePointer<ifaddrs>? = firstAddr
        while let current = ptr {
            let interface = current.pointee
            ptr = interface.ifa_next

            let flags = Int32(interface.ifa_flags)
            guard (flags & IFF_UP) != 0,
                  (flags & IFF_LOOPBACK) == 0,
                  let addr = interface.ifa_addr,
                  addr.pointee.sa_family == UInt8(AF_INET) else {
                continue
            }

            let name = String(cString: interface.ifa_name)
            var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            let getNameRes = getnameinfo(
                addr,
                socklen_t(addr.pointee.sa_len),
                &hostname,
                socklen_t(hostname.count),
                nil,
                0,
                NI_NUMERICHOST
            )
            guard getNameRes == 0 else { continue }
            let ip = String(cString: hostname)
            guard !ip.hasPrefix("169.254.") else { continue }

            // Tailscale / CGNAT VPN range 100.64.0.0/10 or utun interfaces
            if isCGNATOrVPN(ip: ip, interfaceName: name) {
                if !result.vpnTailscaleAddresses.contains(ip) {
                    result.vpnTailscaleAddresses.append(ip)
                }
            } else if name.hasPrefix("en") || name.hasPrefix("bridge") {
                if !result.localLANAddresses.contains(ip) {
                    result.localLANAddresses.append(ip)
                }
            }
        }
        return result
    }

    private static func isCGNATOrVPN(ip: String, interfaceName: String) -> Bool {
        let parts = ip.split(separator: ".").compactMap { Int($0) }
        if parts.count == 4, parts[0] == 100, (64...127).contains(parts[1]) {
            return true
        }
        return interfaceName.hasPrefix("utun")
    }
}
